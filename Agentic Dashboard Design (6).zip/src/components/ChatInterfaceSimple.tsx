import { useState } from 'react';
import { Send, Mic, User, Bot, Circle, Zap, MessageSquare, CheckCircle, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AgentFlowGraph } from './AgentFlowGraph';
import { ReportProblemDialog } from './ReportProblemDialog';

interface Message {
  id: string;
  role: 'user' | 'agent';
  content: string;
  timestamp: string;
}

interface Event {
  id: string;
  type: 'tool_call_started' | 'tool_call_completed' | 'agent_processing' | 'token_usage' | 'agent_response';
  title: string;
  details: string;
  timestamp: string;
  metadata?: {
    prompt?: number;
    completion?: number;
    total?: number;
  };
}

export function ChatInterfaceSimple() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'user',
      content: "I'd like to review investment products and get recommendations based on my retirement goals",
      timestamp: '9:30 AM'
    },
    {
      id: '2',
      role: 'agent',
      content: `Sure, I'd be happy to help with that. However, in order to provide you with the most relevant advice, I'll need a bit more information:

1. What is your current age and when do you plan on retiring?
2. Could you please describe your risk tolerance? (High, Medium or Low)
3. What is your current financial situation? (income level, savings)
4. Do you have any existing retirement accounts? If so, what type?
5. Do you have a specific retirement goal in mind?

Please provide as much detail as possible so I can give you personalized advice for your situation.`,
      timestamp: '9:30 AM'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [showArchitecture, setShowArchitecture] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [events, setEvents] = useState<Event[]>([
    {
      id: 'e1',
      type: 'tool_call_started',
      title: 'Tool Call Started',
      details: 'tool: msg_editor_query_change_requests',
      timestamp: '1:41:17 AM'
    },
    {
      id: 'e2',
      type: 'tool_call_completed',
      title: 'Tool Call Completed',
      details: 'tool: msg_editor_query_change_requests',
      timestamp: '1:41:24 AM'
    },
    {
      id: 'e3',
      type: 'agent_processing',
      title: 'Agent Processing Complete',
      details: '',
      timestamp: '1:41:24 AM'
    },
    {
      id: 'e4',
      type: 'token_usage',
      title: 'Tool Token Usage',
      details: 'tool: msg_editor_query_change_requests',
      timestamp: '1:41:26 AM',
      metadata: { prompt: 382, completion: 168, total: 550 }
    },
    {
      id: 'e5',
      type: 'tool_call_started',
      title: 'Tool Call Started',
      details: 'tool: msg_widget_query_eca_reports',
      timestamp: '1:41:28 AM'
    },
    {
      id: 'e6',
      type: 'tool_call_completed',
      title: 'Tool Call Completed',
      details: 'tool: msg_widget_query_eca_reports',
      timestamp: '1:41:33 AM'
    },
    {
      id: 'e7',
      type: 'agent_processing',
      title: 'Agent Processing Complete',
      details: '',
      timestamp: '1:41:33 AM'
    },
    {
      id: 'e8',
      type: 'token_usage',
      title: 'Tool Token Usage',
      details: 'tool: msg_widget_query_eca_reports',
      timestamp: '1:41:40 AM',
      metadata: { prompt: 680, completion: 158, total: 838 }
    },
    {
      id: 'e9',
      type: 'agent_response',
      title: 'Agent Response',
      details: '"Recent changes - CRQ7003..."',
      timestamp: '1:41:40 AM'
    }
  ]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    };

    setMessages([...messages, newMessage]);
    setInputValue('');

    // Simulate agent response with typing indicator
    setTimeout(() => {
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'agent',
        content: "Thank you for your query. I'm analyzing your requirements and will provide personalized recommendations based on your retirement goals.",
        timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
      };
      setMessages(prev => [...prev, agentMessage]);
      
      // Add events
      const newEvents: Event[] = [
        {
          id: `e-${Date.now()}-1`,
          type: 'tool_call_started',
          title: 'Tool Call Started',
          details: 'tool: retirement_analysis',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        },
        {
          id: `e-${Date.now()}-2`,
          type: 'tool_call_completed',
          title: 'Tool Call Completed',
          details: 'tool: retirement_analysis',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        },
        {
          id: `e-${Date.now()}-3`,
          type: 'agent_processing',
          title: 'Agent Processing Complete',
          details: '',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        },
        {
          id: `e-${Date.now()}-4`,
          type: 'token_usage',
          title: 'Tool Token Usage',
          details: 'tool: retirement_analysis',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' }),
          metadata: { prompt: 156, completion: 89, total: 245 }
        },
        {
          id: `e-${Date.now()}-5`,
          type: 'agent_response',
          title: 'Agent Response',
          details: '"Thank you for your query..."',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        }
      ];
      setEvents(prev => [...prev, ...newEvents]);
    }, 1000);
  };

  const getEventIcon = (type: Event['type']) => {
    switch (type) {
      case 'tool_call_started':
      case 'tool_call_completed':
        return <Circle className="w-4 h-4" />;
      case 'agent_processing':
        return <Zap className="w-4 h-4" />;
      case 'token_usage':
        return <MessageSquare className="w-4 h-4" />;
      case 'agent_response':
        return <CheckCircle className="w-4 h-4" />;
    }
  };

  const getEventColor = (type: Event['type']) => {
    switch (type) {
      case 'tool_call_started':
      case 'tool_call_completed':
        return 'bg-muted text-muted-foreground';
      case 'agent_processing':
        return 'bg-orange-500 text-white';
      case 'token_usage':
        return 'bg-blue-500 text-white';
      case 'agent_response':
        return 'bg-green-500 text-white';
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        {/* Chat Header */}
        <div className="border-b px-6 py-4 bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg">Chat</h2>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant={showArchitecture ? 'default' : 'outline'}
                size="sm" 
                onClick={() => setShowArchitecture(!showArchitecture)}
                className="gap-2"
              >
                {showArchitecture ? 'Hide' : 'Show'} Architecture
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowReportDialog(true)}
                className="gap-2"
              >
                <AlertCircle className="w-4 h-4" />
                Report Problem
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'agent' && (
                <div className="w-8 h-8 rounded-md border bg-muted flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div className={`max-w-2xl ${message.role === 'user' ? 'order-first' : ''}`}>
                <div
                  className={`rounded-lg px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-foreground text-background ml-auto'
                      : 'border bg-card'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 px-1">{message.timestamp}</p>
              </div>
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-md border bg-muted flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Input Area */}
        <div className="border-t p-4 bg-card">
          <div className="flex items-center gap-3">
            <div className="flex-1 relative">
              <Input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type a message to test the app..."
                className="pr-10"
              />
              <button className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-accent rounded transition-colors">
                <Mic className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
            <Button onClick={handleSend} size="icon">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Architecture Graph Panel - Right Side (when visible) */}
      {showArchitecture && (
        <div className="w-80 border-l bg-card flex flex-col">
          {/* Panel Header */}
          <div className="px-4 py-3 border-b">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-sm">Architecture</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowArchitecture(false)}>
                Close
              </Button>
            </div>
          </div>

          {/* Graph Content */}
          <div className="flex-1 overflow-hidden p-2">
            <div className="h-full w-full" style={{ minHeight: '400px' }}>
              <AgentFlowGraph />
            </div>
          </div>
        </div>
      )}
      
      {/* Events Panel - Right Side */}
      <div className="w-96 border-l bg-card flex flex-col">
        {/* Panel Header */}
        <div className="px-4 py-3 border-b">
          <h3 className="font-medium">Events</h3>
        </div>

        {/* Events Content */}
        <div className="flex-1 overflow-auto p-4">
          {/* Timeline */}
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-4 top-0 bottom-0 w-px bg-border" />
            
            {/* Events */}
            <div className="space-y-4">
              {events.map((event) => (
                <div key={event.id} className="relative pl-10">
                  {/* Icon */}
                  <div className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center ${getEventColor(event.type)}`}>
                    {getEventIcon(event.type)}
                  </div>
                  
                  {/* Content */}
                  <div className="pb-4">
                    <div className="text-sm font-medium mb-0.5">
                      {event.title}
                    </div>
                    {event.details && (
                      <div className="text-xs text-muted-foreground mb-1">
                        {event.details}
                      </div>
                    )}
                    {event.metadata && (
                      <div className="text-xs text-muted-foreground mb-1">
                        Prompt: {event.metadata.prompt} | Completion: {event.metadata.completion} | Total: {event.metadata.total}
                      </div>
                    )}
                    <div className="text-xs text-muted-foreground">
                      {event.timestamp}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Report Problem Dialog */}
      <ReportProblemDialog 
        open={showReportDialog} 
        onClose={() => setShowReportDialog(false)}
        appName="Chat Interface"
      />
    </div>
  );
}