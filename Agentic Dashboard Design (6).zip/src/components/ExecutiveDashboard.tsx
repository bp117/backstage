import { useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  Target,
  BarChart3,
  PieChart,
  Activity,
  Award,
  Building2,
  Zap
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

export function ExecutiveDashboard() {
  return (
    <div className="p-8 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-2">Executive Dashboard</h1>
          <p className="text-muted-foreground">
            Strategic overview of AI agent adoption, ROI, and business impact
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <BarChart3 className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button>
            View Detailed Analytics
          </Button>
        </div>
      </div>

      {/* Executive KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total ROI</p>
              <p className="text-3xl">347%</p>
              <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +23% YoY
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Cost Savings</p>
              <p className="text-3xl">$12.4M</p>
              <p className="text-xs text-muted-foreground mt-2">
                Annually
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">User Adoption</p>
              <p className="text-3xl">89%</p>
              <p className="text-xs text-green-600 mt-2">
                +12% this quarter
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Customer Satisfaction</p>
              <p className="text-3xl">4.7</p>
              <p className="text-xs text-muted-foreground mt-2">
                Out of 5.0
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <Award className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Business Impact Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="p-6 lg:col-span-2">
          <h2 className="text-lg mb-6">Business Impact by Division</h2>
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Building2 className="w-4 h-4 text-blue-600" />
                  <div>
                    <p className="font-medium">Retail Banking</p>
                    <p className="text-sm text-muted-foreground">Cost reduction: $4.2M</p>
                  </div>
                </div>
                <span className="text-sm font-medium">92%</span>
              </div>
              <Progress value={92} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Building2 className="w-4 h-4 text-green-600" />
                  <div>
                    <p className="font-medium">Wealth Management</p>
                    <p className="text-sm text-muted-foreground">Cost reduction: $3.8M</p>
                  </div>
                </div>
                <span className="text-sm font-medium">88%</span>
              </div>
              <Progress value={88} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Building2 className="w-4 h-4 text-purple-600" />
                  <div>
                    <p className="font-medium">Commercial Banking</p>
                    <p className="text-sm text-muted-foreground">Cost reduction: $2.6M</p>
                  </div>
                </div>
                <span className="text-sm font-medium">76%</span>
              </div>
              <Progress value={76} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Building2 className="w-4 h-4 text-orange-600" />
                  <div>
                    <p className="font-medium">Customer Service</p>
                    <p className="text-sm text-muted-foreground">Cost reduction: $1.8M</p>
                  </div>
                </div>
                <span className="text-sm font-medium">95%</span>
              </div>
              <Progress value={95} className="h-2" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg mb-6">Quarterly Goals</h2>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-green-600" />
                  <span className="text-sm">User Adoption</span>
                </div>
                <span className="text-sm font-medium">89/90%</span>
              </div>
              <Progress value={98.8} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <span className="text-sm">Cost Savings</span>
                </div>
                <span className="text-sm font-medium">$12.4M/$12M</span>
              </div>
              <Progress value={103} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-orange-600" />
                  <span className="text-sm">Agent Deployment</span>
                </div>
                <span className="text-sm font-medium">487/500</span>
              </div>
              <Progress value={97.4} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-yellow-600" />
                  <span className="text-sm">Satisfaction</span>
                </div>
                <span className="text-sm font-medium">4.7/4.5</span>
              </div>
              <Progress value={104} className="h-2" />
            </div>
          </div>
        </Card>
      </div>

      {/* Strategic Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg">Top Performing Agents</h2>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <p className="font-medium">Retirement Planning Assistant</p>
                <p className="text-sm text-muted-foreground">Wealth Management</p>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">$2.1M saved</p>
                <p className="text-sm text-muted-foreground">12,450 interactions</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <p className="font-medium">Customer Onboarding Agent</p>
                <p className="text-sm text-muted-foreground">Retail Banking</p>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">$1.8M saved</p>
                <p className="text-sm text-muted-foreground">18,923 interactions</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <p className="font-medium">Investment Advisory Agent</p>
                <p className="text-sm text-muted-foreground">Wealth Management</p>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">$1.5M saved</p>
                <p className="text-sm text-muted-foreground">9,876 interactions</p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg">Recent Milestones</h2>
            <Button variant="ghost" size="sm">View Timeline</Button>
          </div>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center flex-shrink-0">
                <Award className="w-4 h-4 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium">500th Agent Deployed</p>
                <p className="text-sm text-muted-foreground">Platform milestone reached ahead of schedule</p>
                <p className="text-xs text-muted-foreground mt-1">2 days ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-4 h-4 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Q4 Cost Savings Target Exceeded</p>
                <p className="text-sm text-muted-foreground">Achieved 103% of quarterly goal</p>
                <p className="text-xs text-muted-foreground mt-1">1 week ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                <Users className="w-4 h-4 text-purple-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium">User Adoption Reaches 89%</p>
                <p className="text-sm text-muted-foreground">Nearly 90% of employees actively using AI agents</p>
                <p className="text-xs text-muted-foreground mt-1">2 weeks ago</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Key Performance Indicators */}
      <Card className="p-6">
        <h2 className="text-lg mb-6">Key Performance Indicators - Last 30 Days</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Activity className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Interactions</p>
                <p className="text-2xl">847K</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-green-600">+18.3%</span>
              <span className="text-muted-foreground">vs last month</span>
            </div>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <Zap className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Automation Rate</p>
                <p className="text-2xl">94%</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-green-600">+3.2%</span>
              <span className="text-muted-foreground">vs last month</span>
            </div>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <Award className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">First Call Resolution</p>
                <p className="text-2xl">87%</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-green-600">+5.1%</span>
              <span className="text-muted-foreground">vs last month</span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
