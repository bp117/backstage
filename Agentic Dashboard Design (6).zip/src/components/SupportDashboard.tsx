import { useState } from 'react';
import { 
  Ticket, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  TrendingDown,
  MessageSquare,
  User,
  Search,
  Filter
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface SupportTicket {
  id: string;
  title: string;
  user: string;
  agent: string;
  status: 'open' | 'in_progress' | 'resolved' | 'escalated';
  priority: 'low' | 'medium' | 'high' | 'critical';
  created: string;
  updated: string;
}

const mockTickets: SupportTicket[] = [
  {
    id: 'TKT-1847',
    title: 'Agent not responding to queries',
    user: 'Sarah Mitchell',
    agent: 'Retirement Planning App',
    status: 'open',
    priority: 'high',
    created: '10 min ago',
    updated: '10 min ago'
  },
  {
    id: 'TKT-1846',
    title: 'Incorrect investment recommendations',
    user: 'John Davis',
    agent: 'Investment Advisor App',
    status: 'in_progress',
    priority: 'critical',
    created: '25 min ago',
    updated: '5 min ago'
  },
  {
    id: 'TKT-1845',
    title: 'Timeout error during loan calculation',
    user: 'Emily Chen',
    agent: 'Loan Calculator App',
    status: 'escalated',
    priority: 'high',
    created: '1 hour ago',
    updated: '15 min ago'
  },
  {
    id: 'TKT-1844',
    title: 'Unable to access account overview',
    user: 'Michael Brown',
    agent: 'Account Overview App',
    status: 'in_progress',
    priority: 'medium',
    created: '2 hours ago',
    updated: '30 min ago'
  },
  {
    id: 'TKT-1843',
    title: 'Feature request: Export conversation history',
    user: 'Lisa Anderson',
    agent: 'General Platform',
    status: 'open',
    priority: 'low',
    created: '3 hours ago',
    updated: '3 hours ago'
  }
];

export function SupportDashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');

  const filteredTickets = mockTickets.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ticket.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ticket.user.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || ticket.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-red-500 text-white border-red-500';
      case 'high':
        return 'bg-orange-500 text-white border-orange-500';
      case 'medium':
        return 'bg-yellow-500 text-white border-yellow-500';
      case 'low':
        return 'bg-green-500 text-white border-green-500';
      default:
        return '';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-500/10 text-blue-600 border-blue-200';
      case 'in_progress':
        return 'bg-purple-500/10 text-purple-600 border-purple-200';
      case 'resolved':
        return 'bg-green-500/10 text-green-600 border-green-200';
      case 'escalated':
        return 'bg-orange-500/10 text-orange-600 border-orange-200';
      default:
        return '';
    }
  };

  const formatStatus = (status: string) => {
    return status.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <div className="p-8 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-2xl mb-2">Support Dashboard</h1>
        <p className="text-muted-foreground">
          Monitor and resolve user-reported issues across all agents
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Open Tickets</p>
              <p className="text-3xl">24</p>
              <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                <TrendingDown className="w-3 h-3" />
                -8% from yesterday
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Ticket className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">In Progress</p>
              <p className="text-3xl">12</p>
              <p className="text-xs text-muted-foreground mt-2">
                Being handled
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Avg Response Time</p>
              <p className="text-3xl">8m</p>
              <p className="text-xs text-green-600 mt-2">
                Target: &lt;15 min
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Resolved Today</p>
              <p className="text-3xl">37</p>
              <p className="text-xs text-green-600 mt-2">
                98% satisfaction
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search tickets by ID, title, or user..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="escalated">Escalated</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Priorities" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Tickets Table */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg">Support Tickets</h2>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-200">
              3 Critical
            </Badge>
            <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-200">
              5 High
            </Badge>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Ticket ID</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Issue</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">User</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Agent</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Priority</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Created</th>
                <th className="text-left py-3 px-4 text-sm text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTickets.map((ticket) => (
                <tr key={ticket.id} className="border-b hover:bg-accent/50">
                  <td className="py-4 px-4">
                    <span className="font-mono text-sm">{ticket.id}</span>
                  </td>
                  <td className="py-4 px-4">
                    <p className="font-medium max-w-xs truncate">{ticket.title}</p>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="w-3 h-3 text-primary" />
                      </div>
                      <span className="text-sm">{ticket.user}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-sm text-muted-foreground">
                    {ticket.agent}
                  </td>
                  <td className="py-4 px-4">
                    <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                      {ticket.priority.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-4 px-4">
                    <Badge variant="outline" className={getStatusColor(ticket.status)}>
                      {formatStatus(ticket.status)}
                    </Badge>
                  </td>
                  <td className="py-4 px-4 text-sm text-muted-foreground">
                    {ticket.created}
                  </td>
                  <td className="py-4 px-4">
                    <Button variant="ghost" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTickets.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No tickets found matching your criteria</p>
          </div>
        )}
      </Card>

      {/* Common Issues */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-lg mb-6">Top Issues This Week</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Agent timeout errors</p>
                <p className="text-sm text-muted-foreground">Loan Calculator App</p>
              </div>
              <Badge>18 reports</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Incorrect data displayed</p>
                <p className="text-sm text-muted-foreground">Account Overview App</p>
              </div>
              <Badge>12 reports</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Authentication failures</p>
                <p className="text-sm text-muted-foreground">Multiple agents</p>
              </div>
              <Badge>9 reports</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Slow response times</p>
                <p className="text-sm text-muted-foreground">Investment Advisor App</p>
              </div>
              <Badge>7 reports</Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg mb-6">Team Performance</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">Alex Thompson</p>
                <p className="text-sm text-muted-foreground">Senior Support Engineer</p>
              </div>
              <div className="text-right">
                <p className="font-medium">24 resolved</p>
                <p className="text-sm text-green-600">4.9★ rating</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">Maria Garcia</p>
                <p className="text-sm text-muted-foreground">Support Engineer</p>
              </div>
              <div className="text-right">
                <p className="font-medium">19 resolved</p>
                <p className="text-sm text-green-600">4.8★ rating</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">David Kim</p>
                <p className="text-sm text-muted-foreground">Support Engineer</p>
              </div>
              <div className="text-right">
                <p className="font-medium">17 resolved</p>
                <p className="text-sm text-green-600">4.7★ rating</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}