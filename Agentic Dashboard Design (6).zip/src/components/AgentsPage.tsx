import { useState } from 'react';
import { Plus, Upload, Grid3x3, List, Search, Filter, Calendar as CalendarIcon, ChevronDown } from 'lucide-react';
import { AgentCard } from './AgentCard';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { CreateAgentDialog } from './CreateAgentDialog';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { format } from 'date-fns';

interface Agent {
  id: string;
  name: string;
  lastUpdated: string;
  description: string;
  status: 'draft' | 'published';
  category: string;
  tags: string[];
  stats: {
    versions: number;
    users: number;
    conversations: number;
    actions: number;
  };
  version?: string;
  goals?: {
    total: number;
    success: number;
    failed: number;
    in_progress: number;
    hitl?: number;
  };
  managerStats?: {
    totalUsers: number;
    activeUsers: number;
  };
}

const mockAgents: Agent[] = [
  {
    id: '1',
    name: 'Advisor App',
    lastUpdated: '7/18/2025',
    description: 'No description provided.',
    status: 'draft',
    category: 'Debt Collection',
    tags: ['Debt Collection'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 2 },
    version: '1.2.0',
    goals: { total: 12, success: 8, failed: 1, in_progress: 3, hitl: 2 },
    managerStats: { totalUsers: 156, activeUsers: 128 }
  },
  {
    id: '2',
    name: 'Banking Payments App',
    lastUpdated: '7/24/2025',
    description: 'Banking agent specialized in person-to-person payments',
    status: 'draft',
    category: 'Uncategorized',
    tags: ['Uncategorized'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 },
    version: '2.0.1',
    goals: { total: 45, success: 38, failed: 3, in_progress: 4, hitl: 3 },
    managerStats: { totalUsers: 342, activeUsers: 289 }
  },
  {
    id: '3',
    name: 'Transaction Analysis App',
    lastUpdated: '7/18/2025',
    description: 'Banking agent specialized in transaction history and spending analysis',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 0 },
    version: '1.5.2',
    goals: { total: 28, success: 22, failed: 2, in_progress: 4, hitl: 1 },
    managerStats: { totalUsers: 234, activeUsers: 198 }
  },
  {
    id: '4',
    name: 'Banking Transfers App',
    lastUpdated: '7/18/2025',
    description: 'Banking agent specialized in account-to-account transfers',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 0 },
    version: '3.1.0',
    goals: { total: 67, success: 58, failed: 5, in_progress: 4, hitl: 4 },
    managerStats: { totalUsers: 456, activeUsers: 398 }
  },
  {
    id: '5',
    name: 'Account Opening App',
    lastUpdated: '7/18/2025',
    description: 'Banking specialist focused on opening new customer accounts',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 0 },
    version: '1.0.5',
    goals: { total: 15, success: 10, failed: 3, in_progress: 2, hitl: 1 },
    managerStats: { totalUsers: 198, activeUsers: 145 }
  },
  {
    id: '6',
    name: 'Savings Accounts App',
    lastUpdated: '7/18/2025',
    description: 'Banking specialist focused on savings account products and queries',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 },
    version: '2.3.1',
    goals: { total: 34, success: 29, failed: 2, in_progress: 3, hitl: 2 },
    managerStats: { totalUsers: 267, activeUsers: 223 }
  },
  {
    id: '7',
    name: 'Chat/Digital App',
    lastUpdated: '7/18/2025',
    description: 'No description provided.',
    status: 'draft',
    category: 'Debt Collection',
    tags: ['Debt Collection'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 2 },
    version: '1.8.0',
    goals: { total: 23, success: 18, failed: 2, in_progress: 3, hitl: 1 },
    managerStats: { totalUsers: 189, activeUsers: 156 }
  },
  {
    id: '8',
    name: 'Customer Service App',
    lastUpdated: '7/9/2025',
    description: 'General customer service agent for banking inquiries',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 },
    version: '4.2.0',
    goals: { total: 89, success: 76, failed: 6, in_progress: 7, hitl: 5 },
    managerStats: { totalUsers: 512, activeUsers: 445 }
  },
  {
    id: '9',
    name: 'Excite Digital App',
    lastUpdated: '7/7/2025',
    description: 'No description provided.',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 },
    version: '1.1.0',
    goals: { total: 18, success: 14, failed: 1, in_progress: 3, hitl: 0 },
    managerStats: { totalUsers: 145, activeUsers: 112 }
  },
  {
    id: '10',
    name: 'Retirement Planning App',
    lastUpdated: '7/28/2025',
    description: 'Financial advisor specialized in retirement planning and investment strategies',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 },
    version: '2.1.3',
    goals: { total: 52, success: 43, failed: 4, in_progress: 5, hitl: 0 },
    managerStats: { totalUsers: 321, activeUsers: 278 }
  },
  {
    id: '11',
    name: 'Risk Assessment App',
    lastUpdated: '7/18/2025',
    description: 'Financial advisor for risk assessment and portfolio analysis',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 },
    version: '1.4.2',
    goals: { total: 31, success: 25, failed: 3, in_progress: 3, hitl: 0 },
    managerStats: { totalUsers: 213, activeUsers: 189 }
  }
];

interface AgentsPageProps {
  onAgentSelect: (agentId: string, tab?: string) => void;
}

export function AgentsPage({ onAgentSelect }: AgentsPageProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filter, setFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [agents, setAgents] = useState(mockAgents);
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: new Date(2025, 10, 1),
    to: new Date(2025, 10, 10)
  });

  const handleCreateAgent = (newAgent: any) => {
    const agent = {
      id: Date.now().toString(),
      name: newAgent.name,
      lastUpdated: new Date().toLocaleDateString(),
      description: newAgent.description,
      status: 'draft' as const,
      category: newAgent.category,
      tags: [newAgent.category],
      stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
    };
    setAgents([agent, ...agents]);
  };

  const handleDeleteAgent = (id: string) => {
    if (confirm('Are you sure you want to delete this app?')) {
      setAgents(agents.filter(a => a.id !== id));
    }
  };

  const handleDuplicateAgent = (id: string) => {
    const agent = agents.find(a => a.id === id);
    if (agent) {
      const duplicated = {
        ...agent,
        id: Date.now().toString(),
        name: `${agent.name} (Copy)`,
        lastUpdated: new Date().toLocaleDateString(),
      };
      setAgents([duplicated, ...agents]);
    }
  };

  const filteredAgents = agents.filter(agent => {
    if (filter !== 'all' && agent.status !== filter) return false;
    if (categoryFilter !== 'all' && !agent.tags.includes(categoryFilter)) return false;
    if (searchQuery && !agent.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Create and manage AI apps for your organization</p>
        </div>
        <div className="flex gap-3">
          {/* Line of Business Dropdown - Greyed Out */}
          <Button variant="outline" disabled className="opacity-60 cursor-not-allowed">
            DTI
            <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
          
          {/* Date Range Picker */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-[280px] justify-start">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange.from && dateRange.to ? (
                  <>
                    {format(dateRange.from, 'MMM dd, yyyy')} - {format(dateRange.to, 'MMM dd, yyyy')}
                  </>
                ) : (
                  <span>Pick a date range</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="single"
                selected={dateRange.from}
                onSelect={(date) => setDateRange({ ...dateRange, from: date })}
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant={categoryFilter === 'all' ? 'default' : 'ghost'}
            onClick={() => setCategoryFilter('all')}
            size="sm"
          >
            All Categories
          </Button>
          <Button
            variant={categoryFilter === 'Banking' ? 'default' : 'ghost'}
            onClick={() => setCategoryFilter('Banking')}
            size="sm"
          >
            Banking
          </Button>
          <Button
            variant={categoryFilter === 'Debt Collection' ? 'default' : 'ghost'}
            onClick={() => setCategoryFilter('Debt Collection')}
            size="sm"
          >
            Debt Collection
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center border rounded-md">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-accent' : 'hover:bg-accent/50'}`}
            >
              <Grid3x3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-accent' : 'hover:bg-accent/50'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search apps..."
              className="pl-9 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Apps Count */}
      <div className="mb-4">
        <p className="text-sm text-muted-foreground">
          Showing {filteredAgents.length} of {agents.length} apps
        </p>
      </div>

      {/* Apps Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAgents.map(agent => (
          <AgentCard 
            key={agent.id} 
            agent={agent} 
            onSelect={() => onAgentSelect(agent.id, 'overview')}
            onViewDetails={() => onAgentSelect(agent.id, 'overview')}
            onExecute={() => onAgentSelect(agent.id, 'chat')}
            onViewHistory={() => onAgentSelect(agent.id, 'history')}
            onDelete={handleDeleteAgent}
            onDuplicate={handleDuplicateAgent}
          />
        ))}
      </div>

      {filteredAgents.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No apps found</p>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Your First App
          </Button>
        </div>
      )}

      <CreateAgentDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onCreate={handleCreateAgent}
      />
    </div>
  );
}