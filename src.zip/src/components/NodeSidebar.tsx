import { 
  Play, 
  GitBranch, 
  Database, 
  MessageSquare, 
  Code,
  Zap,
  CheckCircle,
  Settings,
  Layout,
  Boxes
} from 'lucide-react';
import { Button } from './ui/button';

interface NodeSidebarProps {
  onAddNode: (type: 'start' | 'end' | 'conditional' | 'action' | 'setVariable') => void;
}

export function NodeSidebar({ onAddNode }: NodeSidebarProps) {
  const nodeTypes = [
    { 
      type: 'start' as const, 
      icon: Play, 
      label: 'Start', 
      color: 'text-green-500',
      description: 'Workflow entry point'
    },
    { 
      type: 'conditional' as const, 
      icon: GitBranch, 
      label: 'Conditional', 
      color: 'text-orange-500',
      description: 'Branch logic'
    },
    { 
      type: 'action' as const, 
      icon: Zap, 
      label: 'Action', 
      color: 'text-blue-500',
      description: 'Execute task'
    },
    { 
      type: 'setVariable' as const, 
      icon: Database, 
      label: 'Set Variable', 
      color: 'text-blue-400',
      description: 'Store data'
    },
    { 
      type: 'end' as const, 
      icon: CheckCircle, 
      label: 'End', 
      color: 'text-red-500',
      description: 'Workflow exit'
    },
  ];

  const tools = [
    { icon: Layout, label: 'Canvas', active: false },
    { icon: GitBranch, label: 'Workflows', active: true },
    { icon: Boxes, label: 'Templates', active: false },
    { icon: Settings, label: 'Settings', active: false },
  ];

  return (
    <div className="w-16 border-r bg-card flex flex-col items-center py-4 gap-2">
      {/* Tools */}
      <div className="space-y-2 pb-4 border-b w-full flex flex-col items-center">
        {tools.map((tool, idx) => {
          const Icon = tool.icon;
          return (
            <button
              key={idx}
              className={`w-10 h-10 rounded-md flex items-center justify-center transition-colors ${
                tool.active 
                  ? 'bg-accent text-accent-foreground' 
                  : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
              }`}
              title={tool.label}
            >
              <Icon className="w-4 h-4" />
            </button>
          );
        })}
      </div>

      {/* Node Types */}
      <div className="flex-1 space-y-2 pt-4 w-full flex flex-col items-center">
        {nodeTypes.map((nodeType) => {
          const Icon = nodeType.icon;
          return (
            <button
              key={nodeType.type}
              onClick={() => onAddNode(nodeType.type)}
              className={`w-10 h-10 rounded-md flex items-center justify-center transition-colors hover:bg-accent group relative ${nodeType.color}`}
              title={nodeType.label}
            >
              <Icon className="w-4 h-4" />
              
              {/* Tooltip */}
              <div className="absolute left-full ml-2 px-3 py-2 bg-popover border rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all whitespace-nowrap z-50">
                <div className="text-sm font-medium mb-0.5">{nodeType.label}</div>
                <div className="text-xs text-muted-foreground">{nodeType.description}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
