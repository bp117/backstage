import { useCallback } from 'react';
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Background,
  Controls,
  MiniMap,
  Handle,
  Position,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { User, Bot, Server, Database, Cloud } from 'lucide-react';
import { Badge } from './ui/badge';

const CustomNode = ({ data }: any) => {
  const getIcon = () => {
    switch (data.icon) {
      case 'user':
        return <User className="w-6 h-6" />;
      case 'agent':
        return <Bot className="w-6 h-6" />;
      case 'mcp':
        return <Server className="w-6 h-6" />;
      case 'database':
        return <Database className="w-6 h-6" />;
      case 'api':
        return <Cloud className="w-6 h-6" />;
      default:
        return <Bot className="w-6 h-6" />;
    }
  };

  return (
    <div className="px-4 py-3 border-2 rounded-lg bg-white shadow-lg" style={{ minWidth: '180px', borderColor: data.borderColor || '#000' }}>
      <Handle type="target" position={Position.Left} />
      <div className="flex items-center gap-2 mb-1">
        {getIcon()}
        <div className="font-medium text-sm">{data.label}</div>
      </div>
      {data.description && (
        <div className="text-xs text-gray-600 mt-1">{data.description}</div>
      )}
      {data.metrics && (
        <div className="mt-2 pt-2 border-t text-xs space-y-1">
          <div>Requests: <span className="font-medium">{data.metrics.requests}</span></div>
          <div>Latency: <span className="font-medium">{data.metrics.latency}</span></div>
        </div>
      )}
      <Handle type="source" position={Position.Right} />
    </div>
  );
};

const nodeTypes = {
  custom: CustomNode,
};

const initialNodes: Node[] = [
  {
    id: '1',
    type: 'custom',
    position: { x: 50, y: 200 },
    data: {
      label: 'User Interface',
      icon: 'user',
      description: 'Web & Mobile',
      borderColor: '#3b82f6',
      metrics: { requests: 1247, latency: '45ms' }
    },
  },
  {
    id: '2',
    type: 'custom',
    position: { x: 350, y: 200 },
    data: {
      label: 'Financial Agent',
      icon: 'agent',
      description: 'GPT-4 Powered',
      borderColor: '#10b981',
      metrics: { requests: 1189, latency: '850ms' }
    },
  },
  {
    id: '3',
    type: 'custom',
    position: { x: 650, y: 50 },
    data: {
      label: 'MCP Server',
      icon: 'mcp',
      description: 'Model Context Protocol',
      borderColor: '#8b5cf6',
      metrics: { requests: 456, latency: '120ms' }
    },
  },
  {
    id: '4',
    type: 'custom',
    position: { x: 650, y: 350 },
    data: {
      label: 'Knowledge Base',
      icon: 'database',
      description: 'Vector DB',
      borderColor: '#f59e0b',
      metrics: { requests: 892, latency: '12ms' }
    },
  },
  {
    id: '5',
    type: 'custom',
    position: { x: 950, y: 200 },
    data: {
      label: 'External APIs',
      icon: 'api',
      description: 'Market Data',
      borderColor: '#ec4899',
      metrics: { requests: 234, latency: '340ms' }
    },
  },
];

const initialEdges: Edge[] = [
  {
    id: 'e1-2',
    source: '1',
    target: '2',
    animated: true,
    style: { strokeWidth: 4, stroke: '#3b82f6' },
    label: 'User Traffic',
    labelStyle: { fill: '#3b82f6', fontWeight: 700 },
  },
  {
    id: 'e2-3',
    source: '2',
    target: '3',
    animated: true,
    style: { strokeWidth: 4, stroke: '#10b981' },
    label: 'Context',
    labelStyle: { fill: '#10b981', fontWeight: 700 },
  },
  {
    id: 'e2-4',
    source: '2',
    target: '4',
    animated: true,
    style: { strokeWidth: 4, stroke: '#8b5cf6' },
    label: 'Query',
    labelStyle: { fill: '#8b5cf6', fontWeight: 700 },
  },
  {
    id: 'e3-5',
    source: '3',
    target: '5',
    animated: true,
    style: { strokeWidth: 4, stroke: '#f59e0b' },
    label: 'Tools',
    labelStyle: { fill: '#f59e0b', fontWeight: 700 },
  },
  {
    id: 'e4-5',
    source: '4',
    target: '5',
    animated: true,
    style: { strokeWidth: 4, stroke: '#ec4899' },
    label: 'Cache',
    labelStyle: { fill: '#ec4899', fontWeight: 700 },
  },
];

export function AgentFlowGraph() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  return (
    <div className="h-full w-full">
      <div className="mb-4">
        <h3 className="text-lg font-medium mb-1">Agent Architecture</h3>
        <p className="text-sm text-muted-foreground">Real-time data flow and system status</p>
        <Badge variant="outline" className="mt-2">Live Traffic</Badge>
      </div>
      
      <div style={{ height: '600px', width: '100%', border: '1px solid #e5e7eb', borderRadius: '8px', backgroundColor: '#fafafa' }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          fitView
          attributionPosition="bottom-right"
        >
          <Background color="#aaa" gap={16} />
          <Controls />
          <MiniMap />
        </ReactFlow>
      </div>

      {/* Legend */}
      <div className="mt-4 flex items-center gap-4 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-blue-600"></div>
          <span>User Traffic</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-green-600"></div>
          <span>Context</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-purple-600"></div>
          <span>Query</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-orange-600"></div>
          <span>Tools</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-pink-600"></div>
          <span>Cache</span>
        </div>
      </div>
    </div>
  );
}
