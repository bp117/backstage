import { useState } from 'react';
import { Send, Mic, Settings, X, Maximize2, User, Bot } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface Message {
  id: string;
  role: 'user' | 'agent';
  content: string;
  timestamp: string;
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'user',
      content: "I'd like to review investment products and get recommendations based on my retirement goals",
      timestamp: '9:30 AM'
    },
    {
      id: '2',
      role: 'agent',
      content: `Sure, I'd be happy to help with that. However, in order to provide you with the most relevant advice, I'll need a bit more information:

1. What is your current age and when do you plan on retiring?
2. Could you please describe your risk tolerance? (High, Medium or Low)
3. What is your current financial situation? (income level, savings)
4. Do you have any existing retirement accounts? If so, what type?
5. Do you have a specific retirement goal in mind?

Please provide as much detail as possible so I can give you personalized advice for your situation.`,
      timestamp: '9:30 AM'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [showLogPanel, setShowLogPanel] = useState(true);
  const [logTab, setLogTab] = useState<'detail' | 'tracing'>('detail');

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    };

    setMessages([...messages, newMessage]);
    setInputValue('');

    // Simulate agent response with typing indicator
    setTimeout(() => {
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'agent',
        content: "Thank you for your query. I'm analyzing your requirements and will provide personalized recommendations based on your retirement goals.",
        timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
      };
      setMessages(prev => [...prev, agentMessage]);
    }, 1000);
  };

  const handleClearChat = () => {
    if (confirm('Are you sure you want to clear the chat history?')) {
      setMessages([]);
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        {/* Chat Header */}
        <div className="border-b px-6 py-4 bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg">Test Conversation</h2>
              <p className="text-sm text-muted-foreground">Model: gpt-4</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Parameters
              </Button>
              <Button variant="ghost" size="sm" onClick={handleClearChat}>
                Clear Chat
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'agent' && (
                <div className="w-8 h-8 rounded-md border bg-muted flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div className={`max-w-2xl ${message.role === 'user' ? 'order-first' : ''}`}>
                <div
                  className={`rounded-lg px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-foreground text-background ml-auto'
                      : 'border bg-card'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 px-1">{message.timestamp}</p>
              </div>
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-md border bg-muted flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Input Area */}
        <div className="border-t p-4 bg-card">
          <div className="flex items-center gap-3">
            <div className="flex-1 relative">
              <Input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type a message to test the agent..."
                className="pr-10"
              />
              <button className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-accent rounded transition-colors">
                <Mic className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
            <Button onClick={handleSend} size="icon">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Log Panel */}
      {showLogPanel && (
        <div className="w-96 border-l bg-card flex flex-col">
          {/* Log Header */}
          <div className="px-4 py-3 border-b flex items-center justify-between">
            <h3>Execution Logs</h3>
            <Button 
              variant="ghost"
              size="icon"
              onClick={() => setShowLogPanel(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Log Tabs */}
          <div className="flex border-b">
            <button
              onClick={() => setLogTab('detail')}
              className={`flex-1 px-4 py-2 text-sm ${
                logTab === 'detail' 
                  ? 'border-b-2 border-foreground' 
                  : 'text-muted-foreground'
              }`}
            >
              Detail
            </button>
            <button
              onClick={() => setLogTab('tracing')}
              className={`flex-1 px-4 py-2 text-sm ${
                logTab === 'tracing' 
                  ? 'border-b-2 border-foreground' 
                  : 'text-muted-foreground'
              }`}
            >
              Tracing
            </button>
          </div>

          {/* Log Content */}
          <div className="flex-1 overflow-auto p-4">
            {logTab === 'detail' && (
              <div className="space-y-4">
                {/* Status */}
                <div>
                  <div className="text-xs text-muted-foreground mb-2">STATUS</div>
                  <Badge variant="outline" className="text-green-600 border-green-600/30">
                    SUCCESS
                  </Badge>
                </div>

                {/* Time Stats */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Elapsed Time</span>
                    <span>1.2s</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Total Tokens</span>
                    <span>245</span>
                  </div>
                </div>

                {/* Input */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">INPUT</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <Maximize2 className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="bg-muted rounded-md p-3 text-xs font-mono">
                    <pre className="whitespace-pre-wrap">
{`{ "request": { "business_id": "BUSINESS1" },
  "query": "I'd like to review investment products..." }`}
                    </pre>
                  </div>
                </div>

                {/* Output */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">OUTPUT</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <Maximize2 className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="bg-muted rounded-md p-3 text-xs font-mono max-h-64 overflow-auto">
                    <pre className="whitespace-pre-wrap">
{`"Sure, I'd be happy to help with that. However, in order to provide you with the most relevant advice..."`}
                    </pre>
                  </div>
                </div>

                {/* Metadata */}
                <div>
                  <div className="text-xs text-muted-foreground mb-2">METADATA</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Executor</span>
                      <span className="text-xs">financial_advisor</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Start Time</span>
                      <span className="text-xs">7/28/2025, 9:30 PM</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {logTab === 'tracing' && (
              <div className="text-sm text-muted-foreground text-center py-8">
                Tracing data will appear here
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}