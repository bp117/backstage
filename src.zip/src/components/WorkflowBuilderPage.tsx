import { useState } from 'react';
import { 
  ArrowLeft, 
  Save, 
  Play, 
  Settings, 
  Plus,
  Zap,
  GitBranch,
  Database,
  MessageSquare,
  Code,
  CheckCircle,
  XCircle,
  Circle,
  MoreVertical
} from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { WorkflowCanvas } from './WorkflowCanvas';

interface WorkflowBuilderPageProps {
  onBack: () => void;
}

export function WorkflowBuilderPage({ onBack }: WorkflowBuilderPageProps) {
  const [activeTab, setActiveTab] = useState('design');
  const [workflowName] = useState('Account Creation');
  const [isSaved, setIsSaved] = useState(true);

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'design', label: 'Workflow Design' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'history', label: 'History' },
    { id: 'export', label: 'Export' },
  ];

  const handleSave = () => {
    setIsSaved(true);
    // Save workflow logic
  };

  const handleRun = () => {
    // Run workflow logic
    console.log('Running workflow...');
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="border-b bg-card px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost"
              size="icon"
              onClick={onBack}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-blue-600 flex items-center justify-center">
                <GitBranch className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl">{workflowName}</h1>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Circle className="w-3 h-3 fill-current" />
                    <span>2</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    <span>8k</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    Draft
                  </Badge>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {!isSaved && (
              <span className="text-xs text-muted-foreground">Unsaved changes</span>
            )}
            <Button 
              variant="default" 
              size="sm"
              onClick={handleSave}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
            <Button 
              variant="default" 
              size="sm"
              onClick={handleRun}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Play className="w-4 h-4 mr-2" />
              Run Workflow
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b bg-card">
        <div className="flex items-center px-6">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-3 text-sm border-b-2 transition-colors ${
                activeTab === tab.id 
                  ? 'border-blue-500 text-foreground' 
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'design' && (
        <WorkflowCanvas onWorkflowChange={() => setIsSaved(false)} />
      )}
      
      {activeTab !== 'design' && (
        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-4xl">
            <div className="border rounded-lg p-12 text-center bg-card">
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 rounded-full border-2 border-dashed flex items-center justify-center">
                  <GitBranch className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
              <h3 className="text-xl mb-2">{tabs.find(t => t.id === activeTab)?.label}</h3>
              <p className="text-muted-foreground">This section is under construction</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
