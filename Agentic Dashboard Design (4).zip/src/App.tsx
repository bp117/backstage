import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { AgentsPage } from './components/AgentsPage';
import { DashboardPage } from './components/DashboardPage';
import { AgentDetailPage } from './components/AgentDetailPage';
import { WorkflowBuilderPage } from './components/WorkflowBuilderPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'agents' | 'agent-detail' | 'workflows'>('dashboard');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);

  const handleAgentSelect = (agentId: string) => {
    setSelectedAgentId(agentId);
    setCurrentPage('agent-detail');
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      {currentPage !== 'workflows' && (
        <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      )}
      <main className="flex-1 overflow-auto">
        {currentPage === 'dashboard' && <DashboardPage onCreateWorkflow={() => setCurrentPage('workflows')} />}
        {currentPage === 'agents' && <AgentsPage onAgentSelect={handleAgentSelect} />}
        {currentPage === 'agent-detail' && selectedAgentId && (
          <AgentDetailPage agentId={selectedAgentId} onBack={() => setCurrentPage('agents')} />
        )}
        {currentPage === 'workflows' && (
          <WorkflowBuilderPage onBack={() => setCurrentPage('dashboard')} />
        )}
      </main>
    </div>
  );
}