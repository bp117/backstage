import { Shield, Users, MessageSquare, Zap, MoreVertical, Play, Trash2, Copy, Edit, TrendingUp, Eye, AlertCircle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { useState } from 'react';
import { ReportProblemDialog } from './ReportProblemDialog';

interface Agent {
  id: string;
  name: string;
  lastUpdated: string;
  description: string;
  status: 'draft' | 'published';
  category: string;
  tags: string[];
  stats: {
    versions: number;
    users: number;
    conversations: number;
    actions: number;
  };
  version?: string;
  goals?: {
    total: number;
    success: number;
    failed: number;
    in_progress: number;
  };
}

interface AgentCardProps {
  agent: Agent;
  onSelect: () => void;
  onViewDetails: () => void;
  onExecute: () => void;
  onViewHistory: () => void;
  onDelete?: (id: string) => void;
  onDuplicate?: (id: string) => void;
}

export function AgentCard({ agent, onSelect, onViewDetails, onExecute, onViewHistory, onDelete, onDuplicate }: AgentCardProps) {
  const [showReportDialog, setShowReportDialog] = useState(false);
  
  const handleAction = (e: React.MouseEvent, action: () => void) => {
    e.stopPropagation();
    action();
  };

  const goals = agent.goals || { total: 0, success: 0, failed: 0, in_progress: 0 };

  return (
    <>
      <div 
        className="border rounded-lg p-5 bg-card hover:shadow-lg transition-all cursor-pointer group relative"
        onClick={onSelect}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-9 h-9 rounded-md border bg-muted/50 flex items-center justify-center flex-shrink-0">
                <MessageSquare className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-medium group-hover:text-primary transition-colors truncate">
                  {agent.name}
                </h3>
                <p className="text-xs text-muted-foreground">
                  v{agent.version || '1.0.0'}
                </p>
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 flex-shrink-0" 
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="z-[9999] !bg-white dark:!bg-gray-800 !border !shadow-lg" style={{ position: 'relative' }}>
              <DropdownMenuItem onClick={(e) => handleAction(e as any, onViewDetails)}>
                <Eye className="w-4 h-4 mr-2" />
                View Details
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => handleAction(e as any, () => setShowReportDialog(true))}>
                <AlertCircle className="w-4 h-4 mr-2" />
                Report Problem
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2 min-h-[40px]">
          {agent.description || 'No description provided.'}
        </p>

        {/* Goals Stats */}
        <div className="space-y-3 mb-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Total Goals</span>
            <button 
              className="font-medium hover:underline"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              {goals.total}
            </button>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-green-600" />
              <span className="text-muted-foreground">Success</span>
            </div>
            <button 
              className="font-medium text-green-600 hover:underline"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              {goals.success}
            </button>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <XCircle className="w-3.5 h-3.5 text-red-600" />
              <span className="text-muted-foreground">Failed</span>
            </div>
            <button 
              className="font-medium text-red-600 hover:underline"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              {goals.failed}
            </button>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-orange-600" />
              <span className="text-muted-foreground">In Progress</span>
            </div>
            <button 
              className="font-medium text-orange-600 hover:underline"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              {goals.in_progress}
            </button>
          </div>
        </div>

        {/* Execute button - always visible */}
        <div>
          <Button 
            size="sm" 
            onClick={(e) => {
              e.stopPropagation();
              onExecute();
            }}
            className="w-full"
          >
            <Play className="w-3 h-3 mr-1.5" />
            Execute
          </Button>
        </div>
      </div>

      <ReportProblemDialog 
        open={showReportDialog}
        onClose={() => setShowReportDialog(false)}
        appName={agent.name}
      />
    </>
  );
}