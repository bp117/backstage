import { useState } from 'react';
import { 
  TrendingUp, 
  Activity, 
  CheckCircle2,
  Clock,
  MessageSquare,
  BarChart3,
  Calendar,
  Search,
  Filter,
  Users,
  UserCheck
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface AppMetric {
  id: string;
  name: string;
  category: string;
  usageCount: number;
  lastUsed: string;
  status: 'active' | 'idle';
  satisfaction: number;
  totalUsers: number;
  activeUsers: number;
}

const mockApps: AppMetric[] = [
  {
    id: '1',
    name: 'Retirement Planning App',
    category: 'Financial Planning',
    usageCount: 47,
    lastUsed: '2 hours ago',
    status: 'active',
    satisfaction: 4.8,
    totalUsers: 342,
    activeUsers: 278
  },
  {
    id: '2',
    name: 'Investment Advisor App',
    category: 'Investments',
    usageCount: 32,
    lastUsed: '5 hours ago',
    status: 'active',
    satisfaction: 4.6,
    totalUsers: 289,
    activeUsers: 231
  },
  {
    id: '3',
    name: 'Account Overview App',
    category: 'Banking',
    usageCount: 89,
    lastUsed: '1 hour ago',
    status: 'active',
    satisfaction: 4.9,
    totalUsers: 456,
    activeUsers: 398
  },
  {
    id: '4',
    name: 'Loan Calculator App',
    category: 'Banking',
    usageCount: 15,
    lastUsed: '1 day ago',
    status: 'idle',
    satisfaction: 4.5,
    totalUsers: 198,
    activeUsers: 145
  }
];

export function ManagerDashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const filteredApps = mockApps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || app.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const totalInteractions = mockApps.reduce((sum, app) => sum + app.usageCount, 0);
  const activeApps = mockApps.filter(app => app.status === 'active').length;
  const avgSatisfaction = (mockApps.reduce((sum, app) => sum + app.satisfaction, 0) / mockApps.length).toFixed(1);
  const totalUsers = mockApps.reduce((sum, app) => sum + app.totalUsers, 0);
  const totalActiveUsers = mockApps.reduce((sum, app) => sum + app.activeUsers, 0);

  return (
    <div className="p-8 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-2xl mb-2">Manager Dashboard - Team Apps Overview</h1>
        <p className="text-muted-foreground">
          Track app usage, user adoption, and team performance metrics
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Interactions</p>
              <p className="text-3xl">{totalInteractions}</p>
              <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +12% from last week
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Active Apps</p>
              <p className="text-3xl">{activeApps}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Out of {mockApps.length} total
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Users</p>
              <p className="text-3xl">{totalUsers}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Across all apps
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Active Users</p>
              <p className="text-3xl">{totalActiveUsers}</p>
              <p className="text-xs text-green-600 mt-2">
                {((totalActiveUsers / totalUsers) * 100).toFixed(0)}% adoption
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-teal-500/10 flex items-center justify-center">
              <UserCheck className="w-5 h-5 text-teal-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Avg Satisfaction</p>
              <p className="text-3xl">{avgSatisfaction}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Out of 5.0
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters and Search */}
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search apps..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[200px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Financial Planning">Financial Planning</SelectItem>
            <SelectItem value="Investments">Investments</SelectItem>
            <SelectItem value="Banking">Banking</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Apps Table */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg">Team Apps</h2>
            <Button variant="outline" size="sm">
              <Calendar className="w-4 h-4 mr-2" />
              Last 30 Days
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">App Name</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Category</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Total Users</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Active Users</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Usage Count</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Last Used</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Status</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Satisfaction</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredApps.map((app) => (
                  <tr key={app.id} className="border-b hover:bg-accent/50">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
                          <BarChart3 className="w-4 h-4 text-primary" />
                        </div>
                        <span className="font-medium">{app.name}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Badge variant="outline">{app.category}</Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{app.totalUsers}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <UserCheck className="w-4 h-4 text-green-600" />
                        <span className="font-medium text-green-600">{app.activeUsers}</span>
                        <span className="text-xs text-muted-foreground">
                          ({((app.activeUsers / app.totalUsers) * 100).toFixed(0)}%)
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="font-medium">{app.usageCount}</span>
                    </td>
                    <td className="py-4 px-4 text-muted-foreground">
                      {app.lastUsed}
                    </td>
                    <td className="py-4 px-4">
                      <Badge 
                        variant={app.status === 'active' ? 'default' : 'secondary'}
                        className={app.status === 'active' ? 'bg-green-500' : ''}
                      >
                        {app.status}
                      </Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{app.satisfaction}</span>
                        <span className="text-muted-foreground text-sm">/5.0</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Button variant="ghost" size="sm">
                        View Analytics
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredApps.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No apps found matching your criteria</p>
            </div>
          )}
        </div>
      </Card>

      {/* User Adoption Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium mb-1">User Engagement Trend</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Active user ratio has increased by 8% this month
              </p>
              <Button size="sm" variant="outline">
                View Detailed Report
              </Button>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
              <BarChart3 className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium mb-1">Top Performing App</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Account Overview App leads with 87% active user rate
              </p>
              <Button size="sm" variant="outline">
                View App Details
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Note about chat being disabled */}
      <Card className="p-6 bg-muted/30 border-dashed">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center flex-shrink-0">
            <MessageSquare className="w-5 h-5 text-orange-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-medium mb-1">Manager View - Read Only</h3>
            <p className="text-sm text-muted-foreground">
              As a manager, you have read-only access to view team app analytics and user metrics. Chat functionality is disabled for this role. To test apps, please switch to the Consumer persona.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
