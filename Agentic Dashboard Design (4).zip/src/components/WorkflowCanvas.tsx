import { useState, useRef, useCallback } from 'react';
import { Plus, Maximize2, Minimize2, ZoomIn, ZoomOut } from 'lucide-react';
import { Button } from './ui/button';
import { WorkflowNode } from './WorkflowNode';
import { NodeSidebar } from './NodeSidebar';

interface Node {
  id: string;
  type: 'start' | 'end' | 'conditional' | 'action' | 'setVariable';
  position: { x: number; y: number };
  data: {
    label: string;
    description?: string;
    inputs?: string[];
    outputs?: string[];
    config?: any;
  };
}

interface Connection {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

const initialNodes: Node[] = [
  {
    id: 'start-1',
    type: 'start',
    position: { x: 100, y: 200 },
    data: {
      label: 'Start Account Creation',
      description: 'Begin workflow',
      inputs: [
        'account_type (string)',
        'first_name (string)',
        'last_name (string)',
        'email (string)',
        'date_of_birth (date)',
        'ssn (string)',
        'address (string)',
        'phone (string)',
        'initial_deposit (number)'
      ]
    }
  },
  {
    id: 'conditional-1',
    type: 'conditional',
    position: { x: 350, y: 150 },
    data: {
      label: 'Identity Validation',
      description: 'Basic identity validation passed',
      outputs: ['name (string)', 'valid (boolean)']
    }
  },
  {
    id: 'conditional-2',
    type: 'conditional',
    position: { x: 550, y: 150 },
    data: {
      label: 'Check Initial Deposit',
      description: 'Checking account minimum deposit met',
      outputs: ['account_type != "checking" or...']
    }
  },
  {
    id: 'action-1',
    type: 'setVariable',
    position: { x: 650, y: 100 },
    data: {
      label: 'Create Checking Account',
      description: 'Set variables for account',
      outputs: [
        'DONE (nothing, over)',
        'date_opened (date)'
      ]
    }
  },
  {
    id: 'action-2',
    type: 'setVariable',
    position: { x: 650, y: 220 },
    data: {
      label: 'Create Savings Account',
      description: 'Set account details',
      outputs: [
        'API_KEY: premium_ban...',
        'account_type',
        'premium_fee'
      ]
    }
  },
  {
    id: 'action-3',
    type: 'setVariable',
    position: { x: 650, y: 340 },
    data: {
      label: 'Create Premium Account',
      description: 'Premium account setup',
      outputs: [
        'API_KEY: premium_ban...',
        'account_number',
        'premium_tier'
      ]
    }
  },
  {
    id: 'end-1',
    type: 'end',
    position: { x: 850, y: 200 },
    data: {
      label: 'End Account Creation',
      description: 'Workflow complete'
    }
  }
];

const initialConnections: Connection[] = [
  { id: 'c1', source: 'start-1', target: 'conditional-1' },
  { id: 'c2', source: 'conditional-1', target: 'conditional-2' },
  { id: 'c3', source: 'conditional-2', target: 'action-1' },
  { id: 'c4', source: 'conditional-2', target: 'action-2' },
  { id: 'c5', source: 'conditional-2', target: 'action-3' },
  { id: 'c6', source: 'action-1', target: 'end-1' },
  { id: 'c7', source: 'action-2', target: 'end-1' },
  { id: 'c8', source: 'action-3', target: 'end-1' },
];

interface WorkflowCanvasProps {
  onWorkflowChange: () => void;
}

export function WorkflowCanvas({ onWorkflowChange }: WorkflowCanvasProps) {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [connections, setConnections] = useState<Connection[]>(initialConnections);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [showMinimap, setShowMinimap] = useState(true);
  const [zoom, setZoom] = useState(1);
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleNodeClick = (nodeId: string) => {
    setSelectedNode(nodeId === selectedNode ? null : nodeId);
  };

  const handleAddNode = (type: Node['type']) => {
    const newNode: Node = {
      id: `${type}-${Date.now()}`,
      type,
      position: { x: 400, y: 300 },
      data: {
        label: `New ${type} node`,
        description: 'Configure this node'
      }
    };
    setNodes([...nodes, newNode]);
    onWorkflowChange();
  };

  const handleDeleteNode = (nodeId: string) => {
    setNodes(nodes.filter(n => n.id !== nodeId));
    setConnections(connections.filter(c => c.source !== nodeId && c.target !== nodeId));
    setSelectedNode(null);
    onWorkflowChange();
  };

  const handleNodePositionChange = (nodeId: string, position: { x: number; y: number }) => {
    setNodes(nodes.map(n => n.id === nodeId ? { ...n, position } : n));
    onWorkflowChange();
  };

  const zoomIn = () => setZoom(Math.min(zoom + 0.1, 2));
  const zoomOut = () => setZoom(Math.max(zoom - 0.1, 0.5));

  // Calculate connection paths
  const getConnectionPath = (source: Node, target: Node) => {
    const sourceX = source.position.x + 120;
    const sourceY = source.position.y + 40;
    const targetX = target.position.x;
    const targetY = target.position.y + 40;
    
    const midX = (sourceX + targetX) / 2;
    
    return `M ${sourceX} ${sourceY} C ${midX} ${sourceY}, ${midX} ${targetY}, ${targetX} ${targetY}`;
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Sidebar */}
      <NodeSidebar onAddNode={handleAddNode} />

      {/* Canvas Area */}
      <div className="flex-1 relative bg-[#0a0f1e] overflow-hidden">
        {/* Toolbar */}
        <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon"
            className="bg-card"
            onClick={() => handleAddNode('action')}
          >
            <Plus className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-1 bg-card border rounded-md">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={zoomOut}
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-xs px-2 min-w-[3rem] text-center">{Math.round(zoom * 100)}%</span>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={zoomIn}
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
          <Button 
            variant="outline" 
            size="icon"
            className="bg-card"
            onClick={() => setShowMinimap(!showMinimap)}
          >
            {showMinimap ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
        </div>

        {/* Canvas */}
        <div 
          ref={canvasRef}
          className="w-full h-full overflow-auto"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px'
          }}
        >
          <div 
            className="relative"
            style={{
              width: '2000px',
              height: '1500px',
              transform: `scale(${zoom})`,
              transformOrigin: 'top left'
            }}
          >
            {/* SVG for connections */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="10"
                  refX="9"
                  refY="3"
                  orient="auto"
                >
                  <polygon 
                    points="0 0, 10 3, 0 6" 
                    fill="rgba(255, 255, 255, 0.3)"
                  />
                </marker>
              </defs>
              {connections.map(conn => {
                const sourceNode = nodes.find(n => n.id === conn.source);
                const targetNode = nodes.find(n => n.id === conn.target);
                if (!sourceNode || !targetNode) return null;
                
                return (
                  <path
                    key={conn.id}
                    d={getConnectionPath(sourceNode, targetNode)}
                    stroke="rgba(255, 255, 255, 0.2)"
                    strokeWidth="2"
                    fill="none"
                    markerEnd="url(#arrowhead)"
                  />
                );
              })}
            </svg>

            {/* Nodes */}
            {nodes.map(node => (
              <WorkflowNode
                key={node.id}
                node={node}
                isSelected={selectedNode === node.id}
                onClick={() => handleNodeClick(node.id)}
                onDelete={() => handleDeleteNode(node.id)}
                onPositionChange={(pos) => handleNodePositionChange(node.id, pos)}
              />
            ))}
          </div>
        </div>

        {/* Minimap */}
        {showMinimap && (
          <div className="absolute bottom-4 right-4 w-48 h-32 bg-card border rounded-lg overflow-hidden">
            <div className="relative w-full h-full">
              <div 
                className="absolute inset-0"
                style={{
                  transform: 'scale(0.1)',
                  transformOrigin: 'top left',
                  width: '1000%',
                  height: '1000%'
                }}
              >
                {nodes.map(node => (
                  <div
                    key={node.id}
                    className={`absolute w-12 h-8 rounded ${
                      node.type === 'start' ? 'bg-green-500' :
                      node.type === 'end' ? 'bg-red-500' :
                      node.type === 'conditional' ? 'bg-orange-500' :
                      'bg-blue-500'
                    }`}
                    style={{
                      left: node.position.x,
                      top: node.position.y
                    }}
                  />
                ))}
              </div>
              {/* Viewport indicator */}
              <div className="absolute inset-2 border-2 border-white/50 rounded pointer-events-none" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
