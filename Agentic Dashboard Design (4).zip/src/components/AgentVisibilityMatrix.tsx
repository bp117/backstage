import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Search, Check, X, Users as UsersIcon, Shield } from 'lucide-react';

interface VisibilityRule {
  userId: string;
  userName: string;
  userRole: string;
  agents: Record<string, boolean>;
}

const agents = [
  'Financial Advisor',
  'Customer Support',
  'Trading Bot',
  'Account Manager',
  'Analytics Dashboard',
  'Medical Records',
  'Patient Assistant',
  'KB Search',
];

const mockVisibilityData: VisibilityRule[] = [
  {
    userId: '1',
    userName: 'John Developer',
    userRole: 'developer',
    agents: {
      'Financial Advisor': true,
      'Customer Support': true,
      'Trading Bot': false,
      'Account Manager': true,
      'Analytics Dashboard': true,
      'Medical Records': false,
      'Patient Assistant': false,
      'KB Search': true,
    },
  },
  {
    userId: '2',
    userName: 'Sarah Manager',
    userRole: 'manager',
    agents: {
      'Financial Advisor': true,
      'Customer Support': true,
      'Trading Bot': true,
      'Account Manager': true,
      'Analytics Dashboard': true,
      'Medical Records': true,
      'Patient Assistant': true,
      'KB Search': true,
    },
  },
  {
    userId: '3',
    userName: 'Mike Support',
    userRole: 'production_support',
    agents: {
      'Financial Advisor': true,
      'Customer Support': true,
      'Trading Bot': true,
      'Account Manager': false,
      'Analytics Dashboard': true,
      'Medical Records': false,
      'Patient Assistant': false,
      'KB Search': true,
    },
  },
  {
    userId: '4',
    userName: 'Emily Developer',
    userRole: 'developer',
    agents: {
      'Financial Advisor': true,
      'Customer Support': false,
      'Trading Bot': true,
      'Account Manager': true,
      'Analytics Dashboard': false,
      'Medical Records': false,
      'Patient Assistant': false,
      'KB Search': false,
    },
  },
];

export function AgentVisibilityMatrix() {
  const [viewMode, setViewMode] = useState<'users' | 'roles'>('users');
  const [visibilityData, setVisibilityData] = useState<VisibilityRule[]>(mockVisibilityData);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredData = visibilityData.filter((rule) =>
    rule.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    rule.userRole.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggle = (userId: string, agentName: string) => {
    setVisibilityData(
      visibilityData.map((rule) =>
        rule.userId === userId
          ? {
              ...rule,
              agents: {
                ...rule.agents,
                [agentName]: !rule.agents[agentName],
              },
            }
          : rule
      )
    );
  };

  const handleBulkEnable = (agentName: string) => {
    setVisibilityData(
      visibilityData.map((rule) => ({
        ...rule,
        agents: {
          ...rule.agents,
          [agentName]: true,
        },
      }))
    );
  };

  const handleBulkDisable = (agentName: string) => {
    setVisibilityData(
      visibilityData.map((rule) => ({
        ...rule,
        agents: {
          ...rule.agents,
          [agentName]: false,
        },
      }))
    );
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium">Agent Visibility Management</h3>
            <p className="text-sm text-muted-foreground">
              Control which agents are visible to each user
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'users' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('users')}
              className={viewMode === 'users' ? 'bg-orange-500 hover:bg-orange-600' : ''}
            >
              <UsersIcon className="w-3 h-3 mr-2" />
              By Users
            </Button>
            <Button
              variant={viewMode === 'roles' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('roles')}
              className={viewMode === 'roles' ? 'bg-orange-500 hover:bg-orange-600' : ''}
            >
              <Shield className="w-3 h-3 mr-2" />
              By Roles
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={`Search ${viewMode}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Matrix */}
        <div className="border rounded-lg overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="sticky left-0 bg-background z-10 min-w-[200px]">
                  User / Role
                </TableHead>
                {agents.map((agent) => (
                  <TableHead key={agent} className="text-center min-w-[140px]">
                    <div className="space-y-2">
                      <div className="font-medium text-xs">{agent}</div>
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2 text-xs"
                          onClick={() => handleBulkEnable(agent)}
                        >
                          All
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2 text-xs"
                          onClick={() => handleBulkDisable(agent)}
                        >
                          None
                        </Button>
                      </div>
                    </div>
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.map((rule) => (
                <TableRow key={rule.userId}>
                  <TableCell className="sticky left-0 bg-background z-10">
                    <div>
                      <div className="font-medium">{rule.userName}</div>
                      <Badge
                        variant="outline"
                        className="text-xs mt-1"
                      >
                        {rule.userRole}
                      </Badge>
                    </div>
                  </TableCell>
                  {agents.map((agent) => (
                    <TableCell key={agent} className="text-center">
                      <div className="flex items-center justify-center gap-2">
                        <Switch
                          checked={rule.agents[agent]}
                          onCheckedChange={() => handleToggle(rule.userId, agent)}
                        />
                        {rule.agents[agent] ? (
                          <Check className="w-4 h-4 text-green-500" />
                        ) : (
                          <X className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-6 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>Visible - User can access this agent</span>
          </div>
          <div className="flex items-center gap-2">
            <X className="w-4 h-4 text-muted-foreground" />
            <span>Hidden - User cannot access this agent</span>
          </div>
        </div>

        {/* Info */}
        <div className="bg-muted/50 border rounded-lg p-4">
          <p className="text-sm">
            <strong>Note:</strong> User-specific overrides take precedence over role-based defaults.
            Changes are saved automatically and take effect immediately.
          </p>
        </div>
      </div>
    </Card>
  );
}
