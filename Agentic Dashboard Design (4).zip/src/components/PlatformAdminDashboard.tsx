import { useState } from 'react';
import { 
  Server, 
  Database, 
  TrendingUp, 
  AlertCircle,
  Cpu,
  HardDrive,
  Network,
  Shield,
  Activity,
  Zap,
  Settings,
  RefreshCw
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

export function PlatformAdminDashboard() {
  return (
    <div className="p-8 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-2">Platform Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor and manage platform infrastructure, resources, and system health
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button>
            <Settings className="w-4 h-4 mr-2" />
            Platform Settings
          </Button>
        </div>
      </div>

      {/* System Health Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">System Uptime</p>
              <p className="text-3xl">99.9%</p>
              <p className="text-xs text-green-600 mt-2">
                743 days running
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Active Agents</p>
              <p className="text-3xl">487</p>
              <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +23 this week
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Cpu className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">API Calls/min</p>
              <p className="text-3xl">8.2K</p>
              <p className="text-xs text-muted-foreground mt-2">
                Avg response: 45ms
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Critical Alerts</p>
              <p className="text-3xl">2</p>
              <p className="text-xs text-orange-600 mt-2">
                Requires attention
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Resource Usage */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-lg mb-6">Resource Usage</h2>
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Cpu className="w-4 h-4 text-blue-600" />
                  <span>CPU Usage</span>
                </div>
                <span className="text-sm text-muted-foreground">68%</span>
              </div>
              <Progress value={68} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">Average across 24 nodes</p>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Server className="w-4 h-4 text-green-600" />
                  <span>Memory Usage</span>
                </div>
                <span className="text-sm text-muted-foreground">54%</span>
              </div>
              <Progress value={54} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">128GB / 237GB used</p>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <HardDrive className="w-4 h-4 text-purple-600" />
                  <span>Storage Usage</span>
                </div>
                <span className="text-sm text-muted-foreground">41%</span>
              </div>
              <Progress value={41} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">4.2TB / 10TB used</p>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Network className="w-4 h-4 text-orange-600" />
                  <span>Network Traffic</span>
                </div>
                <span className="text-sm text-muted-foreground">72%</span>
              </div>
              <Progress value={72} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">7.2Gbps / 10Gbps bandwidth</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg mb-6">Database Health</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Primary DB Cluster</p>
                  <p className="text-sm text-muted-foreground">prod-db-01</p>
                </div>
              </div>
              <Badge className="bg-green-500">Healthy</Badge>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Read Replica 1</p>
                  <p className="text-sm text-muted-foreground">prod-db-replica-01</p>
                </div>
              </div>
              <Badge className="bg-green-500">Healthy</Badge>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Read Replica 2</p>
                  <p className="text-sm text-muted-foreground">prod-db-replica-02</p>
                </div>
              </div>
              <Badge className="bg-green-500">Healthy</Badge>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-orange-600" />
                <div>
                  <p className="font-medium">Analytics DB</p>
                  <p className="text-sm text-muted-foreground">analytics-db-01</p>
                </div>
              </div>
              <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-200">
                High Load
              </Badge>
            </div>
          </div>
        </Card>
      </div>

      {/* Active Services */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg">Active Services</h2>
          <Button variant="ghost" size="sm">View All</Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-blue-500/10 flex items-center justify-center">
                  <Server className="w-4 h-4 text-blue-600" />
                </div>
                <span className="font-medium">API Gateway</span>
              </div>
              <Badge className="bg-green-500">Active</Badge>
            </div>
            <div className="space-y-1 text-sm text-muted-foreground">
              <p>Uptime: 99.99%</p>
              <p>Requests/s: 1,247</p>
            </div>
          </div>
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-purple-500/10 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-purple-600" />
                </div>
                <span className="font-medium">Agent Runtime</span>
              </div>
              <Badge className="bg-green-500">Active</Badge>
            </div>
            <div className="space-y-1 text-sm text-muted-foreground">
              <p>Uptime: 99.98%</p>
              <p>Active Instances: 487</p>
            </div>
          </div>
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-green-500/10 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-green-600" />
                </div>
                <span className="font-medium">Auth Service</span>
              </div>
              <Badge className="bg-green-500">Active</Badge>
            </div>
            <div className="space-y-1 text-sm text-muted-foreground">
              <p>Uptime: 100%</p>
              <p>Auth/s: 342</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Recent Alerts */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg">Recent Alerts</h2>
          <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-200">
            2 critical
          </Badge>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-4 border border-orange-200 bg-orange-500/5 rounded-lg">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-orange-900 dark:text-orange-100">High Database Load</p>
                  <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
                    Analytics DB experiencing sustained high CPU usage (&gt;85%)
                  </p>
                  <p className="text-xs text-orange-600 dark:text-orange-400 mt-2">5 minutes ago</p>
                </div>
                <Badge variant="outline" className="bg-orange-600 text-white border-orange-600">Critical</Badge>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 border border-orange-200 bg-orange-500/5 rounded-lg">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-orange-900 dark:text-orange-100">SSL Certificate Expiring</p>
                  <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
                    api.agents.company.com certificate expires in 7 days
                  </p>
                  <p className="text-xs text-orange-600 dark:text-orange-400 mt-2">2 hours ago</p>
                </div>
                <Badge variant="outline" className="bg-orange-600 text-white border-orange-600">Critical</Badge>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 border rounded-lg">
            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">Elevated Network Traffic</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Network bandwidth usage above 70% threshold
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">1 hour ago</p>
                </div>
                <Badge variant="outline">Warning</Badge>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}