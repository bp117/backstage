import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  CheckCircle,
  Users,
  Bot,
  Activity,
} from 'lucide-react';
import { UserManagementTable } from './UserManagementTable';
import { AgentVisibilityMatrix } from './AgentVisibilityMatrix';
import { EntitlementManager } from './EntitlementManager';
import { AuditLog } from './AuditLog';
import { AgenticDrillDown } from './AgenticDrillDown';

const systemStats = [
  { label: 'System Status', value: 'Operational', icon: CheckCircle, color: 'text-green-500' },
  { label: 'Active Users', value: '89', icon: Users, color: 'text-blue-500' },
  { label: 'Total Agents', value: '24', icon: Bot, color: 'text-purple-500' },
  { label: 'Active Sessions', value: '45', icon: Activity, color: 'text-orange-500' },
];

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('users');

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl">Administration Center</h2>
        <p className="text-sm text-muted-foreground">Manage users, agents, and system settings</p>
      </div>

      {/* System Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {systemStats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl mt-1">{stat.value}</p>
                </div>
                <div className={`p-2 ${stat.color.replace('text-', 'bg-')}/10 rounded-lg`}>
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Management Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="users">Users & Entitlements</TabsTrigger>
          <TabsTrigger value="visibility">Agent Visibility</TabsTrigger>
          <TabsTrigger value="entitlements">Entitlements</TabsTrigger>
          <TabsTrigger value="drilldown">Drill Down</TabsTrigger>
          <TabsTrigger value="audit">Audit Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-6">
          <UserManagementTable />
        </TabsContent>

        <TabsContent value="visibility" className="mt-6">
          <AgentVisibilityMatrix />
        </TabsContent>

        <TabsContent value="entitlements" className="mt-6">
          <EntitlementManager />
        </TabsContent>

        <TabsContent value="drilldown" className="mt-6">
          <AgenticDrillDown canEdit canDelete canTest showMetrics />
        </TabsContent>

        <TabsContent value="audit" className="mt-6">
          <AuditLog />
        </TabsContent>
      </Tabs>
    </div>
  );
}