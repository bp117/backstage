import { ReactNode } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { LucideIcon } from 'lucide-react';

interface DashboardWidgetProps {
  title: string;
  description?: string;
  value?: string | number;
  change?: {
    value: string;
    positive: boolean;
  };
  icon?: LucideIcon;
  iconColor?: string;
  children?: ReactNode;
  action?: ReactNode;
}

export function DashboardWidget({
  title,
  description,
  value,
  change,
  icon: Icon,
  iconColor = 'text-foreground',
  children,
  action
}: DashboardWidgetProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex-1">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          {description && (
            <CardDescription className="mt-1">{description}</CardDescription>
          )}
        </div>
        {Icon && (
          <Icon className={`h-4 w-4 ${iconColor}`} />
        )}
      </CardHeader>
      <CardContent>
        {value !== undefined && (
          <div className="flex items-baseline gap-2">
            <div className="text-2xl font-bold">{value}</div>
            {change && (
              <span className={`text-xs ${change.positive ? 'text-green-600' : 'text-red-600'}`}>
                {change.positive ? '↑' : '↓'} {change.value}
              </span>
            )}
          </div>
        )}
        {children}
        {action && <div className="mt-4">{action}</div>}
      </CardContent>
    </Card>
  );
}
