import { createContext, useContext, useState, ReactNode } from 'react';

export type Role = 'consumer' | 'manager' | 'lob_admin' | 'platform_admin' | 'support' | 'executive';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  entitlements: string[];
  allowedAgents: string[];
  team?: string;
}

interface UserContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  hasPermission: (permission: string) => boolean;
  canAccessAgent: (agentId: string) => boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const rolePermissions: Record<Role, string[]> = {
  consumer: [
    'view_dashboard',
    'use_apps',
    'view_own_history',
    'report_problems',
  ],
  manager: [
    'view_dashboard',
    'view_team_metrics',
    'generate_reports',
    'view_cost_analysis',
    'view_team_performance',
  ],
  lob_admin: [
    'view_dashboard',
    'manage_lob_users',
    'approve_agents',
    'view_lob_metrics',
    'manage_permissions',
    'view_compliance',
  ],
  platform_admin: [
    'view_dashboard',
    'manage_infrastructure',
    'view_system_health',
    'manage_resources',
    'view_all_logs',
    'system_settings',
  ],
  support: [
    'view_dashboard',
    'view_tickets',
    'resolve_issues',
    'access_user_data',
    'escalate_tickets',
    'view_support_metrics',
  ],
  executive: [
    'view_dashboard',
    'view_all_metrics',
    'view_roi',
    'view_strategic_insights',
    'export_reports',
  ],
};

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>({
    id: '1',
    name: 'Emma Consumer',
    email: 'emma.consumer@bank.com',
    role: 'consumer',
    entitlements: ['basic_access'],
    allowedAgents: ['1', '2', '3', '4'],
    team: 'Digital Banking',
  });

  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    return rolePermissions[user.role]?.includes(permission) || false;
  };

  const canAccessAgent = (agentId: string): boolean => {
    if (!user) return false;
    if (user.allowedAgents.includes('all')) return true;
    return user.allowedAgents.includes(agentId);
  };

  return (
    <UserContext.Provider value={{ user, setUser, hasPermission, canAccessAgent }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}