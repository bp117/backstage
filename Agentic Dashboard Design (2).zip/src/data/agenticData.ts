// Hierarchical data structure: Apps → Agents → MCPs

export interface MCP {
  id: string;
  name: string;
  type: 'database' | 'api' | 'file' | 'search' | 'tool';
  status: 'active' | 'inactive' | 'error';
  description: string;
  endpoint?: string;
  lastUsed: string;
  usageCount: number;
}

export interface Agent {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'draft' | 'error';
  description: string;
  mcps: MCP[];
  successRate: number;
  totalRequests: number;
  lastDeployed: string;
  owner: string;
}

export interface AgenticApp {
  id: string;
  name: string;
  description: string;
  status: 'live' | 'staging' | 'maintenance';
  agents: Agent[];
  category: string;
  users: number;
  createdDate: string;
  version: string;
}

export const agenticApps: AgenticApp[] = [
  {
    id: 'app-1',
    name: 'Financial Services Suite',
    description: 'Complete financial advisory and account management platform',
    status: 'live',
    category: 'Finance',
    users: 1247,
    createdDate: '2023-08-15',
    version: 'v2.1.0',
    agents: [
      {
        id: 'agent-1',
        name: 'Financial Advisor',
        type: 'Advisory',
        status: 'active',
        description: 'Provides personalized financial advice and portfolio recommendations',
        successRate: 96.8,
        totalRequests: 12453,
        lastDeployed: '2024-01-10',
        owner: 'Sarah Chen',
        mcps: [
          {
            id: 'mcp-1',
            name: 'Market Data API',
            type: 'api',
            status: 'active',
            description: 'Real-time stock market and financial data',
            endpoint: 'https://api.marketdata.com/v1',
            lastUsed: '2 min ago',
            usageCount: 45234,
          },
          {
            id: 'mcp-2',
            name: 'Portfolio Database',
            type: 'database',
            status: 'active',
            description: 'User portfolio and transaction history',
            endpoint: 'postgresql://db.example.com:5432/portfolios',
            lastUsed: '5 min ago',
            usageCount: 23456,
          },
          {
            id: 'mcp-3',
            name: 'Risk Analysis Tool',
            type: 'tool',
            status: 'active',
            description: 'Calculate portfolio risk metrics and projections',
            lastUsed: '15 min ago',
            usageCount: 8934,
          },
        ],
      },
      {
        id: 'agent-2',
        name: 'Account Manager',
        type: 'Management',
        status: 'active',
        description: 'Handles account operations and customer requests',
        successRate: 94.2,
        totalRequests: 8923,
        lastDeployed: '2024-01-08',
        owner: 'Mike Johnson',
        mcps: [
          {
            id: 'mcp-4',
            name: 'Customer Database',
            type: 'database',
            status: 'active',
            description: 'Customer profiles and account information',
            endpoint: 'postgresql://db.example.com:5432/customers',
            lastUsed: '1 min ago',
            usageCount: 34567,
          },
          {
            id: 'mcp-5',
            name: 'Authentication Service',
            type: 'api',
            status: 'active',
            description: 'User authentication and authorization',
            endpoint: 'https://auth.example.com/api',
            lastUsed: '3 min ago',
            usageCount: 56789,
          },
        ],
      },
      {
        id: 'agent-3',
        name: 'Trading Bot',
        type: 'Automation',
        status: 'active',
        description: 'Automated trading based on predefined strategies',
        successRate: 91.5,
        totalRequests: 6721,
        lastDeployed: '2024-01-12',
        owner: 'Alex Kumar',
        mcps: [
          {
            id: 'mcp-6',
            name: 'Trading API',
            type: 'api',
            status: 'active',
            description: 'Execute buy/sell orders on exchanges',
            endpoint: 'https://trading.example.com/api/v2',
            lastUsed: 'Just now',
            usageCount: 12890,
          },
          {
            id: 'mcp-7',
            name: 'Strategy Rules Engine',
            type: 'tool',
            status: 'active',
            description: 'Evaluate trading strategies and signals',
            lastUsed: '30 sec ago',
            usageCount: 45678,
          },
        ],
      },
    ],
  },
  {
    id: 'app-2',
    name: 'Customer Support Platform',
    description: 'Multi-channel customer support with AI-powered assistance',
    status: 'live',
    category: 'Support',
    users: 3456,
    createdDate: '2023-09-20',
    version: 'v3.0.2',
    agents: [
      {
        id: 'agent-4',
        name: 'Support Agent',
        type: 'Conversational',
        status: 'active',
        description: 'Handles tier 1 customer inquiries and support tickets',
        successRate: 89.3,
        totalRequests: 15678,
        lastDeployed: '2024-01-11',
        owner: 'Emily Davis',
        mcps: [
          {
            id: 'mcp-8',
            name: 'Knowledge Base',
            type: 'search',
            status: 'active',
            description: 'Search and retrieve support articles',
            endpoint: 'elasticsearch://kb.example.com:9200',
            lastUsed: '10 sec ago',
            usageCount: 78934,
          },
          {
            id: 'mcp-9',
            name: 'Ticket System',
            type: 'api',
            status: 'active',
            description: 'Create and manage support tickets',
            endpoint: 'https://tickets.example.com/api',
            lastUsed: '45 sec ago',
            usageCount: 34521,
          },
          {
            id: 'mcp-10',
            name: 'Chat History',
            type: 'database',
            status: 'active',
            description: 'Previous conversations and context',
            endpoint: 'mongodb://chat.example.com:27017',
            lastUsed: '2 min ago',
            usageCount: 23456,
          },
        ],
      },
      {
        id: 'agent-5',
        name: 'Escalation Handler',
        type: 'Specialized',
        status: 'active',
        description: 'Manages complex issues requiring human intervention',
        successRate: 93.7,
        totalRequests: 4532,
        lastDeployed: '2024-01-09',
        owner: 'Emily Davis',
        mcps: [
          {
            id: 'mcp-11',
            name: 'Priority Queue',
            type: 'tool',
            status: 'active',
            description: 'Prioritize and route escalated tickets',
            lastUsed: '5 min ago',
            usageCount: 5678,
          },
          {
            id: 'mcp-12',
            name: 'Team Calendar',
            type: 'api',
            status: 'active',
            description: 'Check specialist availability',
            endpoint: 'https://calendar.example.com/api',
            lastUsed: '8 min ago',
            usageCount: 3421,
          },
        ],
      },
    ],
  },
  {
    id: 'app-3',
    name: 'Healthcare Assistant',
    description: 'Medical information and patient support system',
    status: 'staging',
    category: 'Healthcare',
    users: 892,
    createdDate: '2023-11-05',
    version: 'v1.5.0',
    agents: [
      {
        id: 'agent-6',
        name: 'Patient Assistant',
        type: 'Medical',
        status: 'active',
        description: 'Provides health information and appointment scheduling',
        successRate: 87.9,
        totalRequests: 3210,
        lastDeployed: '2024-01-13',
        owner: 'Dr. Sarah Wong',
        mcps: [
          {
            id: 'mcp-13',
            name: 'Medical Database',
            type: 'database',
            status: 'active',
            description: 'Medical conditions and treatment information',
            endpoint: 'postgresql://medical.example.com:5432/meddb',
            lastUsed: '20 min ago',
            usageCount: 12345,
          },
          {
            id: 'mcp-14',
            name: 'Appointment System',
            type: 'api',
            status: 'active',
            description: 'Schedule and manage appointments',
            endpoint: 'https://appointments.example.com/api',
            lastUsed: '15 min ago',
            usageCount: 8765,
          },
          {
            id: 'mcp-15',
            name: 'Symptom Checker',
            type: 'tool',
            status: 'active',
            description: 'Analyze symptoms and suggest next steps',
            lastUsed: '25 min ago',
            usageCount: 6543,
          },
        ],
      },
      {
        id: 'agent-7',
        name: 'Medical Records Agent',
        type: 'Data Access',
        status: 'draft',
        description: 'Secure access to patient medical records',
        successRate: 95.2,
        totalRequests: 1876,
        lastDeployed: '2024-01-05',
        owner: 'Dr. Sarah Wong',
        mcps: [
          {
            id: 'mcp-16',
            name: 'EHR System',
            type: 'api',
            status: 'active',
            description: 'Electronic Health Records integration',
            endpoint: 'https://ehr.example.com/fhir/v4',
            lastUsed: '1 hour ago',
            usageCount: 4567,
          },
          {
            id: 'mcp-17',
            name: 'Secure File Storage',
            type: 'file',
            status: 'active',
            description: 'Encrypted storage for medical documents',
            endpoint: 's3://medical-records-secure/',
            lastUsed: '45 min ago',
            usageCount: 2345,
          },
        ],
      },
    ],
  },
  {
    id: 'app-4',
    name: 'Analytics Dashboard',
    description: 'Business intelligence and data analytics platform',
    status: 'live',
    category: 'Analytics',
    users: 567,
    createdDate: '2023-10-12',
    version: 'v2.3.1',
    agents: [
      {
        id: 'agent-8',
        name: 'Data Analyst',
        type: 'Analytics',
        status: 'active',
        description: 'Generates insights and reports from business data',
        successRate: 92.4,
        totalRequests: 5432,
        lastDeployed: '2024-01-14',
        owner: 'John Developer',
        mcps: [
          {
            id: 'mcp-18',
            name: 'Data Warehouse',
            type: 'database',
            status: 'active',
            description: 'Central repository for analytics data',
            endpoint: 'postgresql://warehouse.example.com:5432/analytics',
            lastUsed: '5 min ago',
            usageCount: 23456,
          },
          {
            id: 'mcp-19',
            name: 'Visualization Engine',
            type: 'tool',
            status: 'active',
            description: 'Generate charts and graphs',
            lastUsed: '10 min ago',
            usageCount: 15678,
          },
          {
            id: 'mcp-20',
            name: 'Query Optimizer',
            type: 'tool',
            status: 'active',
            description: 'Optimize and execute complex queries',
            lastUsed: '3 min ago',
            usageCount: 34567,
          },
        ],
      },
    ],
  },
];
