import { useState } from 'react';
import { 
  ArrowLeft, 
  Save, 
  Settings, 
  MessageSquare, 
  Clock, 
  Sliders,
  Wrench,
  ShieldCheck,
  Zap,
  BarChart3,
  FileText,
  Download,
  Mic,
  Send,
  X,
  Maximize2
} from 'lucide-react';
import { ChatInterface } from './ChatInterface';
import { GuardrailsPanel } from './GuardrailsPanel';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface AgentDetailPageProps {
  agentId: string;
  onBack: () => void;
}

export function AgentDetailPage({ agentId, onBack }: AgentDetailPageProps) {
  const [activeTab, setActiveTab] = useState('test');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: FileText },
    { id: 'test', label: 'Test', icon: MessageSquare },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'preprocessing', label: 'Pre Processing', icon: Sliders },
    { id: 'postprocessing', label: 'Post Processing', icon: Wrench },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'conversations', label: 'Conversation Logs', icon: MessageSquare },
    { id: 'export', label: 'Export', icon: Download },
    { id: 'history', label: 'History', icon: Clock }
  ];

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="border-b px-6 py-4 bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost"
              size="icon"
              onClick={onBack}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md border bg-muted flex items-center justify-center">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl">Financial Advisor - Retirement Planning</h1>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Badge variant="secondary">Draft</Badge>
                  <span className="text-muted-foreground">•</span>
                  <span>0 versions</span>
                  <span>•</span>
                  <span>0 conversations</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon">
              <Settings className="w-4 h-4" />
            </Button>
            <Button>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b bg-card">
        <div className="flex items-center gap-1 px-6">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors text-sm ${
                  activeTab === tab.id 
                    ? 'border-foreground text-foreground' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'test' && (
        <ChatInterface />
      )}

      {activeTab === 'postprocessing' && (
        <div className="flex-1 overflow-auto">
          <GuardrailsPanel />
        </div>
      )}
      
      {activeTab !== 'test' && activeTab !== 'postprocessing' && (
        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-4xl">
            <div className="border rounded-lg p-12 text-center bg-card">
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 rounded-full border-2 border-dashed flex items-center justify-center">
                  {tabs.find(t => t.id === activeTab)?.icon && (
                    <>{(() => {
                      const Icon = tabs.find(t => t.id === activeTab)!.icon;
                      return <Icon className="w-8 h-8 text-muted-foreground" />;
                    })()}</>
                  )}
                </div>
              </div>
              <h3 className="text-xl mb-2">{tabs.find(t => t.id === activeTab)?.label}</h3>
              <p className="text-muted-foreground">This section is under construction</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}