import { Shield, Users, MessageSquare, Zap, MoreVertical, Play, Trash2, Copy, Edit, TrendingUp } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface Agent {
  id: string;
  name: string;
  lastUpdated: string;
  description: string;
  status: 'draft' | 'published';
  category: string;
  tags: string[];
  stats: {
    versions: number;
    users: number;
    conversations: number;
    actions: number;
  };
}

interface AgentCardProps {
  agent: Agent;
  onSelect: () => void;
  onDelete?: (id: string) => void;
  onDuplicate?: (id: string) => void;
}

export function AgentCard({ agent, onSelect, onDelete, onDuplicate }: AgentCardProps) {
  const handleAction = (e: React.MouseEvent, action: () => void) => {
    e.stopPropagation();
    action();
  };

  return (
    <div 
      className="border rounded-lg p-5 bg-card hover:shadow-lg transition-all cursor-pointer group relative overflow-hidden"
      onClick={onSelect}
    >
      {/* Status indicator line */}
      <div className={`absolute top-0 left-0 right-0 h-1 ${
        agent.status === 'published' ? 'bg-green-500' : 'bg-yellow-500'
      }`} />

      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-9 h-9 rounded-md border bg-muted/50 flex items-center justify-center flex-shrink-0">
              <MessageSquare className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-medium group-hover:text-primary transition-colors truncate">
                {agent.name}
              </h3>
            </div>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={(e) => handleAction(e as any, onSelect)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Agent
            </DropdownMenuItem>
            <DropdownMenuItem onClick={(e) => handleAction(e as any, () => onDuplicate?.(agent.id))}>
              <Copy className="w-4 h-4 mr-2" />
              Duplicate
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Play className="w-4 h-4 mr-2" />
              Test Agent
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              className="text-destructive focus:text-destructive"
              onClick={(e) => handleAction(e as any, () => onDelete?.(agent.id))}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Updated time */}
      <p className="text-xs text-muted-foreground mb-3">
        Updated {agent.lastUpdated}
      </p>

      {/* Description */}
      <p className="text-sm text-muted-foreground mb-4 line-clamp-2 min-h-[40px]">
        {agent.description || 'No description provided.'}
      </p>

      {/* Status and Tags */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <Badge variant={agent.status === 'draft' ? 'secondary' : 'default'} className="text-xs">
          {agent.status === 'draft' ? 'Draft' : 'Published'}
        </Badge>
        {agent.tags.slice(0, 2).map((tag, idx) => (
          <Badge key={idx} variant="outline" className="text-xs">
            {tag}
          </Badge>
        ))}
        {agent.tags.length > 2 && (
          <Badge variant="outline" className="text-xs">
            +{agent.tags.length - 2}
          </Badge>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 pt-4 border-t">
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Shield className="w-3.5 h-3.5 text-muted-foreground" />
          </div>
          <div className="text-sm font-medium">{agent.stats.versions}</div>
          <div className="text-xs text-muted-foreground">Versions</div>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Users className="w-3.5 h-3.5 text-muted-foreground" />
          </div>
          <div className="text-sm font-medium">{agent.stats.users}</div>
          <div className="text-xs text-muted-foreground">Users</div>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <MessageSquare className="w-3.5 h-3.5 text-muted-foreground" />
          </div>
          <div className="text-sm font-medium">{agent.stats.conversations}</div>
          <div className="text-xs text-muted-foreground">Chats</div>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Zap className="w-3.5 h-3.5 text-muted-foreground" />
          </div>
          <div className="text-sm font-medium">{agent.stats.actions}</div>
          <div className="text-xs text-muted-foreground">Actions</div>
        </div>
      </div>

      {/* Quick action button - visible on hover */}
      <div className="absolute bottom-5 right-5 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button 
          size="sm" 
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          className="shadow-lg"
        >
          <Play className="w-3 h-3 mr-1.5" />
          Test
        </Button>
      </div>
    </div>
  );
}