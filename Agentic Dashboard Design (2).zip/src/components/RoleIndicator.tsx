import { Badge } from './ui/badge';
import { useUser, Role } from '../contexts/UserContext';
import { Wrench, BarChart3, Shield, Activity } from 'lucide-react';

const roleConfig: Record<Role, { label: string; icon: any; color: string }> = {
  developer: {
    label: 'Developer',
    icon: Wrench,
    color: 'bg-blue-500 text-white',
  },
  manager: {
    label: 'Manager',
    icon: BarChart3,
    color: 'bg-purple-500 text-white',
  },
  admin: {
    label: 'Admin',
    icon: Shield,
    color: 'bg-orange-500 text-white',
  },
  production_support: {
    label: 'Production Support',
    icon: Activity,
    color: 'bg-green-500 text-white',
  },
};

export function RoleIndicator() {
  const { user } = useUser();

  if (!user) return null;

  const config = roleConfig[user.role];
  const Icon = config.icon;

  return (
    <Badge className={`${config.color} gap-1.5 px-3 py-1`}>
      <Icon className="w-3.5 h-3.5" />
      {config.label}
    </Badge>
  );
}
