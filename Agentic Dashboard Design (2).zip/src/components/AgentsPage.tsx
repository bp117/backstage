import { useState } from 'react';
import { Plus, Upload, Grid3x3, List, Search, Filter } from 'lucide-react';
import { AgentCard } from './AgentCard';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { CreateAgentDialog } from './CreateAgentDialog';

interface Agent {
  id: string;
  name: string;
  lastUpdated: string;
  description: string;
  status: 'draft' | 'published';
  category: string;
  tags: string[];
  stats: {
    versions: number;
    users: number;
    conversations: number;
    actions: number;
  };
}

const mockAgents: Agent[] = [
  {
    id: '1',
    name: 'Agent Advisor',
    lastUpdated: '7/18/2025',
    description: 'No description provided.',
    status: 'draft',
    category: 'Debt Collection',
    tags: ['Debt Collection'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 2 }
  },
  {
    id: '2',
    name: 'Banking Agent - Payments',
    lastUpdated: '7/24/2025',
    description: 'Banking agent specialized in person-to-person payments',
    status: 'draft',
    category: 'Uncategorized',
    tags: ['Uncategorized'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
  },
  {
    id: '3',
    name: 'Banking Agent - Transaction Analysis',
    lastUpdated: '7/18/2025',
    description: 'Banking agent specialized in transaction history and spending analysis',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 0 }
  },
  {
    id: '4',
    name: 'Banking Agent - Transfers',
    lastUpdated: '7/18/2025',
    description: 'Banking agent specialized in account-to-account transfers',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 0 }
  },
  {
    id: '5',
    name: 'Banking Specialist - Account Opening',
    lastUpdated: '7/18/2025',
    description: 'Banking specialist focused on opening new customer accounts',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 0 }
  },
  {
    id: '6',
    name: 'Banking Specialist - Savings Accounts',
    lastUpdated: '7/18/2025',
    description: 'Banking specialist focused on savings account products and queries',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
  },
  {
    id: '7',
    name: 'Chat/Digital Agent',
    lastUpdated: '7/18/2025',
    description: 'No description provided.',
    status: 'draft',
    category: 'Debt Collection',
    tags: ['Debt Collection'],
    stats: { versions: 0, users: 1, conversations: 0, actions: 2 }
  },
  {
    id: '8',
    name: 'Customer Service Agent',
    lastUpdated: '7/9/2025',
    description: 'General customer service agent for banking inquiries',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
  },
  {
    id: '9',
    name: 'Excite Digital Assistant',
    lastUpdated: '7/7/2025',
    description: 'No description provided.',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
  },
  {
    id: '10',
    name: 'Financial Advisor - Retirement Planning',
    lastUpdated: '7/28/2025',
    description: 'Financial advisor specialized in retirement planning and investment strategies',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
  },
  {
    id: '11',
    name: 'Financial Advisor - Risk Assessment',
    lastUpdated: '7/18/2025',
    description: 'Financial advisor for risk assessment and portfolio analysis',
    status: 'draft',
    category: 'Banking',
    tags: ['Banking'],
    stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
  }
];

interface AgentsPageProps {
  onAgentSelect: (agentId: string) => void;
}

export function AgentsPage({ onAgentSelect }: AgentsPageProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filter, setFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [agents, setAgents] = useState(mockAgents);

  const handleCreateAgent = (newAgent: any) => {
    const agent = {
      id: Date.now().toString(),
      name: newAgent.name,
      lastUpdated: new Date().toLocaleDateString(),
      description: newAgent.description,
      status: 'draft' as const,
      category: newAgent.category,
      tags: [newAgent.category],
      stats: { versions: 0, users: 0, conversations: 0, actions: 0 }
    };
    setAgents([agent, ...agents]);
  };

  const handleDeleteAgent = (id: string) => {
    if (confirm('Are you sure you want to delete this agent?')) {
      setAgents(agents.filter(a => a.id !== id));
    }
  };

  const handleDuplicateAgent = (id: string) => {
    const agent = agents.find(a => a.id === id);
    if (agent) {
      const duplicated = {
        ...agent,
        id: Date.now().toString(),
        name: `${agent.name} (Copy)`,
        lastUpdated: new Date().toLocaleDateString(),
      };
      setAgents([duplicated, ...agents]);
    }
  };

  const filteredAgents = agents.filter(agent => {
    if (filter !== 'all' && agent.status !== filter) return false;
    if (categoryFilter !== 'all' && !agent.tags.includes(categoryFilter)) return false;
    if (searchQuery && !agent.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl mb-2">Agents</h1>
          <p className="text-muted-foreground">Create and manage AI agents for your organization</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Upload className="w-4 h-4 mr-2" />
            Import
          </Button>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Agent
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant={categoryFilter === 'all' ? 'default' : 'ghost'}
            onClick={() => setCategoryFilter('all')}
            size="sm"
          >
            All Categories
          </Button>
          <Button
            variant={categoryFilter === 'Banking' ? 'default' : 'ghost'}
            onClick={() => setCategoryFilter('Banking')}
            size="sm"
          >
            Banking
          </Button>
          <Button
            variant={categoryFilter === 'Debt Collection' ? 'default' : 'ghost'}
            onClick={() => setCategoryFilter('Debt Collection')}
            size="sm"
          >
            Debt Collection
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center border rounded-md">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-accent' : 'hover:bg-accent/50'}`}
            >
              <Grid3x3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-accent' : 'hover:bg-accent/50'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center border rounded-md">
            <button
              className={`px-3 py-2 text-sm ${filter === 'all' ? 'bg-accent' : 'hover:bg-accent/50'}`}
              onClick={() => setFilter('all')}
            >
              All
            </button>
            <button
              className={`px-3 py-2 text-sm ${filter === 'published' ? 'bg-accent' : 'hover:bg-accent/50'}`}
              onClick={() => setFilter('published')}
            >
              Published
            </button>
            <button
              className={`px-3 py-2 text-sm ${filter === 'draft' ? 'bg-accent' : 'hover:bg-accent/50'}`}
              onClick={() => setFilter('draft')}
            >
              Draft
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search agents..."
              className="pl-9 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Agents Count */}
      <div className="mb-4">
        <p className="text-sm text-muted-foreground">
          Showing {filteredAgents.length} of {agents.length} agents
        </p>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAgents.map(agent => (
          <AgentCard 
            key={agent.id} 
            agent={agent} 
            onSelect={() => onAgentSelect(agent.id)}
            onDelete={handleDeleteAgent}
            onDuplicate={handleDuplicateAgent}
          />
        ))}
      </div>

      {filteredAgents.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No agents found</p>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Your First Agent
          </Button>
        </div>
      )}

      <CreateAgentDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onCreate={handleCreateAgent}
      />
    </div>
  );
}