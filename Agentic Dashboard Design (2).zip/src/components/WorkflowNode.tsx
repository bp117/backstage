import { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  GitBranch, 
  Database, 
  Zap,
  CheckCircle,
  Trash2,
  GripVertical,
  Settings,
  MoreVertical
} from 'lucide-react';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface Node {
  id: string;
  type: 'start' | 'end' | 'conditional' | 'action' | 'setVariable';
  position: { x: number; y: number };
  data: {
    label: string;
    description?: string;
    inputs?: string[];
    outputs?: string[];
    config?: any;
  };
}

interface WorkflowNodeProps {
  node: Node;
  isSelected: boolean;
  onClick: () => void;
  onDelete: () => void;
  onPositionChange: (position: { x: number; y: number }) => void;
}

export function WorkflowNode({ 
  node, 
  isSelected, 
  onClick, 
  onDelete,
  onPositionChange 
}: WorkflowNodeProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const nodeRef = useRef<HTMLDivElement>(null);

  const getNodeColor = () => {
    switch (node.type) {
      case 'start':
        return 'bg-green-500 border-green-600';
      case 'end':
        return 'bg-red-500 border-red-600';
      case 'conditional':
        return 'bg-orange-500 border-orange-600';
      case 'setVariable':
        return 'bg-blue-500 border-blue-600';
      default:
        return 'bg-blue-500 border-blue-600';
    }
  };

  const getNodeIcon = () => {
    switch (node.type) {
      case 'start':
        return <Play className="w-4 h-4" />;
      case 'end':
        return <CheckCircle className="w-4 h-4" />;
      case 'conditional':
        return <GitBranch className="w-4 h-4" />;
      case 'setVariable':
        return <Database className="w-4 h-4" />;
      default:
        return <Zap className="w-4 h-4" />;
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;
    
    setIsDragging(true);
    setDragStart({
      x: e.clientX - node.position.x,
      y: e.clientY - node.position.y
    });
    e.preventDefault();
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        onPositionChange({
          x: e.clientX - dragStart.x,
          y: e.clientY - dragStart.y
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragStart, onPositionChange]);

  return (
    <div
      ref={nodeRef}
      className={`absolute cursor-move transition-shadow ${
        isSelected ? 'ring-2 ring-white/50' : ''
      } ${isDragging ? 'opacity-70' : ''}`}
      style={{
        left: node.position.x,
        top: node.position.y,
        width: '240px'
      }}
      onClick={onClick}
      onMouseDown={handleMouseDown}
    >
      {/* Connection Points */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 bg-card border-2 border-foreground rounded-full" />
      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3 h-3 bg-card border-2 border-foreground rounded-full" />

      {/* Node Card */}
      <div className={`${getNodeColor()} text-white rounded-lg shadow-lg overflow-hidden`}>
        {/* Header */}
        <div className="px-3 py-2 flex items-center justify-between border-b border-white/20">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {getNodeIcon()}
            <span className="text-sm font-medium truncate">{node.data.label}</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 text-white hover:bg-white/20"
              >
                <MoreVertical className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Settings className="w-4 h-4 mr-2" />
                Configure
              </DropdownMenuItem>
              <DropdownMenuItem>
                <GripVertical className="w-4 h-4 mr-2" />
                Duplicate
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="text-destructive focus:text-destructive"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete();
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Body */}
        <div className="px-3 py-2 bg-black/20">
          {node.data.description && (
            <p className="text-xs opacity-90 mb-2">{node.data.description}</p>
          )}
          
          {/* Inputs */}
          {node.data.inputs && node.data.inputs.length > 0 && (
            <div className="text-xs space-y-1 mb-2">
              <div className="opacity-75">Inputs:</div>
              {node.data.inputs.slice(0, 3).map((input, idx) => (
                <div key={idx} className="opacity-90 truncate">• {input}</div>
              ))}
              {node.data.inputs.length > 3 && (
                <div className="opacity-75">+{node.data.inputs.length - 3} more</div>
              )}
            </div>
          )}

          {/* Outputs */}
          {node.data.outputs && node.data.outputs.length > 0 && (
            <div className="text-xs space-y-1">
              <div className="opacity-75">Outputs:</div>
              {node.data.outputs.slice(0, 3).map((output, idx) => (
                <div key={idx} className="opacity-90 truncate">• {output}</div>
              ))}
              {node.data.outputs.length > 3 && (
                <div className="opacity-75">+{node.data.outputs.length - 3} more</div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
