import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'developer' | 'manager' | 'admin' | 'production_support';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  permissions: string[];
  team?: string;
  entitlements: string[];
  visibleAgents: string[];
}

interface RoleContextType {
  user: User;
  setUser: (user: User) => void;
  hasPermission: (permission: string) => boolean;
  canAccessAgent: (agentId: string) => boolean;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>({
    id: '1',
    name: 'John Developer',
    email: 'john@example.com',
    role: 'developer',
    permissions: ['create_workflow', 'edit_workflow', 'test_agent', 'view_logs'],
    team: 'Engineering',
    entitlements: ['standard_access', 'api_access'],
    visibleAgents: ['agent-1', 'agent-2', 'agent-3']
  });

  const hasPermission = (permission: string) => {
    return user.permissions.includes(permission);
  };

  const canAccessAgent = (agentId: string) => {
    return user.visibleAgents.includes(agentId);
  };

  return (
    <RoleContext.Provider value={{ user, setUser, hasPermission, canAccessAgent }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within RoleProvider');
  }
  return context;
}
