import { useState } from 'react';
import { UserProvider } from './contexts/UserContext';
import { Sidebar } from './components/Sidebar';
import { AgentsPage } from './components/AgentsPage';
import { AgentDetailPage } from './components/AgentDetailPage';
import { WorkflowBuilderPage } from './components/WorkflowBuilderPage';
import { RoleBasedDashboard } from './components/RoleBasedDashboard';
import { Button } from './components/ui/button';
import { LayoutDashboard } from 'lucide-react';
import { Toaster } from './components/ui/sonner';

type Page = 'agents' | 'agent-detail' | 'workflows' | 'persona-dashboard';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('agents');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const handleAgentSelect = (agentId: string) => {
    setSelectedAgentId(agentId);
    setCurrentPage('agent-detail');
  };

  const handleBackFromAgent = () => {
    setCurrentPage('agents');
    setSelectedAgentId(null);
  };

  const handleBackFromWorkflow = () => {
    setCurrentPage('agents');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'agents':
        return <AgentsPage onAgentSelect={handleAgentSelect} />;
      case 'agent-detail':
        return selectedAgentId ? (
          <AgentDetailPage agentId={selectedAgentId} onBack={handleBackFromAgent} />
        ) : null;
      case 'workflows':
        return <WorkflowBuilderPage onBack={handleBackFromWorkflow} />;
      case 'persona-dashboard':
        return <RoleBasedDashboard onBackToMain={() => setCurrentPage('agents')} />;
      default:
        return <AgentsPage onAgentSelect={handleAgentSelect} />;
    }
  };

  return (
    <UserProvider>
      <div className="flex h-screen overflow-hidden bg-background">
        {currentPage !== 'persona-dashboard' && (
          <Sidebar
            currentPage={currentPage}
            onNavigate={(page) => setCurrentPage(page)}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          />
        )}
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {currentPage !== 'persona-dashboard' && (
            <header className="border-b bg-card px-8 py-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <h1 className="text-xl">Agentic Dashboard & Monitoring</h1>
              </div>
              <Button
                onClick={() => setCurrentPage('persona-dashboard')}
                className="bg-purple-500 hover:bg-purple-600"
              >
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Persona Dashboards
              </Button>
            </header>
          )}
          
          <main className="flex-1 overflow-auto">
            {renderPage()}
          </main>
        </div>
      </div>
      <Toaster />
    </UserProvider>
  );
}