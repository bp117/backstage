import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Star,
  Users,
  ArrowUp,
  ArrowDown,
  Download,
  Calendar,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { AgenticDrillDown } from './AgenticDrillDown';

const kpiCards = [
  { label: 'Total Cost', value: '$4,567', change: '-12%', trend: 'down', icon: DollarSign, color: 'text-green-500' },
  { label: 'Success Rate', value: '94.2%', change: '+3%', trend: 'up', icon: TrendingUp, color: 'text-blue-500' },
  { label: 'User Satisfaction', value: '4.7/5', change: '+0.2', trend: 'up', icon: Star, color: 'text-yellow-500' },
  { label: 'Active Users', value: '1,247', change: '+156', trend: 'up', icon: Users, color: 'text-purple-500' },
];

const performanceData = [
  { date: 'Jan 8', requests: 4200, success: 3950, latency: 340 },
  { date: 'Jan 9', requests: 4500, success: 4250, latency: 320 },
  { date: 'Jan 10', requests: 4100, success: 3900, latency: 350 },
  { date: 'Jan 11', requests: 4800, success: 4600, latency: 310 },
  { date: 'Jan 12', requests: 5200, success: 4950, latency: 290 },
  { date: 'Jan 13', requests: 5000, success: 4750, latency: 300 },
  { date: 'Jan 14', requests: 5400, success: 5100, latency: 280 },
];

const agentLeaderboard = [
  { name: 'Financial Advisor', successRate: 96.8, usage: 12453, efficiency: 95, status: 'excellent' },
  { name: 'Customer Support', successRate: 94.2, usage: 8923, efficiency: 92, status: 'good' },
  { name: 'Account Manager', successRate: 91.5, usage: 6721, efficiency: 89, status: 'good' },
  { name: 'Trading Bot', successRate: 87.3, usage: 4532, efficiency: 84, status: 'warning' },
  { name: 'Analytics Assistant', successRate: 93.1, usage: 3210, efficiency: 90, status: 'good' },
];

const costBreakdown = [
  { name: 'Financial Advisor', value: 1850, color: '#3b82f6' },
  { name: 'Customer Support', value: 1234, color: '#10b981' },
  { name: 'Account Manager', value: 892, color: '#8b5cf6' },
  { name: 'Trading Bot', value: 456, color: '#f59e0b' },
  { name: 'Others', value: 135, color: '#6b7280' },
];

const teamActivity = [
  { user: 'Sarah Chen', action: 'Deployed Financial Advisor v2.1', time: '2 hours ago', type: 'deployment' },
  { user: 'Mike Johnson', action: 'Updated Customer Support workflow', time: '5 hours ago', type: 'update' },
  { user: 'Emily Davis', action: 'Fixed critical issue in Trading Bot', time: '1 day ago', type: 'fix' },
  { user: 'Alex Kumar', action: 'Reached 10,000 successful requests', time: '2 days ago', type: 'milestone' },
];

export function ManagerDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">Executive Overview</h2>
          <p className="text-sm text-muted-foreground">Business metrics and team performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="w-4 h-4 mr-2" />
            Last 7 Days
          </Button>
          <Button>
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="drilldown">Drill Down</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpiCards.map((kpi) => {
              const Icon = kpi.icon;
              const TrendIcon = kpi.trend === 'up' ? ArrowUp : ArrowDown;
              return (
                <Card key={kpi.label} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{kpi.label}</p>
                      <p className="text-2xl mt-1">{kpi.value}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <TrendIcon className={`w-3 h-3 ${kpi.color}`} />
                        <span className={`text-xs ${kpi.color}`}>{kpi.change}</span>
                        <span className="text-xs text-muted-foreground">vs last week</span>
                      </div>
                    </div>
                    <div className={`p-2 ${kpi.color.replace('text-', 'bg-')}/10 rounded-lg`}>
                      <Icon className={`w-5 h-5 ${kpi.color}`} />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Performance Trends Chart */}
          <Card className="p-6">
            <div className="mb-4">
              <h3 className="font-medium">Performance Trends</h3>
              <p className="text-sm text-muted-foreground">Request volume, success rate, and latency over time</p>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px' }}
                />
                <Legend />
                <Line type="monotone" dataKey="requests" stroke="#3b82f6" strokeWidth={2} name="Requests" />
                <Line type="monotone" dataKey="success" stroke="#10b981" strokeWidth={2} name="Successful" />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Agent Performance Leaderboard */}
            <Card className="p-6">
              <div className="mb-4">
                <h3 className="font-medium">Agent Performance Leaderboard</h3>
                <p className="text-sm text-muted-foreground">Ranked by success rate and efficiency</p>
              </div>

              <div className="space-y-3">
                {agentLeaderboard.map((agent, index) => (
                  <div key={agent.name} className="flex items-center gap-3 p-3 border rounded-lg">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-500/10 text-purple-500 font-medium">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{agent.name}</span>
                        <Badge
                          variant={
                            agent.status === 'excellent'
                              ? 'default'
                              : agent.status === 'good'
                              ? 'secondary'
                              : 'outline'
                          }
                          className={
                            agent.status === 'excellent'
                              ? 'bg-green-500'
                              : agent.status === 'warning'
                              ? 'bg-yellow-500'
                              : ''
                          }
                        >
                          {agent.successRate}%
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1">
                        <span>{agent.usage.toLocaleString()} requests</span>
                        <span>Efficiency: {agent.efficiency}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Cost Breakdown */}
            <Card className="p-6">
              <div className="mb-4">
                <h3 className="font-medium">Cost Breakdown</h3>
                <p className="text-sm text-muted-foreground">Spending by agent this month</p>
              </div>

              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={costBreakdown}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {costBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px' }}
                  />
                </PieChart>
              </ResponsiveContainer>

              <div className="mt-4 space-y-2">
                {costBreakdown.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                    </div>
                    <span className="font-medium">${item.value}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Team Activity Feed */}
          <Card className="p-6">
            <div className="mb-4">
              <h3 className="font-medium">Team Activity Feed</h3>
              <p className="text-sm text-muted-foreground">Recent deployments, updates, and milestones</p>
            </div>

            <div className="space-y-3">
              {teamActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div
                    className={`w-2 h-2 rounded-full mt-2 ${
                      activity.type === 'deployment'
                        ? 'bg-blue-500'
                        : activity.type === 'update'
                        ? 'bg-purple-500'
                        : activity.type === 'fix'
                        ? 'bg-red-500'
                        : 'bg-green-500'
                    }`}
                  />
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-medium">{activity.user}</span> {activity.action}
                    </p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Drill Down Tab */}
        <TabsContent value="drilldown">
          <AgenticDrillDown showMetrics />
        </TabsContent>
      </Tabs>
    </div>
  );
}