import { useState } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Workflow, 
  Database, 
  Settings, 
  FileText, 
  BarChart3,
  GitBranch,
  Bot,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: 'agents' | 'agent-detail' | 'workflows') => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({ currentPage, onNavigate, isCollapsed, onToggleCollapse }: SidebarProps) {
  const menuItems = [
    { id: 'agents', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'workflows', icon: Workflow, label: 'Workflows' },
    { id: 'knowledge', icon: Database, label: 'Knowledge' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'logs', icon: FileText, label: 'Logs' },
    { id: 'integrations', icon: GitBranch, label: 'Integrations' },
  ];

  return (
    <div className={`${isCollapsed ? 'w-16' : 'w-64'} border-r bg-card flex flex-col transition-all duration-300`}>
      {/* Logo */}
      <div className="h-14 border-b flex items-center px-4 gap-2 justify-between">
        {!isCollapsed && (
          <>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-md bg-foreground flex items-center justify-center">
                <Bot className="w-5 h-5 text-background" />
              </div>
              <span className="font-semibold">AgenticOS</span>
            </div>
          </>
        )}
        <button
          onClick={onToggleCollapse}
          className="p-1.5 hover:bg-accent rounded-md transition-colors"
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Menu items */}
      <nav className="flex-1 p-3 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.id === 'agents' || item.id === 'workflows') {
                  onNavigate(item.id as any);
                }
              }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
                isActive 
                  ? 'bg-accent text-accent-foreground' 
                  : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
              }`}
              title={isCollapsed ? item.label : undefined}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {!isCollapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Settings at bottom */}
      <div className="p-3 border-t">
        <button className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-muted-foreground hover:bg-accent/50 hover:text-foreground transition-colors ${isCollapsed ? 'justify-center' : ''}`}>
          <Settings className="w-4 h-4 flex-shrink-0" />
          {!isCollapsed && <span>Settings</span>}
        </button>
      </div>
    </div>
  );
}