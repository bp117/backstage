import { useState } from 'react';
import { Search, CheckCircle, XCircle, Clock as ClockIcon, Circle, Zap, MessageSquare } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Event {
  id: string;
  type: 'tool_call_started' | 'tool_call_completed' | 'agent_processing' | 'token_usage' | 'agent_response';
  title: string;
  details: string;
  timestamp: string;
  metadata?: {
    prompt?: number;
    completion?: number;
    total?: number;
  };
}

interface Goal {
  id: string;
  title: string;
  description: string;
  status: 'success' | 'failed' | 'in_progress';
  timestamp: string;
  duration: string;
  userId: string;
  events: Event[];
}

const mockGoals: Goal[] = [
  {
    id: '1',
    title: 'Retirement Investment Portfolio Review',
    description: 'User requested review of investment products and recommendations for retirement planning',
    status: 'success',
    timestamp: 'Nov 10, 2025 9:30 AM',
    duration: '2m 15s',
    userId: 'user@example.com',
    events: [
      {
        id: 'e1',
        type: 'tool_call_started',
        title: 'Tool Call Started',
        details: 'tool: retirement_goal_analyzer',
        timestamp: '9:30:15 AM'
      },
      {
        id: 'e2',
        type: 'tool_call_completed',
        title: 'Tool Call Completed',
        details: 'tool: retirement_goal_analyzer',
        timestamp: '9:30:42 AM'
      },
      {
        id: 'e3',
        type: 'agent_processing',
        title: 'Agent Processing Complete',
        details: '',
        timestamp: '9:31:05 AM'
      },
      {
        id: 'e4',
        type: 'token_usage',
        title: 'Tool Token Usage',
        details: 'tool: retirement_goal_analyzer',
        timestamp: '9:31:08 AM',
        metadata: { prompt: 456, completion: 234, total: 690 }
      },
      {
        id: 'e5',
        type: 'agent_response',
        title: 'Agent Response',
        details: '"Successfully provided retirement investment recommendations..."',
        timestamp: '9:31:45 AM'
      }
    ]
  },
  {
    id: '2',
    title: 'Risk Assessment for 401k Rebalancing',
    description: 'Analysis of risk tolerance and portfolio rebalancing strategy for existing 401k account',
    status: 'success',
    timestamp: 'Nov 9, 2025 2:15 PM',
    duration: '3m 45s',
    userId: 'john.doe@example.com',
    events: [
      {
        id: 'e1',
        type: 'tool_call_started',
        title: 'Tool Call Started',
        details: 'tool: risk_assessment_tool',
        timestamp: '2:15:10 PM'
      },
      {
        id: 'e2',
        type: 'tool_call_completed',
        title: 'Tool Call Completed',
        details: 'tool: risk_assessment_tool',
        timestamp: '2:16:22 PM'
      },
      {
        id: 'e3',
        type: 'agent_processing',
        title: 'Agent Processing Complete',
        details: '',
        timestamp: '2:17:30 PM'
      },
      {
        id: 'e4',
        type: 'token_usage',
        title: 'Tool Token Usage',
        details: 'tool: risk_assessment_tool',
        timestamp: '2:17:45 PM',
        metadata: { prompt: 523, completion: 312, total: 835 }
      },
      {
        id: 'e5',
        type: 'agent_response',
        title: 'Agent Response',
        details: '"Risk assessment completed with portfolio recommendations..."',
        timestamp: '2:18:55 PM'
      }
    ]
  },
  {
    id: '3',
    title: 'Social Security Benefits Planning',
    description: 'User inquired about optimal timing for claiming social security benefits',
    status: 'in_progress',
    timestamp: 'Nov 10, 2025 11:00 AM',
    duration: '1m 20s',
    userId: 'mary.smith@example.com',
    events: [
      {
        id: 'e1',
        type: 'tool_call_started',
        title: 'Tool Call Started',
        details: 'tool: social_security_calculator',
        timestamp: '11:00:15 AM'
      },
      {
        id: 'e2',
        type: 'agent_processing',
        title: 'Agent Processing',
        details: 'Analyzing social security claim timing...',
        timestamp: '11:01:20 AM'
      }
    ]
  },
  {
    id: '4',
    title: 'IRA Contribution Limits Query',
    description: 'User asked about IRA contribution limits and tax implications',
    status: 'failed',
    timestamp: 'Nov 8, 2025 4:30 PM',
    duration: '45s',
    userId: 'robert.jones@example.com',
    events: [
      {
        id: 'e1',
        type: 'tool_call_started',
        title: 'Tool Call Started',
        details: 'tool: ira_calculator',
        timestamp: '4:30:05 PM'
      },
      {
        id: 'e2',
        type: 'agent_processing',
        title: 'Agent Processing Failed',
        details: 'Error: Unable to retrieve current tax year data',
        timestamp: '4:30:50 PM'
      }
    ]
  },
  {
    id: '5',
    title: 'Estate Planning for Retirement Assets',
    description: 'Discussion about estate planning strategies and beneficiary designations',
    status: 'success',
    timestamp: 'Nov 7, 2025 10:45 AM',
    duration: '4m 10s',
    userId: 'sarah.wilson@example.com',
    events: [
      {
        id: 'e1',
        type: 'tool_call_started',
        title: 'Tool Call Started',
        details: 'tool: estate_planning_advisor',
        timestamp: '10:45:12 AM'
      },
      {
        id: 'e2',
        type: 'tool_call_completed',
        title: 'Tool Call Completed',
        details: 'tool: estate_planning_advisor',
        timestamp: '10:47:30 AM'
      },
      {
        id: 'e3',
        type: 'agent_processing',
        title: 'Agent Processing Complete',
        details: '',
        timestamp: '10:48:15 AM'
      },
      {
        id: 'e4',
        type: 'token_usage',
        title: 'Tool Token Usage',
        details: 'tool: estate_planning_advisor',
        timestamp: '10:48:45 AM',
        metadata: { prompt: 678, completion: 423, total: 1101 }
      },
      {
        id: 'e5',
        type: 'agent_response',
        title: 'Agent Response',
        details: '"Estate planning recommendations provided..."',
        timestamp: '10:49:22 AM'
      }
    ]
  },
  {
    id: '6',
    title: 'Healthcare Cost Estimation in Retirement',
    description: 'User requested estimates for healthcare costs and Medicare planning',
    status: 'in_progress',
    timestamp: 'Nov 10, 2025 1:30 PM',
    duration: '2m 05s',
    userId: 'david.brown@example.com',
    events: [
      {
        id: 'e1',
        type: 'tool_call_started',
        title: 'Tool Call Started',
        details: 'tool: healthcare_cost_estimator',
        timestamp: '1:30:20 PM'
      },
      {
        id: 'e2',
        type: 'tool_call_completed',
        title: 'Tool Call Completed',
        details: 'tool: healthcare_cost_estimator',
        timestamp: '1:31:45 PM'
      },
      {
        id: 'e3',
        type: 'agent_processing',
        title: 'Agent Processing',
        details: 'Calculating healthcare projections...',
        timestamp: '1:32:25 PM'
      }
    ]
  }
];

export function ConversationHistory() {
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'success' | 'failed' | 'in_progress'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);

  const filteredGoals = mockGoals.filter(goal => {
    const matchesStatus = selectedStatus === 'all' || goal.status === selectedStatus;
    const matchesSearch = goal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          goal.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusIcon = (status: Goal['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'in_progress':
        return <ClockIcon className="w-4 h-4 text-orange-600" />;
    }
  };

  const getStatusBadge = (status: Goal['status']) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-600 hover:bg-green-700">Success</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      case 'in_progress':
        return <Badge className="bg-orange-600 hover:bg-orange-700">In Progress</Badge>;
    }
  };

  const statusCounts = {
    all: mockGoals.length,
    success: mockGoals.filter(g => g.status === 'success').length,
    failed: mockGoals.filter(g => g.status === 'failed').length,
    in_progress: mockGoals.filter(g => g.status === 'in_progress').length
  };

  const getEventIcon = (type: Event['type']) => {
    switch (type) {
      case 'tool_call_started':
      case 'tool_call_completed':
        return <Circle className="w-4 h-4" />;
      case 'agent_processing':
        return <Zap className="w-4 h-4" />;
      case 'token_usage':
        return <MessageSquare className="w-4 h-4" />;
      case 'agent_response':
        return <CheckCircle className="w-4 h-4" />;
    }
  };

  const getEventColor = (type: Event['type']) => {
    switch (type) {
      case 'tool_call_started':
      case 'tool_call_completed':
        return 'bg-muted text-muted-foreground';
      case 'agent_processing':
        return 'bg-orange-500 text-white';
      case 'token_usage':
        return 'bg-blue-500 text-white';
      case 'agent_response':
        return 'bg-green-500 text-white';
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Goals List */}
      <div className={`${selectedGoal ? 'w-2/3' : 'flex-1'} flex flex-col border-r`}>
        {/* Header */}
        <div className="p-6 border-b">
          <h2 className="text-lg mb-4">Conversation History</h2>
          
          {/* Status Filters */}
          <div className="flex gap-2 mb-4">
            <Button
              variant={selectedStatus === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('all')}
            >
              All ({statusCounts.all})
            </Button>
            <Button
              variant={selectedStatus === 'success' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('success')}
              className={selectedStatus === 'success' ? 'bg-green-600 hover:bg-green-700' : ''}
            >
              Success ({statusCounts.success})
            </Button>
            <Button
              variant={selectedStatus === 'in_progress' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('in_progress')}
              className={selectedStatus === 'in_progress' ? 'bg-orange-600 hover:bg-orange-700' : ''}
            >
              In Progress ({statusCounts.in_progress})
            </Button>
            <Button
              variant={selectedStatus === 'failed' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('failed')}
              className={selectedStatus === 'failed' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              Failed ({statusCounts.failed})
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search conversations..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Goals List */}
        <div className="flex-1 overflow-auto p-4 space-y-3">
          {filteredGoals.map((goal) => (
            <div
              key={goal.id}
              onClick={() => setSelectedGoal(goal)}
              className={`border rounded-lg p-4 cursor-pointer transition-all hover:shadow-md ${
                selectedGoal?.id === goal.id ? 'border-foreground bg-accent' : 'bg-card'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  {getStatusIcon(goal.status)}
                  <h3 className="font-medium">{goal.title}</h3>
                </div>
                {getStatusBadge(goal.status)}
              </div>
              <p className="text-sm text-muted-foreground mb-3">{goal.description}</p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>{goal.timestamp}</span>
                <span>•</span>
                <span>Duration: {goal.duration}</span>
                <span>•</span>
                <span>{goal.userId}</span>
              </div>
            </div>
          ))}

          {filteredGoals.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No conversations found</p>
            </div>
          )}
        </div>
      </div>

      {/* Events Panel */}
      {selectedGoal && (
        <div className="w-1/3 flex flex-col bg-card">
          {/* Panel Header */}
          <div className="px-4 py-3 border-b">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium">Events</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedGoal(null)}
              >
                Close
              </Button>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(selectedGoal.status)}
              <span className="text-sm text-muted-foreground">{selectedGoal.title}</span>
            </div>
          </div>

          {/* Events Content */}
          <div className="flex-1 overflow-auto p-4">
            {/* Timeline */}
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-4 top-0 bottom-0 w-px bg-border" />
              
              {/* Events */}
              <div className="space-y-4">
                {selectedGoal.events.map((event) => (
                  <div key={event.id} className="relative pl-10">
                    {/* Icon */}
                    <div className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center ${getEventColor(event.type)}`}>
                      {getEventIcon(event.type)}
                    </div>
                    
                    {/* Content */}
                    <div className="pb-4">
                      <div className="text-sm font-medium mb-0.5">
                        {event.title}
                      </div>
                      {event.details && (
                        <div className="text-xs text-muted-foreground mb-1">
                          {event.details}
                        </div>
                      )}
                      {event.metadata && (
                        <div className="text-xs text-muted-foreground mb-1">
                          Prompt: {event.metadata.prompt} | Completion: {event.metadata.completion} | Total: {event.metadata.total}
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground">
                        {event.timestamp}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
