import { useState } from 'react';
import { X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { toast } from 'sonner@2.0.3';

interface ReportProblemDialogProps {
  open: boolean;
  onClose: () => void;
  appName: string;
}

export function ReportProblemDialog({ open, onClose, appName }: ReportProblemDialogProps) {
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('bug');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulate sending feedback
    toast.success('Problem report submitted successfully');
    
    // Reset form
    setSubject('');
    setDescription('');
    setCategory('bug');
    
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Report Problem - {appName}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Category */}
          <div className="space-y-2">
            <Label htmlFor="category">Problem Category</Label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full border rounded-md px-3 py-2 bg-background"
              required
            >
              <option value="bug">Bug / Error</option>
              <option value="performance">Performance Issue</option>
              <option value="incorrect_response">Incorrect Response</option>
              <option value="feature_request">Feature Request</option>
              <option value="other">Other</option>
            </select>
          </div>

          {/* Subject */}
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              type="text"
              placeholder="Brief description of the problem"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Detailed Description</Label>
            <Textarea
              id="description"
              placeholder="Please provide as much detail as possible about the issue you're experiencing..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={6}
              className="resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Submit Report
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
