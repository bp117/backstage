import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  GitBranch,
  TestTube,
  Clock,
  Zap,
  Play,
  Copy,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  AlertCircle,
} from 'lucide-react';
import { AgenticDrillDown } from './AgenticDrillDown';

const quickStats = [
  { label: 'Active Workflows', value: '12', icon: GitBranch, change: '+2' },
  { label: 'Test Runs Today', value: '47', icon: TestTube, change: '+12' },
  { label: 'Avg Response Time', value: '340ms', icon: Clock, change: '-15ms' },
  { label: 'API Quota Used', value: '67%', icon: Zap, change: '+5%' },
];

const workflows = [
  { id: '1', name: 'Financial Services Suite', status: 'active', modified: '2 hours ago', tests: 156, agents: 3 },
  { id: '2', name: 'Customer Support Platform', status: 'testing', modified: '1 day ago', tests: 89, agents: 2 },
  { id: '3', name: 'Healthcare Assistant', status: 'active', modified: '3 days ago', tests: 234, agents: 2 },
  { id: '4', name: 'Analytics Dashboard', status: 'draft', modified: '5 days ago', tests: 12, agents: 1 },
];

const testRuns = [
  { id: '1', workflow: 'Customer Onboarding', status: 'passed', time: '2 min ago', duration: '1.2s' },
  { id: '2', workflow: 'Payment Processing', status: 'passed', time: '15 min ago', duration: '0.8s' },
  { id: '3', workflow: 'Account Verification', status: 'failed', time: '1 hour ago', duration: '2.1s' },
  { id: '4', workflow: 'Customer Onboarding', status: 'passed', time: '2 hours ago', duration: '1.0s' },
];

const apiExamples = [
  { lang: 'cURL', code: 'curl -X POST https://api.example.com/agent/run' },
  { lang: 'Python', code: 'import requests\nrequests.post("https://api.example.com/agent/run")' },
  { lang: 'JavaScript', code: 'fetch("https://api.example.com/agent/run", { method: "POST" })' },
];

export function DeveloperDashboard() {
  const [selectedApiLang, setSelectedApiLang] = useState('cURL');
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl">Developer Workspace</h2>
        <p className="text-sm text-muted-foreground">Build, test, and debug your agent workflows</p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="drill-down">Apps & Agents</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickStats.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card key={stat.label} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-2xl mt-1">{stat.value}</p>
                      <p className="text-xs text-muted-foreground mt-1">{stat.change} from yesterday</p>
                    </div>
                    <div className="p-2 bg-blue-500/10 rounded-lg">
                      <Icon className="w-5 h-5 text-blue-500" />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* My Workflows */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium">My Workflows</h3>
                <p className="text-sm text-muted-foreground">Workflows you've created or modified</p>
              </div>
              <Button className="bg-blue-500 hover:bg-blue-600">
                <GitBranch className="w-4 h-4 mr-2" />
                New Workflow
              </Button>
            </div>

            <div className="space-y-2">
              {workflows.map((workflow) => (
                <div
                  key={workflow.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{workflow.name}</span>
                        <Badge
                          variant={
                            workflow.status === 'active'
                              ? 'default'
                              : workflow.status === 'testing'
                              ? 'secondary'
                              : 'outline'
                          }
                        >
                          {workflow.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Modified {workflow.modified} • {workflow.tests} test runs
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm">
                      <Play className="w-3 h-3 mr-1" />
                      Test
                    </Button>
                    <Button variant="outline" size="sm">Edit</Button>
                    <Button variant="ghost" size="sm">
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Test Runs */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-medium">Recent Test Runs</h3>
                  <p className="text-sm text-muted-foreground">Latest execution results</p>
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="w-3 h-3 mr-2" />
                  Filter
                </Button>
              </div>

              <div className="space-y-2">
                {testRuns.map((run) => (
                  <div key={run.id} className="flex items-center gap-3 p-3 border rounded-lg">
                    {run.status === 'passed' ? (
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{run.workflow}</p>
                      <p className="text-xs text-muted-foreground">
                        {run.time} • {run.duration}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">View</Button>
                  </div>
                ))}
              </div>
            </Card>

            {/* API Playground */}
            <Card className="p-6">
              <div className="mb-4">
                <h3 className="font-medium">API Playground</h3>
                <p className="text-sm text-muted-foreground">Test your endpoints</p>
              </div>

              <div className="space-y-4">
                <div className="flex gap-2">
                  {apiExamples.map((example) => (
                    <Button
                      key={example.lang}
                      variant={selectedApiLang === example.lang ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedApiLang(example.lang)}
                    >
                      {example.lang}
                    </Button>
                  ))}
                </div>

                <div className="relative">
                  <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto">
                    {apiExamples.find((e) => e.lang === selectedApiLang)?.code}
                  </pre>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>

                <Button className="w-full">
                  <Play className="w-4 h-4 mr-2" />
                  Execute Request
                </Button>
              </div>
            </Card>
          </div>

          {/* Debug Console */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium">Debug Console</h3>
                <p className="text-sm text-muted-foreground">Real-time log streaming</p>
              </div>
              <div className="flex items-center gap-2">
                <Input placeholder="Search logs..." className="w-64" />
                <Button variant="outline" size="sm">
                  <Filter className="w-3 h-3 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-xs space-y-1 h-64 overflow-y-auto">
              <div>[2024-01-15 10:23:45] INFO: Workflow execution started</div>
              <div>[2024-01-15 10:23:46] DEBUG: Loading agent configuration</div>
              <div>[2024-01-15 10:23:47] INFO: Agent initialized successfully</div>
              <div className="text-yellow-400">[2024-01-15 10:23:48] WARN: High memory usage detected</div>
              <div>[2024-01-15 10:23:49] INFO: Processing user input</div>
              <div>[2024-01-15 10:23:50] DEBUG: Calling external API</div>
              <div>[2024-01-15 10:23:51] INFO: Response received in 340ms</div>
              <div>[2024-01-15 10:23:52] INFO: Workflow completed successfully</div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="drill-down" className="space-y-6 mt-6">
          <AgenticDrillDown canEdit canTest />
        </TabsContent>
      </Tabs>
    </div>
  );
}