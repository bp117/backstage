import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Search, Filter, Download, Shield, User, Bot, Eye } from 'lucide-react';

interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  category: 'user' | 'agent' | 'permission' | 'system';
  details: string;
  ipAddress: string;
}

const mockAuditLogs: AuditEntry[] = [
  {
    id: '1',
    timestamp: '2024-01-15 10:45:32',
    user: 'Alex Admin',
    action: 'Created User',
    category: 'user',
    details: 'Added new user "Emily Developer" with Developer role',
    ipAddress: '192.168.1.100',
  },
  {
    id: '2',
    timestamp: '2024-01-15 10:42:18',
    user: 'Alex Admin',
    action: 'Updated Agent Visibility',
    category: 'agent',
    details: 'Enabled "Trading Bot" access for user "John Developer"',
    ipAddress: '192.168.1.100',
  },
  {
    id: '3',
    timestamp: '2024-01-15 10:38:55',
    user: 'Sarah Manager',
    action: 'Viewed Audit Logs',
    category: 'system',
    details: 'Accessed audit log section',
    ipAddress: '192.168.1.105',
  },
  {
    id: '4',
    timestamp: '2024-01-15 10:15:42',
    user: 'Alex Admin',
    action: 'Modified Entitlement',
    category: 'permission',
    details: 'Updated "Financial Services Access" entitlement - added 2 new agents',
    ipAddress: '192.168.1.100',
  },
  {
    id: '5',
    timestamp: '2024-01-15 09:52:11',
    user: 'Alex Admin',
    action: 'Changed User Role',
    category: 'permission',
    details: 'Changed role for "Mike Support" from Developer to Production Support',
    ipAddress: '192.168.1.100',
  },
  {
    id: '6',
    timestamp: '2024-01-15 09:30:27',
    user: 'John Developer',
    action: 'Failed Login Attempt',
    category: 'system',
    details: 'Failed authentication - incorrect password',
    ipAddress: '192.168.1.200',
  },
  {
    id: '7',
    timestamp: '2024-01-15 09:15:03',
    user: 'Alex Admin',
    action: 'Deleted User',
    category: 'user',
    details: 'Removed user "Bob Contractor" from system',
    ipAddress: '192.168.1.100',
  },
  {
    id: '8',
    timestamp: '2024-01-15 08:45:19',
    user: 'Alex Admin',
    action: 'Created Entitlement',
    category: 'permission',
    details: 'Created new entitlement "Healthcare Data Access"',
    ipAddress: '192.168.1.100',
  },
];

const categoryIcons = {
  user: User,
  agent: Bot,
  permission: Shield,
  system: Eye,
};

const categoryColors = {
  user: 'bg-blue-500',
  agent: 'bg-purple-500',
  permission: 'bg-orange-500',
  system: 'bg-green-500',
};

export function AuditLog() {
  const [logs, setLogs] = useState<AuditEntry[]>(mockAuditLogs);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = categoryFilter === 'all' || log.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  return (
    <Card className="p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium">Security & Audit Logs</h3>
            <p className="text-sm text-muted-foreground">
              Track all system activities and permission changes
            </p>
          </div>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Logs
          </Button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by user, action, or details..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="user">User Management</SelectItem>
              <SelectItem value="agent">Agent Visibility</SelectItem>
              <SelectItem value="permission">Permissions</SelectItem>
              <SelectItem value="system">System Events</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Audit Log Entries */}
        <div className="space-y-2">
          {filteredLogs.map((log) => {
            const Icon = categoryIcons[log.category];
            const color = categoryColors[log.category];

            return (
              <div
                key={log.id}
                className="flex items-start gap-3 p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className={`p-2 ${color}/10 rounded-lg mt-0.5`}>
                  <Icon className={`w-4 h-4 ${color.replace('bg-', 'text-')}`} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium">{log.action}</span>
                    <Badge variant="outline" className="text-xs">
                      {log.category}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{log.details}</p>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>By: {log.user}</span>
                    <span>•</span>
                    <span>{log.timestamp}</span>
                    <span>•</span>
                    <span>IP: {log.ipAddress}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between pt-4 border-t">
          <span className="text-sm text-muted-foreground">
            Showing {filteredLogs.length} of {logs.length} entries
          </span>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
