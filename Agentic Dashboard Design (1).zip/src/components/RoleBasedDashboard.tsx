import { useUser } from '../contexts/UserContext';
import { DeveloperDashboard } from './DeveloperDashboard';
import { ManagerDashboard } from './ManagerDashboard';
import { AdminDashboard } from './AdminDashboard';
import { ProductionSupportDashboard } from './ProductionSupportDashboard';
import { RoleIndicator } from './RoleIndicator';
import { RoleSwitcher } from './RoleSwitcher';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { UserCircle, LogOut, Settings, ArrowLeft } from 'lucide-react';

interface RoleBasedDashboardProps {
  onBackToMain?: () => void;
}

export function RoleBasedDashboard({ onBackToMain }: RoleBasedDashboardProps) {
  const { user, setUser } = useUser();

  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-2xl mb-4">Not Authenticated</h2>
          <p className="text-muted-foreground">Please log in to continue</p>
        </div>
      </div>
    );
  }

  const renderDashboard = () => {
    switch (user.role) {
      case 'developer':
        return <DeveloperDashboard />;
      case 'manager':
        return <ManagerDashboard />;
      case 'admin':
        return <AdminDashboard />;
      case 'production_support':
        return <ProductionSupportDashboard />;
      default:
        return (
          <div className="p-8">
            <p>Unknown role: {user.role}</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="flex items-center justify-between px-8 py-4">
          <div className="flex items-center gap-4">
            {onBackToMain && (
              <Button variant="ghost" size="sm" onClick={onBackToMain}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Main
              </Button>
            )}
            <h1 className="text-xl">Agentic Dashboard</h1>
            <RoleIndicator />
          </div>

          <div className="flex items-center gap-4">
            <RoleSwitcher />
            <span className="text-sm text-muted-foreground">{user.name}</span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <UserCircle className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setUser(null)}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <main className="flex-1 overflow-auto bg-background">
        {renderDashboard()}
      </main>
    </div>
  );
}