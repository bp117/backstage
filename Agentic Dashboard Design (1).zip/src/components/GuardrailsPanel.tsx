import { CheckCircle, XCircle, AlertTriangle, Shield, Target, Scale, MessageSquare, Clock, Sparkles } from 'lucide-react';
import { Badge } from './ui/badge';

interface GuardrailCheck {
  id: string;
  name: string;
  description: string;
  status: 'passed' | 'failed' | 'warning';
  score?: number;
  explanation: string;
  timestamp: string;
}

export function GuardrailsPanel() {
  const goal = {
    primary: "Provide accurate financial advice for retirement planning while maintaining regulatory compliance",
    constraints: [
      "Do not provide specific investment recommendations without proper disclaimers",
      "Ensure all advice complies with financial advisory regulations",
      "Collect necessary customer information before providing personalized advice",
      "Maintain professional and ethical communication standards"
    ]
  };

  const guardrails: GuardrailCheck[] = [
    {
      id: '1',
      name: 'Goal Drift Detection',
      description: 'Monitors whether the agent stays aligned with its primary objective or deviates into unrelated tasks',
      status: 'passed',
      score: 94,
      explanation: 'The agent maintained focus on the primary goal of providing financial retirement planning advice. All actions taken (requesting user information, discussing retirement planning context) directly support the stated objective. No tangential topics or goal drift detected throughout the conversation flow.',
      timestamp: '9:30:15 AM'
    },
    {
      id: '2',
      name: 'Step Budgeting',
      description: 'Ensures the agent operates within allocated computational steps and does not exceed resource limits',
      status: 'passed',
      score: 100,
      explanation: 'Agent completed task in 3 steps out of allocated 50-step budget (6% utilization). Resource usage is well within acceptable limits. The agent efficiently gathered requirements without unnecessary iterations or redundant processing steps.',
      timestamp: '9:30:16 AM'
    },
    {
      id: '3',
      name: 'Unsafe Tools Detection',
      description: 'Validates that the agent only uses approved tools and does not attempt to access restricted capabilities',
      status: 'passed',
      score: 100,
      explanation: 'All tool invocations were from the approved tool set: [query_knowledge_base, format_response, validate_compliance]. No attempts to access restricted tools, system commands, or external APIs detected. Tool usage patterns are consistent with authorized operations.',
      timestamp: '9:30:17 AM'
    },
    {
      id: '4',
      name: 'Loop Detection',
      description: 'Identifies repetitive patterns or infinite loops in agent reasoning or tool usage',
      status: 'warning',
      score: 78,
      explanation: 'Minor repetitive pattern detected: The agent requested similar information in slightly different phrasings across two consecutive interactions. While not a critical loop, this suggests potential optimization opportunity. Pattern observed: ["age and financial situation" → "current age and risk tolerance"]. Recommend consolidating information requests into a single structured query.',
      timestamp: '9:30:18 AM'
    }
  ];

  const overallScore = Math.round(
    guardrails.reduce((acc, g) => acc + (g.score || 0), 0) / guardrails.length
  );

  const passedCount = guardrails.filter(g => g.status === 'passed').length;
  const failedCount = guardrails.filter(g => g.status === 'failed').length;
  const warningCount = guardrails.filter(g => g.status === 'warning').length;

  return (
    <div className="p-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <Shield className="w-8 h-8" />
          <h2 className="text-2xl">Agentic Guardrails</h2>
        </div>
        <p className="text-muted-foreground">
          Automated safety and compliance validation using Judge LLM evaluation
        </p>
      </div>

      {/* Overall Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="border rounded-lg p-6 bg-card">
          <div className="text-sm text-muted-foreground mb-2">Overall Score</div>
          <div className="text-3xl font-medium mb-2">{overallScore}%</div>
          <div className="flex items-center gap-2">
            {overallScore >= 90 ? (
              <>
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm text-green-600">Excellent</span>
              </>
            ) : overallScore >= 70 ? (
              <>
                <AlertTriangle className="w-4 h-4 text-orange-600" />
                <span className="text-sm text-orange-600">Good</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-red-600" />
                <span className="text-sm text-red-600">Needs Review</span>
              </>
            )}
          </div>
        </div>

        <div className="border rounded-lg p-6 bg-card">
          <div className="text-sm text-muted-foreground mb-2">Passed</div>
          <div className="text-3xl font-medium mb-2 text-green-600">{passedCount}</div>
          <div className="text-sm text-muted-foreground">Guardrails passed</div>
        </div>

        <div className="border rounded-lg p-6 bg-card">
          <div className="text-sm text-muted-foreground mb-2">Warnings</div>
          <div className="text-3xl font-medium mb-2 text-orange-600">{warningCount}</div>
          <div className="text-sm text-muted-foreground">Needs attention</div>
        </div>

        <div className="border rounded-lg p-6 bg-card">
          <div className="text-sm text-muted-foreground mb-2">Failed</div>
          <div className="text-3xl font-medium mb-2 text-red-600">{failedCount}</div>
          <div className="text-sm text-muted-foreground">Critical issues</div>
        </div>
      </div>

      {/* Agent Goal */}
      <div className="border rounded-lg p-6 bg-card mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Target className="w-5 h-5" />
          <h3 className="text-lg font-medium">Agent Goal</h3>
        </div>
        <div className="space-y-4">
          <div>
            <div className="text-sm text-muted-foreground mb-2">Primary Objective</div>
            <p className="text-sm">{goal.primary}</p>
          </div>
          <div>
            <div className="text-sm text-muted-foreground mb-2">Constraints & Requirements</div>
            <ul className="space-y-2">
              {goal.constraints.map((constraint, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm">
                  <CheckCircle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <span>{constraint}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Guardrails Execution */}
      <div className="border rounded-lg bg-card mb-6">
        <div className="px-6 py-4 border-b">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5" />
            <h3 className="text-lg font-medium">Guardrails Execution</h3>
          </div>
        </div>
        
        <div className="p-6 space-y-4">
          {guardrails.map((guardrail) => (
            <div key={guardrail.id} className="border rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-medium">{guardrail.name}</h4>
                    {guardrail.status === 'passed' && (
                      <Badge className="bg-green-600 hover:bg-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Passed
                      </Badge>
                    )}
                    {guardrail.status === 'warning' && (
                      <Badge variant="outline" className="text-orange-600 border-orange-600">
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        Warning
                      </Badge>
                    )}
                    {guardrail.status === 'failed' && (
                      <Badge variant="destructive">
                        <XCircle className="w-3 h-3 mr-1" />
                        Failed
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{guardrail.description}</p>
                </div>
                {guardrail.score !== undefined && (
                  <div className="ml-4 text-right">
                    <div className="text-2xl font-medium">{guardrail.score}%</div>
                    <div className="text-xs text-muted-foreground">Score</div>
                  </div>
                )}
              </div>

              {/* Judge LLM Evaluation */}
              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Judge LLM Evaluation</span>
                </div>
                <p className="text-sm bg-muted/50 rounded-md p-3 border">
                  {guardrail.explanation}
                </p>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>Evaluated at {guardrail.timestamp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Final Judgment */}
      <div className="border rounded-lg p-6 bg-card">
        <div className="flex items-center gap-2 mb-4">
          <MessageSquare className="w-5 h-5" />
          <h3 className="text-lg font-medium">Final Judgment</h3>
        </div>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-600 mt-0.5" />
            <div className="flex-1">
              <div className="font-medium mb-1">Goal Achievement: Successful</div>
              <p className="text-sm text-muted-foreground">
                The agent successfully achieved the primary goal while adhering to all critical constraints. 
                The response appropriately requests necessary information before providing personalized financial 
                advice, maintains regulatory compliance, and follows professional standards.
              </p>
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg p-4 border">
            <div className="text-sm font-medium mb-2">Judge LLM Recommendation</div>
            <p className="text-sm text-muted-foreground">
              The response is approved for deployment. While there is room for enhancement in response 
              completeness (providing some general retirement planning information), the current approach 
              is conservative and compliant, which is appropriate for financial advisory contexts. 
              Consider adding educational content in future iterations to improve user experience while 
              maintaining compliance standards.
            </p>
          </div>

          <div className="flex items-center justify-between pt-2 text-sm text-muted-foreground">
            <span>Evaluation Model: gpt-4-judge-v1</span>
            <span>Completed at 9:30:21 AM</span>
          </div>
        </div>
      </div>
    </div>
  );
}