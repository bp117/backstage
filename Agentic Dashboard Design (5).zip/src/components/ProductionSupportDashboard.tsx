import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  CheckCircle,
  AlertTriangle,
  XCircle,
  Activity,
  Server,
  Database,
  Cloud,
  RefreshCw,
  Search,
  Filter,
  Bell,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { AgenticDrillDown } from './AgenticDrillDown';
import { GuardrailsPanel } from './GuardrailsPanel';

const systemHealth = [
  { label: 'System Status', value: 'Healthy', status: 'success', icon: CheckCircle },
  { label: 'Active Alerts', value: '2', status: 'warning', icon: AlertTriangle },
  { label: 'Avg Uptime', value: '99.8%', status: 'success', icon: Activity },
  { label: 'Error Rate', value: '0.3%', status: 'success', icon: XCircle },
];

const alerts = [
  {
    id: '1',
    severity: 'critical',
    title: 'High Memory Usage',
    service: 'Financial Advisor Agent',
    time: '5 min ago',
    status: 'active',
  },
  {
    id: '2',
    severity: 'warning',
    title: 'Increased Response Time',
    service: 'Customer Support Bot',
    time: '23 min ago',
    status: 'active',
  },
  {
    id: '3',
    severity: 'info',
    title: 'Deployment Completed',
    service: 'Trading Bot v2.0',
    time: '1 hour ago',
    status: 'resolved',
  },
];

const incidents = [
  {
    id: 'INC-2401',
    title: 'Database Connection Timeout',
    status: 'investigating',
    assignee: 'Mike Johnson',
    priority: 'high',
    created: '15 min ago',
  },
  {
    id: 'INC-2402',
    title: 'API Rate Limit Exceeded',
    status: 'new',
    assignee: 'Unassigned',
    priority: 'medium',
    created: '45 min ago',
  },
  {
    id: 'INC-2403',
    title: 'Agent Response Degradation',
    status: 'resolved',
    assignee: 'Sarah Chen',
    priority: 'high',
    created: '3 hours ago',
  },
];

const services = [
  { name: 'Agent Runtime', status: 'healthy', latency: '45ms', errors: 12, uptime: 99.9 },
  { name: 'API Gateway', status: 'healthy', latency: '23ms', errors: 3, uptime: 99.95 },
  { name: 'Database', status: 'warning', latency: '156ms', errors: 89, uptime: 99.2 },
  { name: 'Cache Layer', status: 'healthy', latency: '8ms', errors: 0, uptime: 100 },
];

const metricsData = [
  { time: '10:00', responseTime: 340, errorRate: 0.5 },
  { time: '10:05', responseTime: 320, errorRate: 0.4 },
  { time: '10:10', responseTime: 380, errorRate: 0.8 },
  { time: '10:15', responseTime: 290, errorRate: 0.3 },
  { time: '10:20', responseTime: 310, errorRate: 0.2 },
  { time: '10:25', responseTime: 350, errorRate: 0.6 },
  { time: '10:30', responseTime: 300, errorRate: 0.3 },
];

export function ProductionSupportDashboard() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [activeTab, setActiveTab] = useState('monitoring');

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">Production Support Center</h2>
          <p className="text-sm text-muted-foreground">Monitor and manage production systems</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={autoRefresh ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={autoRefresh ? 'bg-green-500 hover:bg-green-600' : ''}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
            Auto-Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Bell className="w-4 h-4 mr-2" />
            Alerts
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          <TabsTrigger value="agents">Agents & MCPs</TabsTrigger>
        </TabsList>

        <TabsContent value="monitoring" className="space-y-6 mt-6">
          {/* System Health Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {systemHealth.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card key={stat.label} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-2xl mt-1">{stat.value}</p>
                    </div>
                    <div
                      className={`p-2 rounded-lg ${
                        stat.status === 'success'
                          ? 'bg-green-500/10'
                          : stat.status === 'warning'
                          ? 'bg-yellow-500/10'
                          : 'bg-red-500/10'
                      }`}
                    >
                      <Icon
                        className={`w-5 h-5 ${
                          stat.status === 'success'
                            ? 'text-green-500'
                            : stat.status === 'warning'
                            ? 'text-yellow-500'
                            : 'text-red-500'
                        }`}
                      />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Real-Time Alert Feed */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium">Real-Time Alert Feed</h3>
                <p className="text-sm text-muted-foreground">Active system alerts and notifications</p>
              </div>
              <Button variant="outline" size="sm">
                <Filter className="w-3 h-3 mr-2" />
                Filter
              </Button>
            </div>

            <div className="space-y-2">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`flex items-center gap-3 p-3 border rounded-lg ${
                    alert.status === 'resolved' ? 'opacity-60' : ''
                  }`}
                >
                  <div
                    className={`w-2 h-2 rounded-full ${
                      alert.severity === 'critical'
                        ? 'bg-red-500'
                        : alert.severity === 'warning'
                        ? 'bg-yellow-500'
                        : 'bg-blue-500'
                    }`}
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{alert.title}</span>
                      <Badge
                        variant={alert.severity === 'critical' ? 'destructive' : 'secondary'}
                        className={
                          alert.severity === 'warning' ? 'bg-yellow-500 text-white' : ''
                        }
                      >
                        {alert.severity}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {alert.service} • {alert.time}
                    </p>
                  </div>
                  {alert.status === 'active' && (
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm">Acknowledge</Button>
                      <Button size="sm">Resolve</Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Incident Tracker */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-medium">Incident Tracker</h3>
                  <p className="text-sm text-muted-foreground">Active and recent incidents</p>
                </div>
                <Button size="sm" className="bg-green-500 hover:bg-green-600">
                  + New Incident
                </Button>
              </div>

              <div className="space-y-2">
                {incidents.map((incident) => (
                  <div key={incident.id} className="p-3 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-muted-foreground">
                          {incident.id}
                        </span>
                        <Badge
                          variant={
                            incident.status === 'investigating'
                              ? 'default'
                              : incident.status === 'new'
                              ? 'secondary'
                              : 'outline'
                          }
                          className={incident.status === 'resolved' ? 'bg-green-500' : ''}
                        >
                          {incident.status}
                        </Badge>
                      </div>
                      <Badge
                        variant={incident.priority === 'high' ? 'destructive' : 'secondary'}
                      >
                        {incident.priority}
                      </Badge>
                    </div>
                    <p className="font-medium text-sm mb-1">{incident.title}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Assignee: {incident.assignee}</span>
                      <span>{incident.created}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Service Monitor Grid */}
            <Card className="p-6">
              <div className="mb-4">
                <h3 className="font-medium">Service Monitor</h3>
                <p className="text-sm text-muted-foreground">Real-time service health</p>
              </div>

              <div className="space-y-3">
                {services.map((service) => (
                  <div key={service.name} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{service.name}</span>
                        <Badge
                          variant={service.status === 'healthy' ? 'default' : 'secondary'}
                          className={
                            service.status === 'healthy' ? 'bg-green-500' : 'bg-yellow-500'
                          }
                        >
                          {service.status}
                        </Badge>
                      </div>
                      <Button variant="ghost" size="sm">
                        <RefreshCw className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-xs">
                      <div>
                        <p className="text-muted-foreground">Latency</p>
                        <p className="font-medium">{service.latency}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Errors</p>
                        <p className="font-medium">{service.errors}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Uptime</p>
                        <p className="font-medium">{service.uptime}%</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Performance Metrics */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium">Performance Metrics</h3>
                <p className="text-sm text-muted-foreground">Real-time response time and error rate</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="bg-green-500/10 text-green-500 border-green-500"
                >
                  ● Live
                </Badge>
                <Button variant="outline" size="sm">Last 30 min</Button>
              </div>
            </div>

            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={metricsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="time" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px' }}
                />
                <Line
                  type="monotone"
                  dataKey="responseTime"
                  stroke="#10b981"
                  strokeWidth={2}
                  name="Response Time (ms)"
                />
                <Line
                  type="monotone"
                  dataKey="errorRate"
                  stroke="#ef4444"
                  strokeWidth={2}
                  name="Error Rate (%)"
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="agents" className="space-y-6 mt-6">
          <AgenticDrillDown canTest showMetrics />
          <GuardrailsPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}