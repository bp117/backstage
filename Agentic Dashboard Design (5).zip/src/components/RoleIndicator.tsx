import { Badge } from './ui/badge';
import { useUser, Role } from '../contexts/UserContext';
import { User, BarChart3, Building2, Server, Headphones, Briefcase } from 'lucide-react';

const roleConfig: Record<Role, { label: string; icon: any; color: string }> = {
  consumer: {
    label: 'Consumer',
    icon: User,
    color: 'bg-blue-500 text-white',
  },
  manager: {
    label: 'Manager',
    icon: BarChart3,
    color: 'bg-purple-500 text-white',
  },
  lob_admin: {
    label: 'LOB Admin',
    icon: Building2,
    color: 'bg-indigo-500 text-white',
  },
  platform_admin: {
    label: 'Platform Admin',
    icon: Server,
    color: 'bg-cyan-500 text-white',
  },
  support: {
    label: 'Support',
    icon: Headphones,
    color: 'bg-green-500 text-white',
  },
  executive: {
    label: 'Executive',
    icon: Briefcase,
    color: 'bg-orange-500 text-white',
  },
};

export function RoleIndicator() {
  const { user } = useUser();

  if (!user) return null;

  const config = roleConfig[user.role];
  const Icon = config.icon;

  return (
    <Badge className={`${config.color} gap-1.5 px-3 py-1`}>
      <Icon className="w-3.5 h-3.5" />
      {config.label}
    </Badge>
  );
}