import { useState } from 'react';
import { Send, Mic, Settings, X, Maximize2, User, Bot, Circle, Zap, MessageSquare, CheckCircle, PanelRightOpen, PanelRightClose } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface Message {
  id: string;
  role: 'user' | 'agent';
  content: string;
  timestamp: string;
}

interface Event {
  id: string;
  type: 'tool_call_started' | 'tool_call_completed' | 'agent_processing' | 'token_usage' | 'agent_response';
  title: string;
  details: string;
  timestamp: string;
  metadata?: {
    prompt?: number;
    completion?: number;
    total?: number;
  };
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'user',
      content: "I'd like to review investment products and get recommendations based on my retirement goals",
      timestamp: '9:30 AM'
    },
    {
      id: '2',
      role: 'agent',
      content: `Sure, I'd be happy to help with that. However, in order to provide you with the most relevant advice, I'll need a bit more information:

1. What is your current age and when do you plan on retiring?
2. Could you please describe your risk tolerance? (High, Medium or Low)
3. What is your current financial situation? (income level, savings)
4. Do you have any existing retirement accounts? If so, what type?
5. Do you have a specific retirement goal in mind?

Please provide as much detail as possible so I can give you personalized advice for your situation.`,
      timestamp: '9:30 AM'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [showLogPanel, setShowLogPanel] = useState(true);
  const [logTab, setLogTab] = useState<'events' | 'summary' | 'execution'>('events');
  const [events, setEvents] = useState<Event[]>([
    {
      id: 'e1',
      type: 'tool_call_started',
      title: 'Tool Call Started',
      details: 'tool: msg_editor_query_change_requests',
      timestamp: '1:41:17 AM'
    },
    {
      id: 'e2',
      type: 'tool_call_completed',
      title: 'Tool Call Completed',
      details: 'tool: msg_editor_query_change_requests',
      timestamp: '1:41:24 AM'
    },
    {
      id: 'e3',
      type: 'agent_processing',
      title: 'Agent Processing Complete',
      details: '',
      timestamp: '1:41:24 AM'
    },
    {
      id: 'e4',
      type: 'token_usage',
      title: 'Tool Token Usage',
      details: 'tool: msg_editor_query_change_requests',
      timestamp: '1:41:26 AM',
      metadata: { prompt: 382, completion: 168, total: 550 }
    },
    {
      id: 'e5',
      type: 'tool_call_started',
      title: 'Tool Call Started',
      details: 'tool: msg_widget_query_eca_reports',
      timestamp: '1:41:28 AM'
    },
    {
      id: 'e6',
      type: 'tool_call_completed',
      title: 'Tool Call Completed',
      details: 'tool: msg_widget_query_eca_reports',
      timestamp: '1:41:33 AM'
    },
    {
      id: 'e7',
      type: 'agent_processing',
      title: 'Agent Processing Complete',
      details: '',
      timestamp: '1:41:33 AM'
    },
    {
      id: 'e8',
      type: 'token_usage',
      title: 'Tool Token Usage',
      details: 'tool: msg_widget_query_eca_reports',
      timestamp: '1:41:40 AM',
      metadata: { prompt: 680, completion: 158, total: 838 }
    },
    {
      id: 'e9',
      type: 'agent_response',
      title: 'Agent Response',
      details: '"Recent changes - CRQ7003..."',
      timestamp: '1:41:40 AM'
    }
  ]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    };

    setMessages([...messages, newMessage]);
    setInputValue('');

    // Simulate agent response with typing indicator
    setTimeout(() => {
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'agent',
        content: "Thank you for your query. I'm analyzing your requirements and will provide personalized recommendations based on your retirement goals.",
        timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
      };
      setMessages(prev => [...prev, agentMessage]);
      
      // Add events
      const newEvents: Event[] = [
        {
          id: `e-${Date.now()}-1`,
          type: 'tool_call_started',
          title: 'Tool Call Started',
          details: 'tool: retirement_analysis',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        },
        {
          id: `e-${Date.now()}-2`,
          type: 'tool_call_completed',
          title: 'Tool Call Completed',
          details: 'tool: retirement_analysis',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        },
        {
          id: `e-${Date.now()}-3`,
          type: 'agent_processing',
          title: 'Agent Processing Complete',
          details: '',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        },
        {
          id: `e-${Date.now()}-4`,
          type: 'token_usage',
          title: 'Tool Token Usage',
          details: 'tool: retirement_analysis',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' }),
          metadata: { prompt: 156, completion: 89, total: 245 }
        },
        {
          id: `e-${Date.now()}-5`,
          type: 'agent_response',
          title: 'Agent Response',
          details: '"Thank you for your query..."',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })
        }
      ];
      setEvents(prev => [...prev, ...newEvents]);
    }, 1000);
  };

  const handleClearChat = () => {
    if (confirm('Are you sure you want to clear the chat history?')) {
      setMessages([]);
      setEvents([]);
    }
  };

  const getEventIcon = (type: Event['type']) => {
    switch (type) {
      case 'tool_call_started':
      case 'tool_call_completed':
        return <Circle className="w-4 h-4" />;
      case 'agent_processing':
        return <Zap className="w-4 h-4" />;
      case 'token_usage':
        return <MessageSquare className="w-4 h-4" />;
      case 'agent_response':
        return <CheckCircle className="w-4 h-4" />;
    }
  };

  const getEventColor = (type: Event['type']) => {
    switch (type) {
      case 'tool_call_started':
      case 'tool_call_completed':
        return 'bg-muted text-muted-foreground';
      case 'agent_processing':
        return 'bg-orange-500 text-white';
      case 'token_usage':
        return 'bg-blue-500 text-white';
      case 'agent_response':
        return 'bg-green-500 text-white';
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        {/* Chat Header */}
        <div className="border-b px-6 py-4 bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg">Test Conversation</h2>
              <p className="text-sm text-muted-foreground">Model: gpt-4</p>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowLogPanel(!showLogPanel)}
              >
                {showLogPanel ? (
                  <>
                    <PanelRightClose className="w-4 h-4 mr-2" />
                    Hide Panel
                  </>
                ) : (
                  <>
                    <PanelRightOpen className="w-4 h-4 mr-2" />
                    Show Panel
                  </>
                )}
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Parameters
              </Button>
              <Button variant="ghost" size="sm" onClick={handleClearChat}>
                Clear Chat
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'agent' && (
                <div className="w-8 h-8 rounded-md border bg-muted flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div className={`max-w-2xl ${message.role === 'user' ? 'order-first' : ''}`}>
                <div
                  className={`rounded-lg px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-foreground text-background ml-auto'
                      : 'border bg-card'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 px-1">{message.timestamp}</p>
              </div>
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-md border bg-muted flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Input Area */}
        <div className="border-t p-4 bg-card">
          <div className="flex items-center gap-3">
            <div className="flex-1 relative">
              <Input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type a message to test the agent..."
                className="pr-10"
              />
              <button className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-accent rounded transition-colors">
                <Mic className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
            <Button onClick={handleSend} size="icon">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Log Panel */}
      {showLogPanel && (
        <div className="w-96 border-l bg-card flex flex-col">
          {/* Log Header */}
          <div className="px-4 py-3 border-b flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-medium">Events & Summary</h3>
            </div>
            <Button 
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setShowLogPanel(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Log Tabs */}
          <div className="flex border-b">
            <button
              onClick={() => setLogTab('events')}
              className={`flex-1 px-4 py-2 text-sm transition-colors ${
                logTab === 'events' 
                  ? 'border-b-2 border-foreground text-foreground' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              EVENTS
            </button>
            <button
              onClick={() => setLogTab('execution')}
              className={`flex-1 px-4 py-2 text-sm transition-colors ${
                logTab === 'execution' 
                  ? 'border-b-2 border-foreground text-foreground' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              LOGS
            </button>
            <button
              onClick={() => setLogTab('summary')}
              className={`flex-1 px-4 py-2 text-sm transition-colors ${
                logTab === 'summary' 
                  ? 'border-b-2 border-foreground text-foreground' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              SUMMARY
            </button>
          </div>

          {/* Log Content */}
          <div className="flex-1 overflow-auto">
            {logTab === 'events' && (
              <div className="p-4">
                {/* Timeline */}
                <div className="relative">
                  {/* Timeline line */}
                  <div className="absolute left-4 top-0 bottom-0 w-px bg-border" />
                  
                  {/* Events */}
                  <div className="space-y-4">
                    {events.map((event, idx) => (
                      <div key={event.id} className="relative pl-10">
                        {/* Icon */}
                        <div className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center ${getEventColor(event.type)}`}>
                          {getEventIcon(event.type)}
                        </div>
                        
                        {/* Content */}
                        <div className="pb-4">
                          <div className="text-sm font-medium mb-0.5">
                            {event.title}
                          </div>
                          {event.details && (
                            <div className="text-xs text-muted-foreground mb-1">
                              {event.details}
                            </div>
                          )}
                          {event.metadata && (
                            <div className="text-xs text-muted-foreground mb-1">
                              Prompt: {event.metadata.prompt} | Completion: {event.metadata.completion} | Total: {event.metadata.total}
                            </div>
                          )}
                          <div className="text-xs text-muted-foreground">
                            {event.timestamp}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {logTab === 'execution' && (
              <div className="p-4 space-y-4">
                {/* Status */}
                <div>
                  <div className="text-xs text-muted-foreground mb-2">STATUS</div>
                  <Badge variant="outline" className="text-green-600 border-green-600/30">
                    SUCCESS
                  </Badge>
                </div>

                {/* Time Stats */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Elapsed Time</span>
                    <span>1.2s</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Total Tokens</span>
                    <span>245</span>
                  </div>
                </div>

                {/* Input */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">INPUT</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <Maximize2 className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="bg-muted rounded-md p-3 text-xs font-mono">
                    <pre className="whitespace-pre-wrap">
{`{
  "request": {
    "business_id": "BUSINESS1"
  },
  "query": "I'd like to review investment products and get recommendations based on my retirement goals"
}`}
                    </pre>
                  </div>
                </div>

                {/* Output */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">OUTPUT</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <Maximize2 className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="bg-muted rounded-md p-3 text-xs font-mono max-h-64 overflow-auto">
                    <pre className="whitespace-pre-wrap">
{`{
  "response": "Sure, I'd be happy to help with that. However, in order to provide you with the most relevant advice, I'll need a bit more information:\\n\\n1. What is your current age and when do you plan on retiring?\\n2. Could you please describe your risk tolerance? (High, Medium or Low)\\n3. What is your current financial situation? (income level, savings)\\n4. Do you have any existing retirement accounts? If so, what type?\\n5. Do you have a specific retirement goal in mind?\\n\\nPlease provide as much detail as possible so I can give you personalized advice for your situation.",
  "metadata": {
    "model": "gpt-4",
    "tokens": {
      "prompt": 156,
      "completion": 89,
      "total": 245
    },
    "finish_reason": "stop"
  }
}`}
                    </pre>
                  </div>
                </div>

                {/* Metadata */}
                <div>
                  <div className="text-xs text-muted-foreground mb-2">METADATA</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status</span>
                      <span className="text-green-600">SUCCESS</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Executor</span>
                      <span className="text-xs">financial_advisor</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Start Time</span>
                      <span className="text-xs">7/28/2025, 9:30 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Elapsed Time</span>
                      <span className="text-xs">1.2s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Model</span>
                      <span className="text-xs">gpt-4</span>
                    </div>
                  </div>
                </div>

                {/* Tool Calls */}
                <div className="pt-4 border-t">
                  <div className="text-xs text-muted-foreground mb-2">TOOL CALLS</div>
                  <div className="space-y-2">
                    <div className="border rounded-md p-2">
                      <div className="text-xs font-medium mb-1">retirement_analysis</div>
                      <div className="text-xs text-muted-foreground">Duration: 0.8s</div>
                    </div>
                    <div className="border rounded-md p-2">
                      <div className="text-xs font-medium mb-1">portfolio_recommendation</div>
                      <div className="text-xs text-muted-foreground">Duration: 0.4s</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {logTab === 'summary' && (
              <div className="p-4 space-y-4">
                {/* Conversation Summary */}
                <div>
                  <h4 className="text-sm font-medium mb-3">Conversation Summary</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Total Messages</span>
                      <span className="font-medium">{messages.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Total Events</span>
                      <span className="font-medium">{events.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Tool Calls</span>
                      <span className="font-medium">
                        {events.filter(e => e.type === 'tool_call_completed').length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Total Tokens</span>
                      <span className="font-medium">
                        {events.reduce((acc, e) => acc + (e.metadata?.total || 0), 0)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Token Usage Breakdown */}
                <div className="pt-4 border-t">
                  <h4 className="text-sm font-medium mb-3">Token Usage</h4>
                  <div className="space-y-3">
                    {events
                      .filter(e => e.type === 'token_usage')
                      .map((event, idx) => (
                        <div key={idx} className="space-y-2">
                          <div className="text-xs text-muted-foreground truncate">
                            {event.details}
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex-1">
                              <div className="flex items-center justify-between text-xs mb-1">
                                <span>Prompt</span>
                                <span>{event.metadata?.prompt}</span>
                              </div>
                              <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-blue-500 rounded-full"
                                  style={{ 
                                    width: `${((event.metadata?.prompt || 0) / (event.metadata?.total || 1)) * 100}%` 
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex-1">
                              <div className="flex items-center justify-between text-xs mb-1">
                                <span>Completion</span>
                                <span>{event.metadata?.completion}</span>
                              </div>
                              <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-green-500 rounded-full"
                                  style={{ 
                                    width: `${((event.metadata?.completion || 0) / (event.metadata?.total || 1)) * 100}%` 
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Performance Metrics */}
                <div className="pt-4 border-t">
                  <h4 className="text-sm font-medium mb-3">Performance</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Avg Response Time</span>
                      <span className="font-medium">1.4s</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Success Rate</span>
                      <span className="font-medium text-green-600">100%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Processing Time</span>
                      <span className="font-medium">4.2s</span>
                    </div>
                  </div>
                </div>

                {/* Agent Actions */}
                <div className="pt-4 border-t">
                  <h4 className="text-sm font-medium mb-3">Agent Actions</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span>Query change requests</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span>Query ECA reports</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span>Generate response</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}