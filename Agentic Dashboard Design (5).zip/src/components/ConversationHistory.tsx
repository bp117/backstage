import { useState } from 'react';
import { Search, CheckCircle, XCircle, Clock as ClockIcon, User, Bot } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Message {
  id: string;
  role: 'user' | 'agent';
  content: string;
  timestamp: string;
}

interface Conversation {
  id: string;
  title: string;
  description: string;
  status: 'success' | 'failed' | 'in_progress';
  timestamp: string;
  duration: string;
  userId: string;
  messages: Message[];
}

const mockConversations: Conversation[] = [
  {
    id: '1',
    title: 'Retirement Investment Portfolio Review',
    description: 'User requested review of investment products and recommendations for retirement planning',
    status: 'success',
    timestamp: 'Nov 10, 2025 9:30 AM',
    duration: '2m 15s',
    userId: 'user@example.com',
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: "I'd like to review my retirement investment portfolio. I'm 45 years old and planning to retire at 65.",
        timestamp: '9:30:15 AM'
      },
      {
        id: 'm2',
        role: 'agent',
        content: "I'd be happy to help you review your retirement portfolio! To provide the most accurate recommendations, I'll need some additional information. Let me analyze your retirement timeline and goals.",
        timestamp: '9:30:42 AM'
      },
      {
        id: 'm3',
        role: 'user',
        content: 'I currently have about $250,000 in my 401(k) and contribute 10% of my salary. My risk tolerance is moderate.',
        timestamp: '9:31:05 AM'
      },
      {
        id: 'm4',
        role: 'agent',
        content: 'Based on your current situation - 20 years until retirement, $250,000 in assets, and moderate risk tolerance - I recommend a balanced portfolio allocation: 60% stocks (mix of domestic and international), 30% bonds, and 10% alternative investments. This should provide growth potential while managing risk appropriately for your timeline.',
        timestamp: '9:31:45 AM'
      }
    ]
  },
  {
    id: '2',
    title: 'Risk Assessment for 401k Rebalancing',
    description: 'Analysis of risk tolerance and portfolio rebalancing strategy for existing 401k account',
    status: 'success',
    timestamp: 'Nov 9, 2025 2:15 PM',
    duration: '3m 45s',
    userId: 'john.doe@example.com',
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: "My 401k hasn't been rebalanced in 3 years. I'm concerned about my current allocation.",
        timestamp: '2:15:10 PM'
      },
      {
        id: 'm2',
        role: 'agent',
        content: "It's important to rebalance regularly. Let me assess your current portfolio and risk tolerance. Can you tell me your age and when you plan to retire?",
        timestamp: '2:16:22 PM'
      },
      {
        id: 'm3',
        role: 'user',
        content: "I'm 52 and planning to retire at 62. I'm moderately conservative in my approach.",
        timestamp: '2:17:30 PM'
      },
      {
        id: 'm4',
        role: 'agent',
        content: 'With 10 years to retirement and a moderately conservative approach, I recommend shifting to a 50/40/10 allocation: 50% stocks, 40% bonds, and 10% cash equivalents. This provides some growth potential while reducing volatility as you approach retirement.',
        timestamp: '2:18:55 PM'
      }
    ]
  },
  {
    id: '3',
    title: 'Social Security Benefits Planning',
    description: 'User inquired about optimal timing for claiming social security benefits',
    status: 'in_progress',
    timestamp: 'Nov 10, 2025 11:00 AM',
    duration: '1m 20s',
    userId: 'mary.smith@example.com',
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: 'When should I start claiming Social Security benefits? I turn 62 next year.',
        timestamp: '11:00:15 AM'
      },
      {
        id: 'm2',
        role: 'agent',
        content: "Great question! The decision of when to claim Social Security depends on several factors. Let me analyze your situation...",
        timestamp: '11:01:20 AM'
      }
    ]
  },
  {
    id: '4',
    title: 'IRA Contribution Limits Query',
    description: 'User asked about IRA contribution limits and tax implications',
    status: 'failed',
    timestamp: 'Nov 8, 2025 4:30 PM',
    duration: '45s',
    userId: 'robert.jones@example.com',
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: 'What are the current IRA contribution limits for 2025?',
        timestamp: '4:30:05 PM'
      },
      {
        id: 'm2',
        role: 'agent',
        content: "I'm experiencing a technical issue accessing the current tax year data. Let me try again...",
        timestamp: '4:30:50 PM'
      }
    ]
  }
];

export function ConversationHistory() {
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'success' | 'failed' | 'in_progress'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);

  const filteredConversations = mockConversations.filter(conv => {
    const matchesStatus = selectedStatus === 'all' || conv.status === selectedStatus;
    const matchesSearch = conv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          conv.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusIcon = (status: Conversation['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'in_progress':
        return <ClockIcon className="w-4 h-4 text-orange-600" />;
    }
  };

  const getStatusBadge = (status: Conversation['status']) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-600 hover:bg-green-700">Success</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      case 'in_progress':
        return <Badge className="bg-orange-600 hover:bg-orange-700">In Progress</Badge>;
    }
  };

  const statusCounts = {
    all: mockConversations.length,
    success: mockConversations.filter(g => g.status === 'success').length,
    failed: mockConversations.filter(g => g.status === 'failed').length,
    in_progress: mockConversations.filter(g => g.status === 'in_progress').length
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Conversations List */}
      <div className={`${selectedConversation ? 'w-1/3' : 'flex-1'} flex flex-col border-r`}>
        {/* Header */}
        <div className="p-6 border-b">
          <h2 className="text-lg mb-4">Conversation History</h2>
          
          {/* Status Filters */}
          <div className="flex gap-2 mb-4">
            <Button
              variant={selectedStatus === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('all')}
            >
              All ({statusCounts.all})
            </Button>
            <Button
              variant={selectedStatus === 'success' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('success')}
              className={selectedStatus === 'success' ? 'bg-green-600 hover:bg-green-700' : ''}
            >
              Success ({statusCounts.success})
            </Button>
            <Button
              variant={selectedStatus === 'in_progress' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('in_progress')}
              className={selectedStatus === 'in_progress' ? 'bg-orange-600 hover:bg-orange-700' : ''}
            >
              In Progress ({statusCounts.in_progress})
            </Button>
            <Button
              variant={selectedStatus === 'failed' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedStatus('failed')}
              className={selectedStatus === 'failed' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              Failed ({statusCounts.failed})
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search conversations..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-auto p-4 space-y-3">
          {filteredConversations.map((conv) => (
            <div
              key={conv.id}
              onClick={() => setSelectedConversation(conv)}
              className={`border rounded-lg p-4 cursor-pointer transition-all hover:shadow-md ${
                selectedConversation?.id === conv.id ? 'border-foreground bg-accent' : 'bg-card'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  {getStatusIcon(conv.status)}
                  <h3 className="font-medium">{conv.title}</h3>
                </div>
                {getStatusBadge(conv.status)}
              </div>
              <p className="text-sm text-muted-foreground mb-3">{conv.description}</p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>{conv.timestamp}</span>
                <span>•</span>
                <span>Duration: {conv.duration}</span>
                <span>•</span>
                <span>{conv.userId}</span>
              </div>
            </div>
          ))}

          {filteredConversations.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No conversations found</p>
            </div>
          )}
        </div>
      </div>

      {/* Conversation Detail Panel */}
      {selectedConversation && (
        <div className="flex-1 flex flex-col bg-card">
          {/* Panel Header */}
          <div className="px-6 py-4 border-b">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {getStatusIcon(selectedConversation.status)}
                <h3 className="font-medium">{selectedConversation.title}</h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedConversation(null)}
              >
                Close
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">{selectedConversation.description}</p>
            <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
              <span>{selectedConversation.timestamp}</span>
              <span>•</span>
              <span>Duration: {selectedConversation.duration}</span>
              <span>•</span>
              <span>{selectedConversation.userId}</span>
            </div>
          </div>

          {/* Messages Content */}
          <div className="flex-1 overflow-auto p-6">
            <div className="space-y-4 max-w-3xl">
              {selectedConversation.messages.map((message) => (
                <div key={message.id} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : ''}`}>
                  {message.role === 'agent' && (
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-primary-foreground" />
                    </div>
                  )}
                  <div className={`flex-1 max-w-[80%] ${message.role === 'user' ? 'flex justify-end' : ''}`}>
                    <div className={`rounded-lg p-4 ${
                      message.role === 'user' 
                        ? 'bg-primary text-primary-foreground ml-auto' 
                        : 'bg-muted'
                    }`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs opacity-70">
                          {message.role === 'user' ? 'You' : 'Agent'}
                        </span>
                        <span className="text-xs opacity-70">{message.timestamp}</span>
                      </div>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                  {message.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
