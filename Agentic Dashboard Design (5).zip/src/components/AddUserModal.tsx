import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { AlertCircle } from 'lucide-react';

interface AddUserModalProps {
  open: boolean;
  onClose: () => void;
}

const entitlements = [
  {
    id: 'financial_services',
    name: 'Financial Services Access',
    description: 'Access to financial agents and trading bots',
    agents: ['Financial Advisor', 'Account Management', 'Trading Bot'],
  },
  {
    id: 'customer_support',
    name: 'Customer Support Tier 2',
    description: 'Full customer support access',
    agents: ['Support Agent', 'Escalation Handler', 'KB Search'],
  },
  {
    id: 'healthcare',
    name: 'Healthcare Data Access',
    description: 'Access to healthcare and medical agents',
    agents: ['Patient Assistant', 'Medical Records Agent'],
  },
  {
    id: 'admin_full',
    name: 'Admin Full Access',
    description: 'Full system access to all agents',
    agents: ['All Agents'],
  },
];

const agents = [
  { id: '1', name: 'Financial Advisor Agent', requiresEntitlement: 'financial_services' },
  { id: '2', name: 'Account Management Agent', requiresEntitlement: 'financial_services' },
  { id: '3', name: 'Trading Bot', requiresEntitlement: 'financial_services' },
  { id: '4', name: 'Support Agent', requiresEntitlement: 'customer_support' },
  { id: '5', name: 'Escalation Handler', requiresEntitlement: 'customer_support' },
  { id: '6', name: 'KB Search Agent', requiresEntitlement: 'customer_support' },
  { id: '7', name: 'Patient Assistant', requiresEntitlement: 'healthcare' },
  { id: '8', name: 'Medical Records Agent', requiresEntitlement: 'healthcare' },
];

export function AddUserModal({ open, onClose }: AddUserModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: '',
    team: '',
  });
  const [selectedEntitlements, setSelectedEntitlements] = useState<string[]>([]);
  const [selectedAgents, setSelectedAgents] = useState<string[]>([]);

  const handleEntitlementToggle = (entitlementId: string) => {
    const newEntitlements = selectedEntitlements.includes(entitlementId)
      ? selectedEntitlements.filter((id) => id !== entitlementId)
      : [...selectedEntitlements, entitlementId];
    
    setSelectedEntitlements(newEntitlements);

    // Auto-select agents based on entitlements
    if (entitlementId === 'admin_full' && newEntitlements.includes('admin_full')) {
      setSelectedAgents(agents.map(a => a.id));
    } else {
      const eligibleAgents = agents
        .filter((agent) => newEntitlements.includes(agent.requiresEntitlement))
        .map((agent) => agent.id);
      setSelectedAgents(eligibleAgents);
    }
  };

  const handleAgentToggle = (agentId: string) => {
    const agent = agents.find((a) => a.id === agentId);
    if (!agent) return;

    // Check if user has required entitlement
    if (!selectedEntitlements.includes(agent.requiresEntitlement) && agent.requiresEntitlement !== 'admin_full') {
      return;
    }

    setSelectedAgents(
      selectedAgents.includes(agentId)
        ? selectedAgents.filter((id) => id !== agentId)
        : [...selectedAgents, agentId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Add user logic here
    console.log('Adding user:', { ...formData, selectedEntitlements, selectedAgents });
    onClose();
  };

  const canSubmit = formData.name && formData.email && formData.role && selectedEntitlements.length > 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New User</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="John Doe"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="john@example.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Role *</Label>
              <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="developer">Developer</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="production_support">Production Support</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="team">Team (Optional)</Label>
              <Input
                id="team"
                value={formData.team}
                onChange={(e) => setFormData({ ...formData, team: e.target.value })}
                placeholder="Platform Team"
              />
            </div>
          </div>

          {/* Entitlements */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Label>Entitlements *</Label>
              {selectedEntitlements.length === 0 && (
                <Badge variant="destructive" className="text-xs">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Required
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              Select entitlements to grant access to specific agents
            </p>
            <div className="space-y-2">
              {entitlements.map((entitlement) => (
                <div
                  key={entitlement.id}
                  className="flex items-start gap-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <Checkbox
                    id={entitlement.id}
                    checked={selectedEntitlements.includes(entitlement.id)}
                    onCheckedChange={() => handleEntitlementToggle(entitlement.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <Label htmlFor={entitlement.id} className="cursor-pointer font-medium">
                      {entitlement.name}
                    </Label>
                    <p className="text-sm text-muted-foreground">{entitlement.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {entitlement.agents.map((agent, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {agent}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Allowed Agents */}
          {selectedEntitlements.length > 0 && (
            <div className="space-y-3">
              <Label>Allowed Agents (Based on entitlements)</Label>
              <p className="text-sm text-muted-foreground">
                You can manually override agent visibility after creation
              </p>
              <div className="grid grid-cols-2 gap-2">
                {agents.map((agent) => {
                  const hasEntitlement = selectedEntitlements.includes(agent.requiresEntitlement);
                  const isDisabled = !hasEntitlement;

                  return (
                    <div
                      key={agent.id}
                      className={`flex items-center gap-2 p-2 border rounded ${
                        isDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-muted/50'
                      }`}
                    >
                      <Checkbox
                        id={`agent-${agent.id}`}
                        checked={selectedAgents.includes(agent.id)}
                        onCheckedChange={() => handleAgentToggle(agent.id)}
                        disabled={isDisabled}
                      />
                      <Label
                        htmlFor={`agent-${agent.id}`}
                        className={`text-sm ${isDisabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                      >
                        {agent.name}
                      </Label>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!canSubmit} className="bg-orange-500 hover:bg-orange-600">
              Add User
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
