import { Plus, Activity, TrendingUp, Server, Users, Workflow, Database, Zap, ArrowUpRight, ArrowDownRight, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';

interface DashboardPageProps {
  onCreateWorkflow?: () => void;
}

export function DashboardPage({ onCreateWorkflow }: DashboardPageProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Monitor and manage your AI agents</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="icon" onClick={handleRefresh}>
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3 mb-8">
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          New Agent
        </Button>
        <Button variant="outline" onClick={onCreateWorkflow}>
          <Plus className="w-4 h-4 mr-2" />
          New Workflow
        </Button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Total Agents */}
        <div className="border rounded-lg p-6 bg-card hover:shadow-md transition-shadow group cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-md border bg-muted/30 flex items-center justify-center group-hover:bg-muted/50 transition-colors">
              <Users className="w-5 h-5 text-muted-foreground" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-3xl mb-1">24</div>
          <p className="text-sm text-muted-foreground mb-3">Active Agents</p>
          <div className="flex items-center gap-2 text-xs">
            <TrendingUp className="w-3 h-3 text-green-600" />
            <span className="text-green-600">+12%</span>
            <span className="text-muted-foreground">from last month</span>
          </div>
        </div>

        {/* Total Workflows */}
        <div className="border rounded-lg p-6 bg-card hover:shadow-md transition-shadow group cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-md border bg-muted/30 flex items-center justify-center group-hover:bg-muted/50 transition-colors">
              <Workflow className="w-5 h-5 text-muted-foreground" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-3xl mb-1">15</div>
          <p className="text-sm text-muted-foreground mb-3">Active Workflows</p>
          <div className="flex items-center gap-2 text-xs">
            <TrendingUp className="w-3 h-3 text-green-600" />
            <span className="text-green-600">+8%</span>
            <span className="text-muted-foreground">from last month</span>
          </div>
        </div>

        {/* Knowledge Hubs */}
        <div className="border rounded-lg p-6 bg-card hover:shadow-md transition-shadow group cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-md border bg-muted/30 flex items-center justify-center group-hover:bg-muted/50 transition-colors">
              <Database className="w-5 h-5 text-muted-foreground" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-3xl mb-1">3</div>
          <p className="text-sm text-muted-foreground mb-3">Knowledge Hubs</p>
          <div className="flex items-center gap-2 text-xs">
            <TrendingUp className="w-3 h-3 text-green-600" />
            <span className="text-green-600">+50%</span>
            <span className="text-muted-foreground">from last month</span>
          </div>
        </div>

        {/* API Activity */}
        <div className="border rounded-lg p-6 bg-card hover:shadow-md transition-shadow group cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-md border bg-muted/30 flex items-center justify-center group-hover:bg-muted/50 transition-colors">
              <Activity className="w-5 h-5 text-muted-foreground" />
            </div>
            <ArrowDownRight className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-3xl mb-1">12.4k</div>
          <p className="text-sm text-muted-foreground mb-3">API Requests (24h)</p>
          <div className="flex items-center gap-2 text-xs">
            <ArrowDownRight className="w-3 h-3 text-orange-600" />
            <span className="text-orange-600">-3%</span>
            <span className="text-muted-foreground">from yesterday</span>
          </div>
        </div>
      </div>

      {/* Quick Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="border rounded-lg p-4 bg-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Success Rate</p>
              <div className="text-2xl">98.5%</div>
            </div>
            <div className="w-12 h-12 rounded-full border-4 border-foreground border-t-transparent animate-spin" 
                 style={{ animationDuration: '3s', opacity: 0.2 }} />
          </div>
        </div>
        <div className="border rounded-lg p-4 bg-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Avg Response Time</p>
              <div className="text-2xl">1.2s</div>
            </div>
            <Zap className="w-8 h-8 text-muted-foreground" />
          </div>
        </div>
        <div className="border rounded-lg p-4 bg-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Active Users</p>
              <div className="text-2xl">1,243</div>
            </div>
            <Users className="w-8 h-8 text-muted-foreground" />
          </div>
        </div>
      </div>

      {/* System Health */}
      <div className="border rounded-lg p-6 bg-card">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5" />
            <h2 className="text-xl">System Health</h2>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm text-muted-foreground">All systems operational</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Response Time */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Response Time</span>
              <span className="text-sm">1.2s</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full w-[85%] bg-foreground rounded-full transition-all" />
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 text-green-600" />
              <span>12% faster than last week</span>
            </div>
          </div>

          {/* Success Rate */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Success Rate</span>
              <span className="text-sm">98.5%</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full w-[98.5%] bg-foreground rounded-full transition-all" />
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 text-green-600" />
              <span>0.3% increase this month</span>
            </div>
          </div>

          {/* System Uptime */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">System Uptime</span>
              <span className="text-sm">99.9%</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full w-[99.9%] bg-foreground rounded-full transition-all" />
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Server className="w-3 h-3" />
              <span>30 days uptime</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="mt-8 border rounded-lg p-6 bg-card">
        <h2 className="text-xl mb-4">Recent Activity</h2>
        <div className="space-y-3">
          {[
            { agent: 'Banking Agent - Payments', action: 'completed 23 conversations', time: '2 hours ago' },
            { agent: 'Customer Support Agent', action: 'handled 15 queries', time: '4 hours ago' },
            { agent: 'Financial Advisor', action: 'generated 8 reports', time: '6 hours ago' },
          ].map((activity, idx) => (
            <div key={idx} className="flex items-center justify-between py-2 border-b last:border-0">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <div>
                  <span className="text-sm font-medium">{activity.agent}</span>
                  <span className="text-sm text-muted-foreground"> {activity.action}</span>
                </div>
              </div>
              <span className="text-xs text-muted-foreground">{activity.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}