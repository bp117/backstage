import { useState, useEffect } from 'react';
import { User, Bot, Server, Database, Cloud, CheckCircle, Activity } from 'lucide-react';
import { Badge } from './ui/badge';

interface Node {
  id: string;
  position: { x: number; y: number };
  width: number;
  height: number;
  data: {
    label: string;
    status: 'online' | 'processing' | 'down';
    icon: 'user' | 'agent' | 'mcp' | 'database' | 'api';
    description: string;
    metrics: {
      requests: number;
      latency: string;
      uptime?: string;
    };
  };
}

interface Connection {
  id: string;
  source: string;
  target: string;
  label: string;
  color: string;
}

const NODE_WIDTH = 200;
const NODE_HEIGHT = 110;

const nodes: Node[] = [
  {
    id: 'user',
    position: { x: 80, y: 180 },
    width: NODE_WIDTH,
    height: NODE_HEIGHT,
    data: {
      label: 'User Interface',
      status: 'online',
      icon: 'user',
      description: 'Web & Mobile',
      metrics: { requests: 1247, latency: '45ms' }
    }
  },
  {
    id: 'agent',
    position: { x: 380, y: 180 },
    width: NODE_WIDTH,
    height: NODE_HEIGHT,
    data: {
      label: 'Financial Agent',
      status: 'processing',
      icon: 'agent',
      description: 'GPT-4 Powered',
      metrics: { requests: 1189, latency: '850ms', uptime: '99.9%' }
    }
  },
  {
    id: 'mcp',
    position: { x: 680, y: 50 },
    width: NODE_WIDTH,
    height: NODE_HEIGHT,
    data: {
      label: 'MCP Server',
      status: 'online',
      icon: 'mcp',
      description: 'Model Context Protocol',
      metrics: { requests: 456, latency: '120ms', uptime: '100%' }
    }
  },
  {
    id: 'database',
    position: { x: 680, y: 310 },
    width: NODE_WIDTH,
    height: NODE_HEIGHT,
    data: {
      label: 'Knowledge Base',
      status: 'online',
      icon: 'database',
      description: 'Vector DB',
      metrics: { requests: 892, latency: '12ms', uptime: '100%' }
    }
  },
  {
    id: 'api',
    position: { x: 980, y: 180 },
    width: NODE_WIDTH,
    height: NODE_HEIGHT,
    data: {
      label: 'External APIs',
      status: 'online',
      icon: 'api',
      description: 'Market Data',
      metrics: { requests: 234, latency: '340ms', uptime: '99.5%' }
    }
  }
];

const connections: Connection[] = [
  { id: 'c1', source: 'user', target: 'agent', label: 'Traffic', color: '#3b82f6' },
  { id: 'c2', source: 'agent', target: 'mcp', label: 'Context', color: '#10b981' },
  { id: 'c3', source: 'agent', target: 'database', label: 'Query', color: '#8b5cf6' },
  { id: 'c4', source: 'mcp', target: 'api', label: 'Tools', color: '#f59e0b' },
  { id: 'c5', source: 'database', target: 'api', label: 'Cache', color: '#ec4899' }
];

function NodeCard({ node }: { node: Node }) {
  const getIcon = () => {
    const iconClass = "w-5 h-5";
    switch (node.data.icon) {
      case 'user': return <User className={iconClass} />;
      case 'agent': return <Bot className={iconClass} />;
      case 'mcp': return <Server className={iconClass} />;
      case 'database': return <Database className={iconClass} />;
      case 'api': return <Cloud className={iconClass} />;
    }
  };

  const getBorderColor = () => {
    switch (node.data.status) {
      case 'online': return '#10b981';
      case 'processing': return '#3b82f6';
      case 'down': return '#ef4444';
    }
  };

  const getStatusIcon = () => {
    if (node.data.status === 'processing') {
      return <Activity className="w-3 h-3 text-blue-600 animate-pulse" />;
    }
    return <CheckCircle className="w-3 h-3 text-green-600" />;
  };

  const isPulsating = node.data.status === 'processing';

  return (
    <div 
      className={`absolute px-4 py-3 rounded-lg bg-card border-2 ${isPulsating ? 'animate-pulse-shadow' : 'shadow-md'}`}
      style={{ 
        left: node.position.x, 
        top: node.position.y,
        width: node.width,
        borderColor: getBorderColor(),
        ...(isPulsating && {
          boxShadow: '0 0 0 0 rgba(59, 130, 246, 0.7), 0 0 20px rgba(59, 130, 246, 0.5)',
          animation: 'pulse-glow 2s ease-in-out infinite'
        })
      }}
    >
      <div className="flex items-center gap-2 mb-2">
        {getIcon()}
        <div className="flex-1 min-w-0">
          <div className="font-medium text-xs truncate">{node.data.label}</div>
          <div className="text-[10px] text-muted-foreground truncate">{node.data.description}</div>
        </div>
        {getStatusIcon()}
      </div>
      
      <div className="grid grid-cols-2 gap-2 text-[10px]">
        <div>
          <div className="text-muted-foreground">Requests</div>
          <div className="font-medium">{node.data.metrics.requests}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Latency</div>
          <div className="font-medium">{node.data.metrics.latency}</div>
        </div>
      </div>
    </div>
  );
}

function getConnectionPath(source: Node, target: Node): string {
  // Determine the best edges to connect based on relative positions
  const sourceCenterX = source.position.x + source.width / 2;
  const sourceCenterY = source.position.y + source.height / 2;
  const targetCenterX = target.position.x + target.width / 2;
  const targetCenterY = target.position.y + target.height / 2;

  const dx = targetCenterX - sourceCenterX;
  const dy = targetCenterY - sourceCenterY;

  let sourceX: number, sourceY: number, targetX: number, targetY: number;

  // Determine connection points based on relative position
  if (Math.abs(dx) > Math.abs(dy)) {
    // Horizontal connection
    if (dx > 0) {
      // Target is to the right
      sourceX = source.position.x + source.width;
      sourceY = source.position.y + source.height / 2;
      targetX = target.position.x;
      targetY = target.position.y + target.height / 2;
    } else {
      // Target is to the left
      sourceX = source.position.x;
      sourceY = source.position.y + source.height / 2;
      targetX = target.position.x + target.width;
      targetY = target.position.y + target.height / 2;
    }
  } else {
    // Vertical connection
    if (dy > 0) {
      // Target is below
      sourceX = source.position.x + source.width / 2;
      sourceY = source.position.y + source.height;
      targetX = target.position.x + target.width / 2;
      targetY = target.position.y;
    } else {
      // Target is above
      sourceX = source.position.x + source.width / 2;
      sourceY = source.position.y;
      targetX = target.position.x + target.width / 2;
      targetY = target.position.y + target.height;
    }
  }

  // Create curved path
  const midX = (sourceX + targetX) / 2;
  const midY = (sourceY + targetY) / 2;

  return `M ${sourceX} ${sourceY} Q ${midX} ${midY}, ${targetX} ${targetY}`;
}

function getLabelPosition(source: Node, target: Node): { x: number; y: number } {
  const sourceCenterX = source.position.x + source.width / 2;
  const sourceCenterY = source.position.y + source.height / 2;
  const targetCenterX = target.position.x + target.width / 2;
  const targetCenterY = target.position.y + target.height / 2;

  const dx = targetCenterX - sourceCenterX;
  const dy = targetCenterY - sourceCenterY;

  let sourceX: number, sourceY: number, targetX: number, targetY: number;

  if (Math.abs(dx) > Math.abs(dy)) {
    // Horizontal connection
    if (dx > 0) {
      sourceX = source.position.x + source.width;
      sourceY = source.position.y + source.height / 2;
      targetX = target.position.x;
      targetY = target.position.y + target.height / 2;
    } else {
      sourceX = source.position.x;
      sourceY = source.position.y + source.height / 2;
      targetX = target.position.x + target.width;
      targetY = target.position.y + target.height / 2;
    }
  } else {
    // Vertical connection
    if (dy > 0) {
      sourceX = source.position.x + source.width / 2;
      sourceY = source.position.y + source.height;
      targetX = target.position.x + target.width / 2;
      targetY = target.position.y;
    } else {
      sourceX = source.position.x + source.width / 2;
      sourceY = source.position.y;
      targetX = target.position.x + target.width / 2;
      targetY = target.position.y + target.height;
    }
  }

  return {
    x: (sourceX + targetX) / 2,
    y: (sourceY + targetY) / 2 - 8
  };
}

export function AgentFlowGraph() {
  const [animationOffset, setAnimationOffset] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationOffset(prev => (prev + 1) % 20);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full w-full">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium mb-1">Agent Architecture</h3>
          <p className="text-sm text-muted-foreground">Real-time data flow and system status</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></div>
            <span className="text-xs">Live Traffic</span>
          </div>
          <Badge variant="outline" className="border-blue-600 text-blue-600 text-xs">
            <Activity className="w-3 h-3 mr-1" />
            Processing
          </Badge>
        </div>
      </div>
      
      <div 
        className="border rounded-lg bg-card overflow-auto"
        style={{ height: '500px' }}
      >
        <div 
          className="relative bg-muted/10"
          style={{
            width: '1300px',
            height: '500px',
            backgroundImage: `
              linear-gradient(rgba(0, 0, 0, 0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 0, 0, 0.03) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px'
          }}
        >
          {/* SVG for connections - positioned absolutely to cover the entire canvas */}
          <svg 
            className="absolute inset-0 pointer-events-none" 
            style={{ 
              width: '1300px', 
              height: '500px',
              zIndex: 1 
            }}
          >
            <defs>
              {connections.map(conn => (
                <marker
                  key={`marker-${conn.id}`}
                  id={`arrow-${conn.id}`}
                  markerWidth="10"
                  markerHeight="10"
                  refX="8"
                  refY="3"
                  orient="auto"
                  markerUnits="strokeWidth"
                >
                  <polygon 
                    points="0 0, 10 3, 0 6" 
                    fill={conn.color}
                  />
                </marker>
              ))}
            </defs>
            
            {connections.map(conn => {
              const sourceNode = nodes.find(n => n.id === conn.source);
              const targetNode = nodes.find(n => n.id === conn.target);
              if (!sourceNode || !targetNode) return null;
              
              const path = getConnectionPath(sourceNode, targetNode);
              const labelPos = getLabelPosition(sourceNode, targetNode);
              
              return (
                <g key={conn.id}>
                  {/* Shadow/glow effect */}
                  <path
                    d={path}
                    stroke={conn.color}
                    strokeWidth="5"
                    fill="none"
                    opacity="0.2"
                    strokeDasharray="10 5"
                    strokeDashoffset={-animationOffset}
                  />
                  {/* Main path */}
                  <path
                    d={path}
                    stroke={conn.color}
                    strokeWidth="3"
                    fill="none"
                    markerEnd={`url(#arrow-${conn.id})`}
                    strokeDasharray="10 5"
                    strokeDashoffset={-animationOffset}
                  />
                  {/* Label background */}
                  <rect
                    x={labelPos.x - 25}
                    y={labelPos.y - 8}
                    width="50"
                    height="16"
                    fill="white"
                    rx="3"
                    opacity="0.95"
                  />
                  {/* Label text */}
                  <text
                    x={labelPos.x}
                    y={labelPos.y + 3}
                    textAnchor="middle"
                    fill={conn.color}
                    fontSize="11"
                    fontWeight="600"
                  >
                    {conn.label}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Nodes - positioned absolutely with higher z-index */}
          <div style={{ position: 'relative', zIndex: 2 }}>
            {nodes.map(node => (
              <NodeCard key={node.id} node={node} />
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
        {connections.map(conn => (
          <div key={conn.id} className="flex items-center gap-2">
            <div className="w-6 h-0.5" style={{ backgroundColor: conn.color }}></div>
            <span>{conn.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}