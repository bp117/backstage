import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Search, UserPlus, MoreVertical, Edit, Trash2, Shield } from 'lucide-react';
import { AddUserModal } from './AddUserModal';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  entitlements: string[];
  allowedAgents: number;
  status: 'active' | 'inactive';
  lastActive: string;
}

const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Developer',
    email: 'john@example.com',
    role: 'developer',
    entitlements: ['Financial Services', 'Customer Support'],
    allowedAgents: 8,
    status: 'active',
    lastActive: '5 min ago',
  },
  {
    id: '2',
    name: 'Sarah Manager',
    email: 'sarah@example.com',
    role: 'manager',
    entitlements: ['All Access'],
    allowedAgents: 24,
    status: 'active',
    lastActive: '1 hour ago',
  },
  {
    id: '3',
    name: 'Mike Support',
    email: 'mike@example.com',
    role: 'production_support',
    entitlements: ['Production Access', 'Incident Management'],
    allowedAgents: 12,
    status: 'active',
    lastActive: '2 min ago',
  },
  {
    id: '4',
    name: 'Emily Developer',
    email: 'emily@example.com',
    role: 'developer',
    entitlements: ['Financial Services'],
    allowedAgents: 5,
    status: 'active',
    lastActive: '3 hours ago',
  },
  {
    id: '5',
    name: 'Alex Admin',
    email: 'alex@example.com',
    role: 'admin',
    entitlements: ['Admin Full Access'],
    allowedAgents: 24,
    status: 'active',
    lastActive: 'Just now',
  },
];

const roleColors: Record<string, string> = {
  developer: 'bg-blue-500',
  manager: 'bg-purple-500',
  admin: 'bg-orange-500',
  production_support: 'bg-green-500',
};

const roleLabels: Record<string, string> = {
  developer: 'Developer',
  manager: 'Manager',
  admin: 'Admin',
  production_support: 'Prod Support',
};

export function UserManagementTable() {
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDeleteUser = (userId: string) => {
    setUsers(users.filter((u) => u.id !== userId));
  };

  return (
    <>
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-medium">User Management</h3>
            <p className="text-sm text-muted-foreground">
              Manage users, roles, and entitlements
            </p>
          </div>
          <Button onClick={() => setShowAddModal(true)} className="bg-orange-500 hover:bg-orange-600">
            <UserPlus className="w-4 h-4 mr-2" />
            Add User
          </Button>
        </div>

        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search users by name, email, or role..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                Filter by Role
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>All Roles</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Developer</DropdownMenuItem>
              <DropdownMenuItem>Manager</DropdownMenuItem>
              <DropdownMenuItem>Admin</DropdownMenuItem>
              <DropdownMenuItem>Production Support</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Entitlements</TableHead>
                <TableHead>Allowed Agents</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={`${roleColors[user.role]} text-white`}>
                      {roleLabels[user.role]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {user.entitlements.slice(0, 2).map((ent, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {ent}
                        </Badge>
                      ))}
                      {user.entitlements.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{user.entitlements.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">{user.allowedAgents}</span>
                    <span className="text-muted-foreground"> / 24</span>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={user.status === 'active' ? 'default' : 'secondary'}
                      className={user.status === 'active' ? 'bg-green-500' : ''}
                    >
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {user.lastActive}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit User
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Shield className="w-4 h-4 mr-2" />
                          Manage Entitlements
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => handleDeleteUser(user.id)}
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete User
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
          <span>Showing {filteredUsers.length} of {users.length} users</span>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>Previous</Button>
            <Button variant="outline" size="sm" disabled>Next</Button>
          </div>
        </div>
      </Card>

      <AddUserModal open={showAddModal} onClose={() => setShowAddModal(false)} />
    </>
  );
}
