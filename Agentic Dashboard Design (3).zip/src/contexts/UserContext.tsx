import { createContext, useContext, useState, ReactNode } from 'react';

export type Role = 'developer' | 'manager' | 'admin' | 'production_support';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  entitlements: string[];
  allowedAgents: string[];
  team?: string;
}

interface UserContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  hasPermission: (permission: string) => boolean;
  canAccessAgent: (agentId: string) => boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const rolePermissions: Record<Role, string[]> = {
  developer: [
    'view_dashboard',
    'create_workflow',
    'edit_workflow',
    'test_workflow',
    'view_own_metrics',
    'access_api_playground',
    'view_debug_logs',
  ],
  manager: [
    'view_dashboard',
    'view_all_metrics',
    'generate_reports',
    'view_cost_analysis',
    'view_team_performance',
  ],
  admin: [
    'view_dashboard',
    'create_workflow',
    'edit_workflow',
    'deploy_production',
    'manage_users',
    'manage_entitlements',
    'control_agent_visibility',
    'view_all_metrics',
    'view_audit_logs',
    'system_settings',
  ],
  production_support: [
    'view_dashboard',
    'view_production_metrics',
    'view_alerts',
    'restart_services',
    'deploy_production',
    'view_incidents',
    'access_production_logs',
  ],
};

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>({
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    entitlements: ['admin_full_access'],
    allowedAgents: ['all'],
    team: 'Platform Team',
  });

  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    return rolePermissions[user.role]?.includes(permission) || false;
  };

  const canAccessAgent = (agentId: string): boolean => {
    if (!user) return false;
    if (user.allowedAgents.includes('all')) return true;
    return user.allowedAgents.includes(agentId);
  };

  return (
    <UserContext.Provider value={{ user, setUser, hasPermission, canAccessAgent }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
