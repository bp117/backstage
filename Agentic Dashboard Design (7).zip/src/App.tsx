import { useState } from 'react';
import { UserProvider, useUser } from './contexts/UserContext';
import { Sidebar } from './components/Sidebar';
import { AgentsPage } from './components/AgentsPage';
import { SupportDashboard } from './components/SupportDashboard';
import { ExecutiveDashboard } from './components/ExecutiveDashboard';
import { AgentDetailPage } from './components/AgentDetailPage';
import { WorkflowBuilderPage } from './components/WorkflowBuilderPage';
import { RoleSwitcher } from './components/RoleSwitcher';
import { RoleIndicator } from './components/RoleIndicator';
import { Toaster } from './components/ui/sonner';

type Page = 'agents' | 'agent-detail' | 'workflows';

function AppContent() {
  const { user } = useUser();
  const [currentPage, setCurrentPage] = useState<Page>('agents');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState<string>('overview');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const handleAgentSelect = (agentId: string, tab: string = 'overview') => {
    setSelectedAgentId(agentId);
    setSelectedTab(tab);
    setCurrentPage('agent-detail');
  };

  const handleBackFromAgent = () => {
    setCurrentPage('agents');
    setSelectedAgentId(null);
  };

  const handleBackFromWorkflow = () => {
    setCurrentPage('agents');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'agents':
        // Use role-specific dashboards
        if (user?.role === 'support') {
          return <SupportDashboard onAgentSelect={handleAgentSelect} />;
        }
        if (user?.role === 'executive') {
          return <ExecutiveDashboard onAgentSelect={handleAgentSelect} />;
        }
        return <AgentsPage onAgentSelect={handleAgentSelect} />;
      case 'agent-detail':
        return selectedAgentId ? (
          <AgentDetailPage agentId={selectedAgentId} onBack={handleBackFromAgent} initialTab={selectedTab} />
        ) : null;
      case 'workflows':
        return <WorkflowBuilderPage onBack={handleBackFromWorkflow} />;
      default:
        if (user?.role === 'support') {
          return <SupportDashboard onAgentSelect={handleAgentSelect} />;
        }
        if (user?.role === 'executive') {
          return <ExecutiveDashboard onAgentSelect={handleAgentSelect} />;
        }
        return <AgentsPage onAgentSelect={handleAgentSelect} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar
        currentPage={currentPage}
        onNavigate={(page) => setCurrentPage(page)}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b bg-card px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl">Agentic Dashboard & Monitoring</h1>
            <RoleIndicator />
          </div>
          <div className="flex items-center gap-3">
            <RoleSwitcher />
          </div>
        </header>
        
        <main className="flex-1 overflow-auto">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <UserProvider>
      <AppContent />
      <Toaster />
    </UserProvider>
  );
}