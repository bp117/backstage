import { Server, Users, Activity, Calendar, CheckCircle, AlertTriangle, Wrench } from 'lucide-react';
import { Badge } from './ui/badge';

interface App {
  id: string;
  name: string;
  description: string;
  status: 'running' | 'degraded' | 'maintenance';
  version: string;
  uptime: string;
  activeUsers: number;
  lastDeployed: string;
  healthStatus: 'healthy' | 'warning' | 'maintenance';
}

interface AppCardProps {
  app: App;
  viewMode: 'grid' | 'list';
}

export function AppCard({ app, viewMode }: AppCardProps) {
  const getStatusColor = (status: App['status']) => {
    switch (status) {
      case 'running':
        return 'bg-green-500';
      case 'degraded':
        return 'bg-yellow-500';
      case 'maintenance':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: App['status']) => {
    switch (status) {
      case 'running':
        return <Badge className="bg-green-500/10 text-green-700 border-green-200">Running</Badge>;
      case 'degraded':
        return <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-200">Degraded</Badge>;
      case 'maintenance':
        return <Badge className="bg-orange-500/10 text-orange-700 border-orange-200">Maintenance</Badge>;
    }
  };

  const getHealthIcon = (healthStatus: App['healthStatus']) => {
    switch (healthStatus) {
      case 'healthy':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case 'maintenance':
        return <Wrench className="w-5 h-5 text-orange-600" />;
    }
  };

  if (viewMode === 'list') {
    return (
      <div className="border rounded-lg p-4 bg-card hover:shadow-md transition-all">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 flex-1">
            <div className="w-10 h-10 rounded-md border bg-muted/50 flex items-center justify-center flex-shrink-0">
              <Server className="w-5 h-5 text-muted-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-medium truncate">{app.name}</h3>
                <span className={`w-2 h-2 rounded-full ${getStatusColor(app.status)}`} />
              </div>
              <p className="text-sm text-muted-foreground truncate">{app.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Version</p>
              <p className="text-sm font-medium">v{app.version}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Uptime</p>
              <p className="text-sm font-medium">{app.uptime}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Active Users</p>
              <p className="text-sm font-medium">{app.activeUsers.toLocaleString()}</p>
            </div>
            <div className="flex items-center gap-2">
              {getHealthIcon(app.healthStatus)}
              {getStatusBadge(app.status)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="border rounded-lg p-5 bg-card hover:shadow-lg transition-all cursor-pointer">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-md border bg-muted/50 flex items-center justify-center flex-shrink-0">
            <Server className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-medium truncate mb-1">{app.name}</h3>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${getStatusColor(app.status)}`} />
              <span className="text-xs text-muted-foreground">v{app.version}</span>
            </div>
          </div>
        </div>
        <div>{getHealthIcon(app.healthStatus)}</div>
      </div>

      {/* Description */}
      <p className="text-sm text-muted-foreground mb-4 line-clamp-2 min-h-[40px]">
        {app.description}
      </p>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-2 rounded-md bg-muted/30 border border-dashed">
          <div className="flex items-center gap-2 mb-1">
            <Activity className="w-3.5 h-3.5 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Uptime</p>
          </div>
          <p className="font-medium">{app.uptime}</p>
        </div>
        <div className="p-2 rounded-md bg-muted/30 border border-dashed">
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-3.5 h-3.5 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Active Users</p>
          </div>
          <p className="font-medium">{app.activeUsers.toLocaleString()}</p>
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Calendar className="w-3.5 h-3.5" />
          <span>Deployed {app.lastDeployed}</span>
        </div>
        {getStatusBadge(app.status)}
      </div>
    </div>
  );
}
