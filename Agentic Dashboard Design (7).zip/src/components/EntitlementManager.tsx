import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Plus, Users, Bot, Edit, Trash2, Eye } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';

interface Entitlement {
  id: string;
  name: string;
  description: string;
  userCount: number;
  allowedAgents: string[];
  permissions: string[];
}

const mockEntitlements: Entitlement[] = [
  {
    id: '1',
    name: 'Financial Services Access',
    description: 'Access to all financial and trading agents for authorized personnel',
    userCount: 12,
    allowedAgents: ['Financial Advisor', 'Account Management', 'Trading Bot'],
    permissions: ['view_agents', 'test_workflows', 'view_metrics'],
  },
  {
    id: '2',
    name: 'Healthcare Data Access',
    description: 'Specialized access to healthcare and medical record agents',
    userCount: 8,
    allowedAgents: ['Patient Assistant', 'Medical Records Agent'],
    permissions: ['view_agents', 'view_sensitive_data'],
  },
  {
    id: '3',
    name: 'Customer Support Tier 2',
    description: 'Full customer support access with escalation capabilities',
    userCount: 23,
    allowedAgents: ['Support Agent', 'Escalation Handler', 'KB Search'],
    permissions: ['view_agents', 'handle_escalations', 'view_customer_data'],
  },
  {
    id: '4',
    name: 'Admin Full Access',
    description: 'Complete system access for administrators',
    userCount: 3,
    allowedAgents: ['All Agents'],
    permissions: ['all_permissions'],
  },
];

const availableAgents = [
  'Financial Advisor',
  'Account Management',
  'Trading Bot',
  'Support Agent',
  'Escalation Handler',
  'KB Search',
  'Patient Assistant',
  'Medical Records Agent',
  'Analytics Dashboard',
];

export function EntitlementManager() {
  const [entitlements, setEntitlements] = useState<Entitlement[]>(mockEntitlements);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingEntitlement, setEditingEntitlement] = useState<Entitlement | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    selectedAgents: [] as string[],
  });

  const handleDelete = (id: string) => {
    setEntitlements(entitlements.filter((e) => e.id !== id));
  };

  const handleEdit = (entitlement: Entitlement) => {
    setEditingEntitlement(entitlement);
    setFormData({
      name: entitlement.name,
      description: entitlement.description,
      selectedAgents: entitlement.allowedAgents,
    });
    setShowCreateModal(true);
  };

  const handleCreateNew = () => {
    setEditingEntitlement(null);
    setFormData({
      name: '',
      description: '',
      selectedAgents: [],
    });
    setShowCreateModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEntitlement) {
      // Update existing
      setEntitlements(
        entitlements.map((ent) =>
          ent.id === editingEntitlement.id
            ? {
                ...ent,
                name: formData.name,
                description: formData.description,
                allowedAgents: formData.selectedAgents,
              }
            : ent
        )
      );
    } else {
      // Create new
      const newEntitlement: Entitlement = {
        id: String(Date.now()),
        name: formData.name,
        description: formData.description,
        userCount: 0,
        allowedAgents: formData.selectedAgents,
        permissions: ['view_agents'],
      };
      setEntitlements([...entitlements, newEntitlement]);
    }
    setShowCreateModal(false);
  };

  const toggleAgent = (agent: string) => {
    setFormData({
      ...formData,
      selectedAgents: formData.selectedAgents.includes(agent)
        ? formData.selectedAgents.filter((a) => a !== agent)
        : [...formData.selectedAgents, agent],
    });
  };

  return (
    <>
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-medium">Entitlement Groups</h3>
            <p className="text-sm text-muted-foreground">
              Manage access groups and their permissions
            </p>
          </div>
          <Button onClick={handleCreateNew} className="bg-orange-500 hover:bg-orange-600">
            <Plus className="w-4 h-4 mr-2" />
            Create Entitlement
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {entitlements.map((entitlement) => (
            <Card key={entitlement.id} className="p-4 border-2">
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium">{entitlement.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      {entitlement.description}
                    </p>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">{entitlement.userCount}</span>
                    <span className="text-muted-foreground">users</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Bot className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">
                      {entitlement.allowedAgents.includes('All Agents')
                        ? 'All'
                        : entitlement.allowedAgents.length}
                    </span>
                    <span className="text-muted-foreground">agents</span>
                  </div>
                </div>

                {/* Agents */}
                <div>
                  <div className="text-xs text-muted-foreground mb-2">Grants access to:</div>
                  <div className="flex flex-wrap gap-1">
                    {entitlement.allowedAgents.map((agent, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {agent}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleEdit(entitlement)}
                  >
                    <Edit className="w-3 h-3 mr-2" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="w-3 h-3 mr-2" />
                    View Users
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:bg-destructive hover:text-white"
                    onClick={() => handleDelete(entitlement.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </Card>

      {/* Create/Edit Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingEntitlement ? 'Edit Entitlement' : 'Create New Entitlement'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Entitlement Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Financial Services Access"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe what this entitlement grants access to..."
                rows={3}
                required
              />
            </div>

            <div className="space-y-3">
              <Label>Allowed Agents *</Label>
              <p className="text-sm text-muted-foreground">
                Select which agents users with this entitlement can access
              </p>
              <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto p-3 border rounded-lg">
                {availableAgents.map((agent) => (
                  <div
                    key={agent}
                    className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded"
                  >
                    <Checkbox
                      id={`agent-${agent}`}
                      checked={formData.selectedAgents.includes(agent)}
                      onCheckedChange={() => toggleAgent(agent)}
                    />
                    <Label htmlFor={`agent-${agent}`} className="text-sm cursor-pointer">
                      {agent}
                    </Label>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                Selected: {formData.selectedAgents.length} agent(s)
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => setShowCreateModal(false)}>
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={!formData.name || !formData.description || formData.selectedAgents.length === 0}
                className="bg-orange-500 hover:bg-orange-600"
              >
                {editingEntitlement ? 'Update' : 'Create'} Entitlement
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
