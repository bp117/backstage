import { useState } from 'react';
import { 
  Users, 
  Building2, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle2,
  BarChart3,
  Settings,
  UserPlus,
  Shield,
  Activity
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

export function LOBAdminDashboard() {
  return (
    <div className="p-8 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-2">Line of Business Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Manage agents and users for your business unit - DTI (Digital Technology & Innovation)
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            LOB Settings
          </Button>
          <Button>
            <UserPlus className="w-4 h-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Users</p>
              <p className="text-3xl">342</p>
              <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +18 this month
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Active Agents</p>
              <p className="text-3xl">28</p>
              <p className="text-xs text-muted-foreground mt-2">
                Across 5 categories
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Compliance Rate</p>
              <p className="text-3xl">98%</p>
              <p className="text-xs text-green-600 mt-2">
                All policies met
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Pending Approvals</p>
              <p className="text-3xl">7</p>
              <p className="text-xs text-orange-600 mt-2">
                Requires attention
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Department Performance */}
      <Card className="p-6">
        <h2 className="text-lg mb-6">Department Performance</h2>
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-muted-foreground" />
                <span>Retail Banking</span>
              </div>
              <span className="text-sm text-muted-foreground">87%</span>
            </div>
            <Progress value={87} />
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-muted-foreground" />
                <span>Wealth Management</span>
              </div>
              <span className="text-sm text-muted-foreground">92%</span>
            </div>
            <Progress value={92} />
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-muted-foreground" />
                <span>Commercial Banking</span>
              </div>
              <span className="text-sm text-muted-foreground">78%</span>
            </div>
            <Progress value={78} />
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-muted-foreground" />
                <span>Customer Service</span>
              </div>
              <span className="text-sm text-muted-foreground">95%</span>
            </div>
            <Progress value={95} />
          </div>
        </div>
      </Card>

      {/* Agent Access & Permissions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg">Agent Access by Role</h2>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">Financial Advisors</p>
                <p className="text-sm text-muted-foreground">156 users</p>
              </div>
              <Badge>12 agents</Badge>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">Customer Service Reps</p>
                <p className="text-sm text-muted-foreground">98 users</p>
              </div>
              <Badge>8 agents</Badge>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">Branch Managers</p>
                <p className="text-sm text-muted-foreground">45 users</p>
              </div>
              <Badge>15 agents</Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg">Recent Activity</h2>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm">New agent approved: Loan Processing Assistant</p>
                <p className="text-xs text-muted-foreground">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <UserPlus className="w-4 h-4 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm">15 new users added to Retail Banking</p>
                <p className="text-xs text-muted-foreground">5 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-4 h-4 text-orange-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm">Compliance review required for 3 agents</p>
                <p className="text-xs text-muted-foreground">1 day ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                <Settings className="w-4 h-4 text-purple-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm">Updated permissions for Financial Advisors group</p>
                <p className="text-xs text-muted-foreground">2 days ago</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Pending Approvals */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg">Pending Approvals</h2>
          <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-200">
            7 items
          </Badge>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50">
            <div className="flex-1">
              <p className="font-medium">New Agent Request: Customer Onboarding Assistant</p>
              <p className="text-sm text-muted-foreground">Requested by: Sarah Johnson • 3 hours ago</p>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline">Reject</Button>
              <Button size="sm">Approve</Button>
            </div>
          </div>
          <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50">
            <div className="flex-1">
              <p className="font-medium">User Access Request: Investment Advisory Agent</p>
              <p className="text-sm text-muted-foreground">Requested by: Mike Chen • 5 hours ago</p>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline">Reject</Button>
              <Button size="sm">Approve</Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
