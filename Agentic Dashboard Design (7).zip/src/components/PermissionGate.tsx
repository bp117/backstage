import { ReactNode } from 'react';
import { useRole } from '../contexts/RoleContext';
import { Alert, AlertDescription } from './ui/alert';
import { Lock } from 'lucide-react';

interface PermissionGateProps {
  permission?: string;
  role?: string | string[];
  fallback?: ReactNode;
  children: ReactNode;
}

export function PermissionGate({ permission, role, fallback, children }: PermissionGateProps) {
  const { user, hasPermission } = useRole();

  // Check role if specified
  if (role) {
    const roles = Array.isArray(role) ? role : [role];
    if (!roles.includes(user.role)) {
      return fallback || (
        <Alert variant="destructive" className="my-4">
          <Lock className="h-4 w-4" />
          <AlertDescription>
            You don't have access to this feature. Required role: {Array.isArray(role) ? role.join(' or ') : role}
          </AlertDescription>
        </Alert>
      );
    }
  }

  // Check permission if specified
  if (permission && !hasPermission(permission)) {
    return fallback || (
      <Alert variant="destructive" className="my-4">
        <Lock className="h-4 w-4" />
        <AlertDescription>
          You don't have permission to access this feature.
        </AlertDescription>
      </Alert>
    );
  }

  return <>{children}</>;
}
