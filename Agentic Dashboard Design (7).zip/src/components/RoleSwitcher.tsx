import { useState } from 'react';
import { useUser, Role } from '../contexts/UserContext';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from './ui/dialog';
import { Card } from './ui/card';
import { User, Building2, Server, Headphones, BarChart3, Briefcase, ArrowRight } from 'lucide-react';

const roles: { role: Role; name: string; email: string; icon: any; color: string; description: string }[] = [
  {
    role: 'consumer',
    name: 'Emma Consumer',
    email: 'emma.consumer@bank.com',
    icon: User,
    color: 'bg-blue-500',
    description: 'View and use personal apps',
  },
  {
    role: 'manager',
    name: 'Sarah Manager',
    email: 'sarah.manager@bank.com',
    icon: BarChart3,
    color: 'bg-purple-500',
    description: 'View team metrics and analytics',
  },
  {
    role: 'lob_admin',
    name: 'David LOB Admin',
    email: 'david.admin@bank.com',
    icon: Building2,
    color: 'bg-indigo-500',
    description: 'Manage line of business users',
  },
  {
    role: 'platform_admin',
    name: 'Alex Platform Admin',
    email: 'alex.platform@bank.com',
    icon: Server,
    color: 'bg-cyan-500',
    description: 'Manage platform infrastructure',
  },
  {
    role: 'support',
    name: 'Mike Support',
    email: 'mike.support@bank.com',
    icon: Headphones,
    color: 'bg-green-500',
    description: 'Handle user support tickets',
  },
  {
    role: 'executive',
    name: 'Jennifer Executive',
    email: 'jennifer.exec@bank.com',
    icon: Briefcase,
    color: 'bg-orange-500',
    description: 'Strategic business insights',
  },
];

export function RoleSwitcher() {
  const { user, setUser } = useUser();
  const [open, setOpen] = useState(!user);

  const handleRoleSelect = (roleData: typeof roles[0]) => {
    setUser({
      id: String(Math.random()),
      name: roleData.name,
      email: roleData.email,
      role: roleData.role,
      entitlements: roleData.role === 'admin' ? ['admin_full_access'] : ['basic_access'],
      allowedAgents: roleData.role === 'admin' || roleData.role === 'manager' ? ['all'] : ['1', '2', '3'],
      team: 'Platform Team',
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Switch Role
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Select User Role</DialogTitle>
          <DialogDescription>
            Choose a persona to view their personalized dashboard
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4 mt-4">
          {roles.map((roleData) => {
            const Icon = roleData.icon;
            const isActive = user?.role === roleData.role;

            return (
              <Card
                key={roleData.role}
                className={`p-4 cursor-pointer transition-all hover:shadow-lg ${
                  isActive ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => handleRoleSelect(roleData)}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-3 ${roleData.color}/10 rounded-lg`}>
                    <Icon className={`w-6 h-6 ${roleData.color.replace('bg-', 'text-')}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium">{roleData.name}</h4>
                      {isActive && (
                        <span className="text-xs text-primary">Current</span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{roleData.email}</p>
                    <p className="text-xs text-muted-foreground">{roleData.description}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </Card>
            );
          })}
        </div>

        <div className="bg-muted/50 border rounded-lg p-4 mt-4">
          <p className="text-sm">
            <strong>Demo Mode:</strong> Each role has a different dashboard with role-specific features
            and permissions. Switch between roles to explore the complete system.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}