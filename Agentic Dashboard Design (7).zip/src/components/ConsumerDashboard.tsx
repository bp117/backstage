import { useState } from 'react';
import { 
  TrendingUp, 
  Activity, 
  AlertCircle,
  CheckCircle2,
  Clock,
  MessageSquare,
  BarChart3,
  Calendar,
  Search,
  Filter
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface AppMetric {
  id: string;
  name: string;
  category: string;
  usageCount: number;
  lastUsed: string;
  status: 'active' | 'idle';
  satisfaction: number;
}

const mockApps: AppMetric[] = [
  {
    id: '1',
    name: 'Retirement Planning App',
    category: 'Financial Planning',
    usageCount: 47,
    lastUsed: '2 hours ago',
    status: 'active',
    satisfaction: 4.8
  },
  {
    id: '2',
    name: 'Investment Advisor App',
    category: 'Investments',
    usageCount: 32,
    lastUsed: '5 hours ago',
    status: 'active',
    satisfaction: 4.6
  },
  {
    id: '3',
    name: 'Account Overview App',
    category: 'Banking',
    usageCount: 89,
    lastUsed: '1 hour ago',
    status: 'active',
    satisfaction: 4.9
  },
  {
    id: '4',
    name: 'Loan Calculator App',
    category: 'Banking',
    usageCount: 15,
    lastUsed: '1 day ago',
    status: 'idle',
    satisfaction: 4.5
  }
];

export function ConsumerDashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const filteredApps = mockApps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || app.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const totalInteractions = mockApps.reduce((sum, app) => sum + app.usageCount, 0);
  const activeApps = mockApps.filter(app => app.status === 'active').length;
  const avgSatisfaction = (mockApps.reduce((sum, app) => sum + app.satisfaction, 0) / mockApps.length).toFixed(1);

  return (
    <div className="p-8 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-2xl mb-2">My Apps Dashboard</h1>
        <p className="text-muted-foreground">
          Track your app usage and manage your digital experience
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Interactions</p>
              <p className="text-3xl">{totalInteractions}</p>
              <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +12% from last week
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Active Apps</p>
              <p className="text-3xl">{activeApps}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Out of {mockApps.length} total
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Avg Satisfaction</p>
              <p className="text-3xl">{avgSatisfaction}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Out of 5.0
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Last Active</p>
              <p className="text-3xl">2h</p>
              <p className="text-xs text-muted-foreground mt-2">
                Retirement Planning App
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters and Search */}
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search apps..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[200px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Financial Planning">Financial Planning</SelectItem>
            <SelectItem value="Investments">Investments</SelectItem>
            <SelectItem value="Banking">Banking</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Apps Table */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg">My Apps</h2>
            <Button variant="outline" size="sm">
              <Calendar className="w-4 h-4 mr-2" />
              Last 30 Days
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">App Name</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Category</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Usage Count</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Last Used</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Status</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Satisfaction</th>
                  <th className="text-left py-3 px-4 text-sm text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredApps.map((app) => (
                  <tr key={app.id} className="border-b hover:bg-accent/50">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
                          <BarChart3 className="w-4 h-4 text-primary" />
                        </div>
                        <span className="font-medium">{app.name}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Badge variant="outline">{app.category}</Badge>
                    </td>
                    <td className="py-4 px-4">
                      <span className="font-medium">{app.usageCount}</span>
                    </td>
                    <td className="py-4 px-4 text-muted-foreground">
                      {app.lastUsed}
                    </td>
                    <td className="py-4 px-4">
                      <Badge 
                        variant={app.status === 'active' ? 'default' : 'secondary'}
                        className={app.status === 'active' ? 'bg-green-500' : ''}
                      >
                        {app.status}
                      </Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{app.satisfaction}</span>
                        <span className="text-muted-foreground text-sm">/5.0</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Button variant="ghost" size="sm">
                        View Details
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredApps.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No apps found matching your criteria</p>
            </div>
          )}
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <MessageSquare className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium mb-1">Need Help?</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Get assistance with any app or report an issue
              </p>
              <Button size="sm" variant="outline">
                Contact Support
              </Button>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
              <BarChart3 className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium mb-1">Discover New Apps</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Explore more apps to enhance your experience
              </p>
              <Button size="sm" variant="outline">
                Browse Apps
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
