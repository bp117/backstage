import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AgentsPage } from './AgentsPage';
import { AppCard } from './AppCard';
import { Search, Grid3x3, List } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface SupportDashboardProps {
  onAgentSelect: (agentId: string, tab?: string) => void;
}

// Mock apps data - simpler app cards for production support
const mockApps = [
  {
    id: 'app-1',
    name: 'Customer Portal',
    description: 'Main customer-facing web application',
    status: 'running' as const,
    version: '3.2.1',
    uptime: '99.8%',
    activeUsers: 1245,
    lastDeployed: '2025-11-08',
    healthStatus: 'healthy' as const,
  },
  {
    id: 'app-2',
    name: 'Mobile Banking App',
    description: 'iOS and Android mobile banking application',
    status: 'running' as const,
    version: '5.1.0',
    uptime: '99.5%',
    activeUsers: 3421,
    lastDeployed: '2025-11-09',
    healthStatus: 'healthy' as const,
  },
  {
    id: 'app-3',
    name: 'Admin Dashboard',
    description: 'Internal admin and management dashboard',
    status: 'running' as const,
    version: '2.8.3',
    uptime: '99.9%',
    activeUsers: 87,
    lastDeployed: '2025-11-07',
    healthStatus: 'healthy' as const,
  },
  {
    id: 'app-4',
    name: 'Payment Gateway',
    description: 'Payment processing and transaction service',
    status: 'degraded' as const,
    version: '4.0.2',
    uptime: '98.2%',
    activeUsers: 2156,
    lastDeployed: '2025-11-10',
    healthStatus: 'warning' as const,
  },
  {
    id: 'app-5',
    name: 'Analytics Platform',
    description: 'Business intelligence and analytics platform',
    status: 'running' as const,
    version: '1.9.5',
    uptime: '99.7%',
    activeUsers: 234,
    lastDeployed: '2025-11-06',
    healthStatus: 'healthy' as const,
  },
  {
    id: 'app-6',
    name: 'Notification Service',
    description: 'Email and SMS notification service',
    status: 'running' as const,
    version: '2.3.0',
    uptime: '99.6%',
    activeUsers: 0,
    lastDeployed: '2025-11-05',
    healthStatus: 'healthy' as const,
  },
  {
    id: 'app-7',
    name: 'Document Management',
    description: 'Document storage and management system',
    status: 'maintenance' as const,
    version: '3.5.1',
    uptime: '95.4%',
    activeUsers: 0,
    lastDeployed: '2025-11-09',
    healthStatus: 'maintenance' as const,
  },
  {
    id: 'app-8',
    name: 'API Gateway',
    description: 'Central API gateway and routing service',
    status: 'running' as const,
    version: '6.2.0',
    uptime: '99.9%',
    activeUsers: 5678,
    lastDeployed: '2025-11-08',
    healthStatus: 'healthy' as const,
  },
];

export function SupportDashboard({ onAgentSelect }: SupportDashboardProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredApps = mockApps.filter(app =>
    searchQuery ? app.name.toLowerCase().includes(searchQuery.toLowerCase()) : true
  );

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Production Support Dashboard</h1>
        <p className="text-muted-foreground">Monitor and manage applications and AI agents</p>
      </div>

      <Tabs defaultValue="apps" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="apps">Apps</TabsTrigger>
          <TabsTrigger value="agents">Agents</TabsTrigger>
        </TabsList>

        <TabsContent value="apps">
          {/* Apps View - Filters */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search apps..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('grid')}
              >
                <Grid3x3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('list')}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Apps Grid */}
          <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-3'}>
            {filteredApps.map((app) => (
              <AppCard key={app.id} app={app} viewMode={viewMode} />
            ))}
          </div>

          {filteredApps.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No apps found matching your search.
            </div>
          )}
        </TabsContent>

        <TabsContent value="agents">
          {/* Agents View - Uses existing AgentsPage */}
          <AgentsPage onAgentSelect={onAgentSelect} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
