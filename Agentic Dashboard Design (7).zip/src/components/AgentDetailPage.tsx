import { useState } from 'react';
import { 
  ArrowLeft, 
  Save, 
  Settings, 
  MessageSquare, 
  Clock, 
  Sliders,
  Wrench,
  ShieldCheck,
  Zap,
  BarChart3,
  FileText,
  Download,
  Mic,
  Send,
  X,
  Maximize2,
  Users
} from 'lucide-react';
import { ChatInterfaceSimple } from './ChatInterfaceSimple';
import { ConversationHistory } from './ConversationHistory';
import { GuardrailsPanel } from './GuardrailsPanel';
import { AgentFlowGraph } from './AgentFlowGraph';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useUser } from '../contexts/UserContext';
import { UsersGrid } from './UsersGrid';
import { UserGoalsPanel } from './UserGoalsPanel';

interface AgentDetailPageProps {
  agentId: string;
  onBack: () => void;
  initialTab?: string;
}

export function AgentDetailPage({ agentId, onBack, initialTab = 'overview' }: AgentDetailPageProps) {
  const { user } = useUser();
  const [activeTab, setActiveTab] = useState(initialTab);
  const [showArchitectureGraph, setShowArchitectureGraph] = useState(false);
  const [selectedUserForGoals, setSelectedUserForGoals] = useState<{ id: string; name: string } | null>(null);

  // Disable chat for Manager role
  const isChatDisabled = user?.role === 'manager';
  const isManager = user?.role === 'manager';

  const tabs = [
    { id: 'overview', label: 'Overview', icon: FileText },
    ...(isManager ? [{ id: 'users', label: 'Users', icon: Users }] : []),
    { id: 'chat', label: 'Chat', icon: MessageSquare, disabled: isChatDisabled },
    { id: 'history', label: 'Conversation History', icon: Clock }
  ];

  const handleViewGoals = (userId: string, userName: string) => {
    setSelectedUserForGoals({ id: userId, name: userName });
  };

  const handleCloseGoals = () => {
    setSelectedUserForGoals(null);
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="border-b px-6 py-4 bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost"
              size="icon"
              onClick={onBack}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md border bg-muted flex items-center justify-center">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl">Financial Advisor - Retirement Planning</h1>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Badge variant="secondary">Draft</Badge>
                  <span className="text-muted-foreground">•</span>
                  <span>0 versions</span>
                  <span>•</span>
                  <span>0 conversations</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b bg-card">
        <div className="flex items-center gap-1 px-6">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isDisabled = tab.disabled;
            return (
              <button
                key={tab.id}
                onClick={() => !isDisabled && setActiveTab(tab.id)}
                disabled={isDisabled}
                className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors text-sm ${
                  activeTab === tab.id 
                    ? 'border-foreground text-foreground' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                } ${isDisabled ? 'opacity-40 cursor-not-allowed hover:!text-muted-foreground' : ''}`}
                title={isDisabled ? 'Chat is disabled for Manager role' : ''}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {isDisabled && <span className="text-xs">(Disabled)</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'chat' && (
        <ChatInterfaceSimple />
      )}

      {activeTab === 'overview' && (
        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-5xl mx-auto space-y-8">
            {/* What it does */}
            <div>
              <h2 className="text-2xl mb-4">What It Does</h2>
              <div className="border rounded-lg p-6 bg-card space-y-4">
                <p className="text-muted-foreground">
                  The Retirement Planning App is a specialized financial advisor that helps users make informed decisions about their retirement planning and investment strategies. This intelligent assistant analyzes user financial situations, risk tolerance, and retirement goals to provide personalized recommendations.
                </p>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Key Capabilities</h4>
                    <ul className="text-sm text-muted-foreground space-y-2">
                      <li>• Retirement goal assessment</li>
                      <li>• Risk tolerance evaluation</li>
                      <li>• Investment portfolio analysis</li>
                      <li>• Personalized recommendations</li>
                    </ul>
                  </div>
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Use Cases</h4>
                    <ul className="text-sm text-muted-foreground space-y-2">
                      <li>• Retirement planning consultations</li>
                      <li>• Investment strategy discussions</li>
                      <li>• Financial goal tracking</li>
                      <li>• Portfolio rebalancing advice</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* How to use */}
            <div>
              <h2 className="text-2xl mb-4">How To Use</h2>
              <div className="border rounded-lg p-6 bg-card space-y-4">
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center flex-shrink-0">
                      1
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Start a conversation</h4>
                      <p className="text-sm text-muted-foreground">
                        Navigate to the Chat tab and begin by describing your retirement goals and current financial situation.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center flex-shrink-0">
                      2
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Provide context</h4>
                      <p className="text-sm text-muted-foreground">
                        Share details about your age, risk tolerance, income level, and existing retirement accounts for personalized advice.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center flex-shrink-0">
                      3
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Get recommendations</h4>
                      <p className="text-sm text-muted-foreground">
                        The app will analyze your information and provide tailored retirement planning strategies and investment recommendations.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center flex-shrink-0">
                      4
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Review and refine</h4>
                      <p className="text-sm text-muted-foreground">
                        Ask follow-up questions, request clarifications, or explore alternative strategies to find the best fit for your needs.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'history' && (
        <ConversationHistory />
      )}
      
      {activeTab === 'users' && (
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 p-8 overflow-auto">
            <div className="max-w-6xl mx-auto">
              <UsersGrid onViewGoals={handleViewGoals} />
            </div>
          </div>
          {selectedUserForGoals && (
            <UserGoalsPanel
              userId={selectedUserForGoals.id}
              userName={selectedUserForGoals.name}
              onClose={handleCloseGoals}
            />
          )}
        </div>
      )}
      
      {activeTab !== 'chat' && activeTab !== 'overview' && activeTab !== 'history' && activeTab !== 'users' && (
        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-4xl">
            <div className="border rounded-lg p-12 text-center bg-card">
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 rounded-full border-2 border-dashed flex items-center justify-center">
                  {tabs.find(t => t.id === activeTab)?.icon && (
                    <>{(() => {
                      const Icon = tabs.find(t => t.id === activeTab)!.icon;
                      return <Icon className="w-8 h-8 text-muted-foreground" />;
                    })()}</>
                  )}
                </div>
              </div>
              <h3 className="text-xl mb-2">{tabs.find(t => t.id === activeTab)?.label}</h3>
              <p className="text-muted-foreground">This section is under construction</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}