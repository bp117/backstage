import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import {
  ChevronRight,
  Search,
  Layers,
  Bot,
  Database,
  Globe,
  FileText,
  Search as SearchIcon,
  Wrench,
  ArrowLeft,
  MoreVertical,
  Play,
  Edit,
  Trash2,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { agenticApps, AgenticApp, Agent, MCP } from '../data/agenticData';

type ViewLevel = 'apps' | 'agents' | 'mcps';

interface AgenticDrillDownProps {
  canEdit?: boolean;
  canDelete?: boolean;
  canTest?: boolean;
  showMetrics?: boolean;
}

const statusColors = {
  live: 'bg-green-500',
  staging: 'bg-yellow-500',
  maintenance: 'bg-red-500',
  active: 'bg-green-500',
  draft: 'bg-gray-500',
  error: 'bg-red-500',
  inactive: 'bg-gray-500',
};

const mcpIcons = {
  database: Database,
  api: Globe,
  file: FileText,
  search: SearchIcon,
  tool: Wrench,
};

export function AgenticDrillDown({
  canEdit = false,
  canDelete = false,
  canTest = false,
  showMetrics = false,
}: AgenticDrillDownProps) {
  const [viewLevel, setViewLevel] = useState<ViewLevel>('apps');
  const [selectedApp, setSelectedApp] = useState<AgenticApp | null>(null);
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleAppClick = (app: AgenticApp) => {
    setSelectedApp(app);
    setViewLevel('agents');
  };

  const handleAgentClick = (agent: Agent) => {
    setSelectedAgent(agent);
    setViewLevel('mcps');
  };

  const handleBack = () => {
    if (viewLevel === 'mcps') {
      setSelectedAgent(null);
      setViewLevel('agents');
    } else if (viewLevel === 'agents') {
      setSelectedApp(null);
      setViewLevel('apps');
    }
  };

  const filteredApps = agenticApps.filter((app) =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredAgents = selectedApp?.agents.filter((agent) =>
    agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    agent.description.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const filteredMCPs = selectedAgent?.mcps.filter((mcp) =>
    mcp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mcp.description.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-sm">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setSelectedApp(null);
            setSelectedAgent(null);
            setViewLevel('apps');
            setSearchQuery('');
          }}
          className={viewLevel === 'apps' ? 'font-medium' : 'text-muted-foreground'}
        >
          <Layers className="w-4 h-4 mr-2" />
          Agentic Apps
        </Button>

        {selectedApp && (
          <>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSelectedAgent(null);
                setViewLevel('agents');
                setSearchQuery('');
              }}
              className={viewLevel === 'agents' ? 'font-medium' : 'text-muted-foreground'}
            >
              <Bot className="w-4 h-4 mr-2" />
              {selectedApp.name}
            </Button>
          </>
        )}

        {selectedAgent && (
          <>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
            <Button
              variant="ghost"
              size="sm"
              className="font-medium"
            >
              <Database className="w-4 h-4 mr-2" />
              {selectedAgent.name}
            </Button>
          </>
        )}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder={`Search ${viewLevel}...`}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Apps View */}
      {viewLevel === 'apps' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredApps.map((app) => (
            <Card
              key={app.id}
              className="p-5 cursor-pointer hover:shadow-lg transition-all border-2"
              onClick={() => handleAppClick(app)}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Layers className="w-5 h-5 text-primary" />
                      <h3 className="font-medium">{app.name}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">{app.description}</p>
                  </div>
                  <Badge className={`${statusColors[app.status]} text-white`}>
                    {app.status}
                  </Badge>
                </div>

                <div className="flex items-center gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Category:</span>{' '}
                    <span className="font-medium">{app.category}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Version:</span>{' '}
                    <span className="font-medium">{app.version}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>{app.agents.length} agents</span>
                    <span>•</span>
                    <span>{app.users.toLocaleString()} users</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Agents View */}
      {viewLevel === 'agents' && selectedApp && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={handleBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Apps
              </Button>
              <div>
                <h3 className="font-medium">{selectedApp.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {filteredAgents.length} agents
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredAgents.map((agent) => (
              <Card
                key={agent.id}
                className="p-5 cursor-pointer hover:shadow-lg transition-all border-2"
                onClick={() => handleAgentClick(agent)}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Bot className="w-5 h-5 text-blue-500" />
                        <h4 className="font-medium">{agent.name}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">{agent.description}</p>
                    </div>
                    <Badge className={`${statusColors[agent.status]} text-white`}>
                      {agent.status}
                    </Badge>
                  </div>

                  {showMetrics && (
                    <div className="grid grid-cols-2 gap-3 pt-2 border-t">
                      <div>
                        <p className="text-xs text-muted-foreground">Success Rate</p>
                        <p className="font-medium">{agent.successRate}%</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Total Requests</p>
                        <p className="font-medium">{agent.totalRequests.toLocaleString()}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <span>{agent.mcps.length} MCPs</span>
                      <span>•</span>
                      <span>By {agent.owner}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {canTest && (
                        <Button variant="ghost" size="sm" onClick={(e) => e.stopPropagation()}>
                          <Play className="w-3 h-3" />
                        </Button>
                      )}
                      {(canEdit || canDelete) && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {canEdit && (
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit Agent
                              </DropdownMenuItem>
                            )}
                            {canDelete && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive">
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete Agent
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* MCPs View */}
      {viewLevel === 'mcps' && selectedAgent && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={handleBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Agents
              </Button>
              <div>
                <h3 className="font-medium">{selectedAgent.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {filteredMCPs.length} Model Context Protocols
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredMCPs.map((mcp) => {
              const Icon = mcpIcons[mcp.type];
              return (
                <Card key={mcp.id} className="p-4 border-2">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <div className="p-2 bg-purple-500/10 rounded-lg">
                          <Icon className="w-4 h-4 text-purple-500" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{mcp.name}</h4>
                          <Badge variant="outline" className="text-xs mt-1">
                            {mcp.type}
                          </Badge>
                        </div>
                      </div>
                      <Badge className={`${statusColors[mcp.status]} text-white text-xs`}>
                        {mcp.status}
                      </Badge>
                    </div>

                    <p className="text-sm text-muted-foreground">{mcp.description}</p>

                    {mcp.endpoint && (
                      <div className="bg-muted p-2 rounded text-xs font-mono break-all">
                        {mcp.endpoint}
                      </div>
                    )}

                    <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                      <span>Last used: {mcp.lastUsed}</span>
                      <span>{mcp.usageCount.toLocaleString()} calls</span>
                    </div>

                    {(canEdit || canDelete) && (
                      <div className="flex items-center gap-2 pt-2">
                        {canEdit && (
                          <Button variant="outline" size="sm" className="flex-1">
                            <Edit className="w-3 h-3 mr-2" />
                            Edit
                          </Button>
                        )}
                        {canTest && (
                          <Button variant="outline" size="sm" className="flex-1">
                            <Play className="w-3 h-3 mr-2" />
                            Test
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
