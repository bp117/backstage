import { useState } from 'react';
import { Users, Search, Eye } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface UserData {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'inactive';
  goals: number;
  success: number;
  failure: number;
  inProgress: number;
  hitl: number;
  lastActive: string;
}

interface UsersGridProps {
  onViewGoals: (userId: string, userName: string) => void;
}

// Mock user data
const generateMockUsers = (agentId: string): UserData[] => {
  const firstNames = ['John', 'Sarah', 'Michael', 'Emma', 'David', 'Lisa', 'Robert', 'Jennifer', 'William', 'Mary', 'James', 'Patricia', 'Christopher', 'Nancy', 'Daniel', 'Karen', 'Matthew', 'Betty', 'Anthony', 'Helen'];
  const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Wilson', 'Anderson', 'Taylor', 'Thomas', 'Moore', 'Jackson', 'Martin', 'Lee', 'Thompson', 'White'];
  
  const userCount = Math.floor(Math.random() * 15) + 10; // 10-25 users
  const users: UserData[] = [];
  
  for (let i = 0; i < userCount; i++) {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const goals = Math.floor(Math.random() * 20) + 5;
    const success = Math.floor(Math.random() * goals);
    const failure = Math.floor(Math.random() * (goals - success));
    const hitl = Math.floor(Math.random() * 3);
    const inProgress = Math.max(0, goals - success - failure - hitl);
    
    users.push({
      id: `user-${agentId}-${i}`,
      name: `${firstName} ${lastName}`,
      email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@company.com`,
      status: Math.random() > 0.2 ? 'active' : 'inactive',
      goals,
      success,
      failure,
      inProgress,
      hitl,
      lastActive: `${Math.floor(Math.random() * 30) + 1} days ago`
    });
  }
  
  return users.sort((a, b) => a.name.localeCompare(b.name));
};

export function UsersGrid({ onViewGoals }: UsersGridProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [users] = useState<UserData[]>(() => generateMockUsers('agent-1'));
  
  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Header with Search */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl mb-1">Users</h2>
          <p className="text-sm text-muted-foreground">
            {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''} found
          </p>
        </div>
        
        {/* Search */}
        <div className="relative w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search users by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="flex-1 overflow-auto p-6">
        <div className="border rounded-lg overflow-hidden bg-card">
          <table className="w-full">
            <thead className="bg-muted/50 border-b">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">User</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Status</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">Goals</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">Success</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">Failure</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">In Progress</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">HITL</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Last Active</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user, index) => (
                <tr 
                  key={user.id} 
                  className={`border-b last:border-b-0 hover:bg-muted/50 transition-colors ${
                    index % 2 === 0 ? 'bg-background' : 'bg-muted/20'
                  }`}
                >
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                      user.status === 'active' 
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' 
                        : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="font-medium">{user.goals}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="font-medium text-green-600">{user.success}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="font-medium text-red-600">{user.failure}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="font-medium text-blue-600">{user.inProgress}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="font-medium text-orange-600">{user.hitl}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-muted-foreground">{user.lastActive}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onViewGoals(user.id, user.name)}
                      className="gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      View Goals
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {filteredUsers.length === 0 && (
            <div className="p-12 text-center text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No users found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}