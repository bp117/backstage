import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Users, Zap, Activity, Layers, Server } from 'lucide-react';

interface ExecutiveDashboardProps {
  onAgentSelect?: (agentId: string, tab?: string) => void;
}

// Mock data for LOB-wise cost breakdown
const lobCostData = [
  { name: 'DTI', value: 145000, color: '#3b82f6' },
  { name: 'Retail Banking', value: 230000, color: '#10b981' },
  { name: 'Commercial Banking', value: 180000, color: '#f59e0b' },
  { name: 'Operations', value: 95000, color: '#8b5cf6' },
  { name: 'Compliance', value: 65000, color: '#ec4899' },
];

// Apps by LOB
const appsByLOB = [
  { lob: 'DTI', apps: 12, agents: 8, mcps: 24 },
  { lob: 'Retail Banking', apps: 18, agents: 15, mcps: 42 },
  { lob: 'Commercial Banking', apps: 14, agents: 11, mcps: 35 },
  { lob: 'Operations', apps: 9, agents: 6, mcps: 18 },
  { lob: 'Compliance', apps: 7, agents: 5, mcps: 15 },
];

// Monthly trend data
const monthlyTrendData = [
  { month: 'Jun', apps: 52, agents: 38, cost: 580 },
  { month: 'Jul', apps: 56, agents: 41, cost: 620 },
  { month: 'Aug', apps: 58, agents: 43, cost: 645 },
  { month: 'Sep', apps: 60, agents: 45, cost: 680 },
  { month: 'Oct', apps: 60, agents: 45, cost: 695 },
  { month: 'Nov', apps: 60, agents: 45, cost: 715 },
];

// Agent performance by LOB
const agentPerformanceData = [
  { lob: 'DTI', successful: 8540, failed: 245, hitl: 512 },
  { lob: 'Retail Banking', successful: 15420, failed: 380, hitl: 892 },
  { lob: 'Commercial Banking', successful: 11230, failed: 298, hitl: 645 },
  { lob: 'Operations', successful: 6780, failed: 156, hitl: 398 },
  { lob: 'Compliance', successful: 4890, failed: 112, hitl: 287 },
];

// MCP usage by category
const mcpUsageData = [
  { name: 'Data Processing', value: 45, color: '#3b82f6' },
  { name: 'API Integration', value: 32, color: '#10b981' },
  { name: 'Document Management', value: 28, color: '#f59e0b' },
  { name: 'Communication', value: 21, color: '#8b5cf6' },
  { name: 'Analytics', value: 18, color: '#ec4899' },
  { name: 'Security', value: 14, color: '#06b6d4' },
];

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'];

export function ExecutiveDashboard({ onAgentSelect }: ExecutiveDashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<'month' | 'quarter' | 'year'>('month');

  // Calculate summary metrics
  const totalCost = lobCostData.reduce((sum, item) => sum + item.value, 0);
  const totalApps = appsByLOB.reduce((sum, item) => sum + item.apps, 0);
  const totalAgents = appsByLOB.reduce((sum, item) => sum + item.agents, 0);
  const totalMCPs = appsByLOB.reduce((sum, item) => sum + item.mcps, 0);
  const totalExecutions = agentPerformanceData.reduce((sum, item) => sum + item.successful + item.failed + item.hitl, 0);
  const successRate = ((agentPerformanceData.reduce((sum, item) => sum + item.successful, 0) / totalExecutions) * 100).toFixed(1);

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Executive Dashboard</h1>
        <p className="text-muted-foreground">Comprehensive analytics and insights across all lines of business</p>
      </div>

      {/* Key Metrics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex items-center gap-1 text-green-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+8.2%</span>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mb-1">Total Monthly Cost</p>
          <p className="text-2xl font-semibold">${(totalCost / 1000).toFixed(0)}K</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Server className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex items-center gap-1 text-green-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+12</span>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mb-1">Total Apps</p>
          <p className="text-2xl font-semibold">{totalApps}</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex items-center gap-1 text-green-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+7</span>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mb-1">Active Agents</p>
          <p className="text-2xl font-semibold">{totalAgents}</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-orange-600" />
            </div>
            <div className="flex items-center gap-1 text-green-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+3.4%</span>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mb-1">Success Rate</p>
          <p className="text-2xl font-semibold">{successRate}%</p>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="lob-analytics">LOB Analytics</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Cost Breakdown Pie Chart */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Cost Breakdown by LOB</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={lobCostData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {lobCostData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `$${(value / 1000).toFixed(0)}K`} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 grid grid-cols-2 gap-2">
                {lobCostData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2 text-sm">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-muted-foreground">{item.name}</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* MCP Usage Pie Chart */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">MCP Usage Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={mcpUsageData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {mcpUsageData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 grid grid-cols-2 gap-2">
                {mcpUsageData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2 text-sm">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-muted-foreground">{item.name}</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Monthly Trend Line Chart */}
            <Card className="p-6 lg:col-span-2">
              <h3 className="text-lg font-semibold mb-4">6-Month Trend Analysis</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={monthlyTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="apps" stroke="#3b82f6" strokeWidth={2} name="Apps" />
                  <Line yAxisId="left" type="monotone" dataKey="agents" stroke="#10b981" strokeWidth={2} name="Agents" />
                  <Line yAxisId="right" type="monotone" dataKey="cost" stroke="#f59e0b" strokeWidth={2} name="Cost ($K)" />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </TabsContent>

        {/* LOB Analytics Tab */}
        <TabsContent value="lob-analytics">
          <div className="grid grid-cols-1 gap-6">
            {/* Apps, Agents, MCPs by LOB */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Resources by Line of Business</h3>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={appsByLOB}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="lob" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="apps" fill="#3b82f6" name="Apps" />
                  <Bar dataKey="agents" fill="#10b981" name="Agents" />
                  <Bar dataKey="mcps" fill="#f59e0b" name="MCPs" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Detailed LOB Table */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Detailed LOB Breakdown</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Line of Business</th>
                      <th className="text-right py-3 px-4">Apps</th>
                      <th className="text-right py-3 px-4">Agents</th>
                      <th className="text-right py-3 px-4">MCPs</th>
                      <th className="text-right py-3 px-4">Monthly Cost</th>
                      <th className="text-right py-3 px-4">Cost/App</th>
                    </tr>
                  </thead>
                  <tbody>
                    {appsByLOB.map((lob, index) => {
                      const cost = lobCostData.find(c => c.name === lob.lob)?.value || 0;
                      const costPerApp = (cost / lob.apps).toFixed(0);
                      return (
                        <tr key={lob.lob} className="border-b hover:bg-muted/50">
                          <td className="py-3 px-4 font-medium">{lob.lob}</td>
                          <td className="text-right py-3 px-4">{lob.apps}</td>
                          <td className="text-right py-3 px-4">{lob.agents}</td>
                          <td className="text-right py-3 px-4">{lob.mcps}</td>
                          <td className="text-right py-3 px-4">${(cost / 1000).toFixed(1)}K</td>
                          <td className="text-right py-3 px-4">${costPerApp}</td>
                        </tr>
                      );
                    })}
                    <tr className="font-semibold bg-muted/30">
                      <td className="py-3 px-4">Total</td>
                      <td className="text-right py-3 px-4">{totalApps}</td>
                      <td className="text-right py-3 px-4">{totalAgents}</td>
                      <td className="text-right py-3 px-4">{totalMCPs}</td>
                      <td className="text-right py-3 px-4">${(totalCost / 1000).toFixed(1)}K</td>
                      <td className="text-right py-3 px-4">${(totalCost / totalApps).toFixed(0)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance">
          <div className="grid grid-cols-1 gap-6">
            {/* Agent Performance by LOB */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Agent Execution Performance by LOB</h3>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={agentPerformanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="lob" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="successful" fill="#10b981" name="Successful" stackId="a" />
                  <Bar dataKey="hitl" fill="#f59e0b" name="HITL Required" stackId="a" />
                  <Bar dataKey="failed" fill="#ef4444" name="Failed" stackId="a" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Performance Metrics Table */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Performance Metrics</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Line of Business</th>
                      <th className="text-right py-3 px-4">Total Executions</th>
                      <th className="text-right py-3 px-4">Success Rate</th>
                      <th className="text-right py-3 px-4">HITL Rate</th>
                      <th className="text-right py-3 px-4">Failure Rate</th>
                      <th className="text-right py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {agentPerformanceData.map((lob) => {
                      const total = lob.successful + lob.failed + lob.hitl;
                      const successRate = ((lob.successful / total) * 100).toFixed(1);
                      const hitlRate = ((lob.hitl / total) * 100).toFixed(1);
                      const failureRate = ((lob.failed / total) * 100).toFixed(1);
                      const status = parseFloat(successRate) >= 90 ? 'Excellent' : parseFloat(successRate) >= 80 ? 'Good' : 'Needs Attention';
                      const statusColor = parseFloat(successRate) >= 90 ? 'text-green-600' : parseFloat(successRate) >= 80 ? 'text-yellow-600' : 'text-red-600';
                      
                      return (
                        <tr key={lob.lob} className="border-b hover:bg-muted/50">
                          <td className="py-3 px-4 font-medium">{lob.lob}</td>
                          <td className="text-right py-3 px-4">{total.toLocaleString()}</td>
                          <td className="text-right py-3 px-4">{successRate}%</td>
                          <td className="text-right py-3 px-4">{hitlRate}%</td>
                          <td className="text-right py-3 px-4">{failureRate}%</td>
                          <td className={`text-right py-3 px-4 font-medium ${statusColor}`}>{status}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Resources Tab */}
        <TabsContent value="resources">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Apps Distribution */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Apps Distribution by LOB</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={appsByLOB} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="lob" type="category" />
                  <Tooltip />
                  <Bar dataKey="apps" fill="#3b82f6" name="Apps" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Agents Distribution */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Agents Distribution by LOB</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={appsByLOB} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="lob" type="category" />
                  <Tooltip />
                  <Bar dataKey="agents" fill="#10b981" name="Agents" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* MCP Distribution */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">MCP Distribution by LOB</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={appsByLOB} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="lob" type="category" />
                  <Tooltip />
                  <Bar dataKey="mcps" fill="#f59e0b" name="MCPs" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Resource Utilization Summary */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Resource Utilization Summary</h3>
              <div className="space-y-6 pt-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Server className="w-5 h-5 text-blue-600" />
                      <span className="text-sm">Total Apps</span>
                    </div>
                    <span className="text-2xl font-semibold">{totalApps}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: '100%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-green-600" />
                      <span className="text-sm">Active Agents</span>
                    </div>
                    <span className="text-2xl font-semibold">{totalAgents}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '75%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Layers className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">Total MCPs</span>
                    </div>
                    <span className="text-2xl font-semibold">{totalMCPs}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-orange-500 h-2 rounded-full" style={{ width: '85%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-purple-600" />
                      <span className="text-sm">Total Executions</span>
                    </div>
                    <span className="text-2xl font-semibold">{(totalExecutions / 1000).toFixed(1)}K</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: '92%' }} />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
