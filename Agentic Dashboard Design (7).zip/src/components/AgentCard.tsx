import { Shield, Users, MessageSquare, Zap, MoreVertical, Play, Trash2, Copy, Edit, TrendingUp, Eye, AlertCircle, CheckCircle, XCircle, Clock, UserCheck, UserX, AlertTriangle, Power } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { useState } from 'react';
import { ReportProblemDialog } from './ReportProblemDialog';
import { useUser } from '../contexts/UserContext';
import { Switch } from './ui/switch';

interface Agent {
  id: string;
  name: string;
  lastUpdated: string;
  description: string;
  status: 'draft' | 'published';
  category: string;
  tags: string[];
  stats: {
    versions: number;
    users: number;
    conversations: number;
    actions: number;
  };
  version?: string;
  goals?: {
    total: number;
    success: number;
    failed: number;
    in_progress: number;
    hitl?: number;
  };
  managerStats?: {
    totalUsers: number;
    activeUsers: number;
  };
  driftDetection?: {
    isDrifting: boolean;
    driftScore?: number;
    lastChecked?: string;
    enabled: boolean;
  };
}

interface AgentCardProps {
  agent: Agent;
  onSelect: () => void;
  onViewDetails: () => void;
  onExecute: () => void;
  onViewHistory: () => void;
  onDelete?: (id: string) => void;
  onDuplicate?: (id: string) => void;
  onViewUsers?: (agentId: string, agentName: string) => void;
}

export function AgentCard({ agent, onSelect, onViewDetails, onExecute, onViewHistory, onDelete, onDuplicate, onViewUsers }: AgentCardProps) {
  const { user } = useUser();
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [driftEnabled, setDriftEnabled] = useState(agent.driftDetection?.enabled ?? true);
  
  const handleAction = (e: React.MouseEvent, action: () => void) => {
    e.stopPropagation();
    action();
  };

  const handleDriftToggle = (checked: boolean) => {
    setDriftEnabled(checked);
    // In a real app, this would make an API call to update the drift detection status
    console.log(`Drift detection ${checked ? 'enabled' : 'disabled'} for ${agent.name}`);
  };

  const goals = agent.goals || { total: 0, success: 0, failed: 0, in_progress: 0, hitl: 0 };
  const isManager = user?.role === 'manager';
  const isLOBAdmin = user?.role === 'lob_admin';
  const isConsumer = user?.role === 'consumer';
  const showUserStats = !isConsumer && onViewUsers; // Show for all roles except Consumer
  const managerStats = agent.managerStats || { totalUsers: 0, activeUsers: 0 };
  const driftDetection = agent.driftDetection || { isDrifting: false, enabled: true };

  return (
    <>
      <div 
        className="border rounded-lg p-5 bg-card hover:shadow-lg transition-all cursor-pointer group relative"
        onClick={onSelect}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-9 h-9 rounded-md border bg-muted/50 flex items-center justify-center flex-shrink-0">
                <MessageSquare className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-medium group-hover:text-primary transition-colors truncate">
                  {agent.name}
                </h3>
                <p className="text-xs text-muted-foreground">
                  v{agent.version || '1.0.0'}
                </p>
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 flex-shrink-0" 
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="z-[9999] !bg-white dark:!bg-gray-800 !border !shadow-lg" style={{ position: 'relative' }}>
              <DropdownMenuItem onClick={(e) => handleAction(e as any, onViewDetails)}>
                <Eye className="w-4 h-4 mr-2" />
                View Details
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => handleAction(e as any, () => setShowReportDialog(true))}>
                <AlertCircle className="w-4 h-4 mr-2" />
                Report Problem
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2 min-h-[40px]">
          {agent.description || 'No description provided.'}
        </p>

        {/* Manager Stats (if manager role) */}
        {showUserStats && (
          <div className="mb-4 p-3 bg-muted/30 rounded-lg border border-dashed">
            <div className="grid grid-cols-2 gap-3">
              <button 
                className="flex items-center gap-2 p-2 rounded-md hover:bg-accent transition-colors text-left"
                onClick={(e) => handleAction(e, () => onViewUsers!(agent.id, agent.name))}
              >
                <Users className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Total Users</p>
                  <p className="font-medium">{managerStats.totalUsers}</p>
                </div>
              </button>
              <button 
                className="flex items-center gap-2 p-2 rounded-md hover:bg-accent transition-colors text-left"
                onClick={(e) => handleAction(e, () => onViewUsers!(agent.id, agent.name))}
              >
                <UserCheck className="w-4 h-4 text-green-600" />
                <div>
                  <p className="text-xs text-muted-foreground">Active Users</p>
                  <p className="font-medium text-green-600">{managerStats.activeUsers}</p>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* Goals Stats - Horizontal Layout */}
        <div className="mb-4">
          <div className="grid grid-cols-5 gap-2">
            <button
              className="p-2 rounded-md hover:bg-accent transition-colors flex flex-col items-center justify-center"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              <p className="text-xs text-muted-foreground mb-1">Total</p>
              <p className="font-medium text-lg">{goals.total}</p>
            </button>
            <button
              className="p-2 rounded-md hover:bg-accent transition-colors flex flex-col items-center justify-center"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              <CheckCircle className="w-5 h-5 text-green-600 mb-1" />
              <p className="font-medium text-lg text-green-600">{goals.success}</p>
            </button>
            <button
              className="p-2 rounded-md hover:bg-accent transition-colors flex flex-col items-center justify-center"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              <XCircle className="w-5 h-5 text-red-600 mb-1" />
              <p className="font-medium text-lg text-red-600">{goals.failed}</p>
            </button>
            <button
              className="p-2 rounded-md hover:bg-accent transition-colors flex flex-col items-center justify-center"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              <Clock className="w-5 h-5 text-orange-600 mb-1" />
              <p className="font-medium text-lg text-orange-600">{goals.in_progress}</p>
            </button>
            <button
              className="p-2 rounded-md hover:bg-accent transition-colors flex flex-col items-center justify-center"
              onClick={(e) => handleAction(e, onViewHistory)}
            >
              <UserX className="w-5 h-5 text-blue-600 mb-1" />
              <p className="font-medium text-lg text-blue-600">{goals.hitl || 0}</p>
            </button>
          </div>
          <div className="grid grid-cols-5 gap-2 mt-1">
            <p className="text-[10px] text-muted-foreground text-center">Goals</p>
            <p className="text-[10px] text-muted-foreground text-center">Success</p>
            <p className="text-[10px] text-muted-foreground text-center">Failed</p>
            <p className="text-[10px] text-muted-foreground text-center">In Progress</p>
            <p className="text-[10px] text-muted-foreground text-center">HITL</p>
          </div>
        </div>

        {/* LOB Admin - Drift Detection (if LOB Admin role) */}
        {isLOBAdmin && (
          <div className={`mb-4 p-3 rounded-lg border ${
            driftDetection.isDrifting && driftEnabled
              ? 'bg-orange-50 border-orange-200 dark:bg-orange-950/20 dark:border-orange-800'
              : 'bg-muted/30 border-dashed'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {driftDetection.isDrifting && driftEnabled ? (
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-green-600" />
                )}
                <div>
                  <p className="text-xs font-medium">
                    {driftDetection.isDrifting && driftEnabled ? 'Drift Detected' : 'No Drift Detected'}
                  </p>
                  {driftDetection.lastChecked && (
                    <p className="text-[10px] text-muted-foreground">
                      Last checked: {driftDetection.lastChecked}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                <Switch
                  checked={driftEnabled}
                  onCheckedChange={(checked) => handleDriftToggle(checked)}
                  onClick={(e) => e.stopPropagation()}
                />
                <Power className={`w-3 h-3 ${driftEnabled ? 'text-green-600' : 'text-muted-foreground'}`} />
              </div>
            </div>
            {driftDetection.isDrifting && driftEnabled && driftDetection.driftScore !== undefined && (
              <div className="pt-2 border-t border-orange-200 dark:border-orange-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Drift Score:</span>
                  <span className="font-medium text-orange-600">{driftDetection.driftScore}%</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* View button (was Execute) */}
        <div>
          <Button 
            size="sm" 
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails();
            }}
            className="w-full"
          >
            <Eye className="w-3 h-3 mr-1.5" />
            View
          </Button>
        </div>
      </div>

      <ReportProblemDialog 
        open={showReportDialog}
        onClose={() => setShowReportDialog(false)}
        appName={agent.name}
      />
    </>
  );
}