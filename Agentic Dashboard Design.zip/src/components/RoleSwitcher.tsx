import { useState } from 'react';
import { useUser, Role } from '../contexts/UserContext';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Card } from './ui/card';
import { Wrench, BarChart3, Shield, Activity, ArrowRight } from 'lucide-react';

const roles: { role: Role; name: string; email: string; icon: any; color: string; description: string }[] = [
  {
    role: 'developer',
    name: 'John Developer',
    email: 'john@example.com',
    icon: Wrench,
    color: 'bg-blue-500',
    description: 'Build and test workflows',
  },
  {
    role: 'manager',
    name: 'Sarah Manager',
    email: 'sarah@example.com',
    icon: BarChart3,
    color: 'bg-purple-500',
    description: 'View metrics and analytics',
  },
  {
    role: 'admin',
    name: 'Alex Admin',
    email: 'alex@example.com',
    icon: Shield,
    color: 'bg-orange-500',
    description: 'Manage users and system',
  },
  {
    role: 'production_support',
    name: 'Mike Support',
    email: 'mike@example.com',
    icon: Activity,
    color: 'bg-green-500',
    description: 'Monitor production systems',
  },
];

export function RoleSwitcher() {
  const { user, setUser } = useUser();
  const [open, setOpen] = useState(!user);

  const handleRoleSelect = (roleData: typeof roles[0]) => {
    setUser({
      id: String(Math.random()),
      name: roleData.name,
      email: roleData.email,
      role: roleData.role,
      entitlements: roleData.role === 'admin' ? ['admin_full_access'] : ['basic_access'],
      allowedAgents: roleData.role === 'admin' || roleData.role === 'manager' ? ['all'] : ['1', '2', '3'],
      team: 'Platform Team',
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Switch Role
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Select User Role</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Choose a persona to view their personalized dashboard
          </p>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4 mt-4">
          {roles.map((roleData) => {
            const Icon = roleData.icon;
            const isActive = user?.role === roleData.role;

            return (
              <Card
                key={roleData.role}
                className={`p-4 cursor-pointer transition-all hover:shadow-lg ${
                  isActive ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => handleRoleSelect(roleData)}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-3 ${roleData.color}/10 rounded-lg`}>
                    <Icon className={`w-6 h-6 ${roleData.color.replace('bg-', 'text-')}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium">{roleData.name}</h4>
                      {isActive && (
                        <span className="text-xs text-primary">Current</span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{roleData.email}</p>
                    <p className="text-xs text-muted-foreground">{roleData.description}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </Card>
            );
          })}
        </div>

        <div className="bg-muted/50 border rounded-lg p-4 mt-4">
          <p className="text-sm">
            <strong>Demo Mode:</strong> Each role has a different dashboard with role-specific features
            and permissions. Switch between roles to explore the complete system.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
